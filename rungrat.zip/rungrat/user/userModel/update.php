<?php

class UserUpdateModel {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function updateStockQty($productID, $newStockQty) {
        $update = "UPDATE stock SET StockQty=? WHERE IDProduct=?";
        $stmt = $this->db->prepare($update);
        $stmt->bind_param("ss", $newStockQty, $productID);
        $stmt->execute();
        return $stmt->affected_rows;
    }

    function updateCartItemQuantity($db, $username, $product_id, $new_quantity) {
        $update_query = "UPDATE cart SET Quantity=? WHERE IDCust=? AND IDProduct=?";
        $stmt = $db->prepare($update_query);
        $stmt->bind_param("iss", $new_quantity, $username, $product_id);
        $update_result = $stmt->execute();
        $stmt->close();
        return $update_result;
    }

    function updateStockQuantity($db, $productID, $quantityDifference) {
        $query = "UPDATE stock SET StockQty = StockQty + ? WHERE IDProduct = ?";
        $stmt = $db->prepare($query);
        $stmt->bind_param("is", $quantityDifference, $productID);
        $stmt->execute();
        $stmt->close();
    }
    
    function updateOrderItemQuantity($db, $orderID, $productID, $quantity) {
        $update_query = "UPDATE order_item SET Quantity = ? WHERE OrderID = ? AND IDProduct = ?";
        $stmt = $db->prepare($update_query);
        $stmt->bind_param("iss", $quantity, $orderID, $productID);
        $stmt->execute();
        return $stmt->affected_rows > 0; // คืนค่า true ถ้ามีการอัปเดตข้อมูลสำเร็จ
    }

    function updateOrderDetails($db, $orderID, $name, $lastName, $email, $tel, $address, $totalOrderPrice, $vat) {
        $update_order = "UPDATE order_detail 
                        SET CustName = ?, lastName = ?, email = ?, 
                            tel = ?, address = ?, totalPrice = ?, VAT = ? 
                        WHERE OrderID = ?";
        $stmt = $db->prepare($update_order);
        $stmt->bind_param("sssssdss", $name, $lastName, $email, $tel, $address, $totalOrderPrice, $vat, $orderID);
        $stmt->execute();
        return $stmt->affected_rows;
    }

    function updateOrderStatus($db, $orderID, $status) {
        // Prepare the SQL statement to update the order status
        $update_query = "UPDATE order_detail SET status = ? WHERE OrderID = ?";
        
        // Prepare and execute the statement
        $stmt = $db->prepare($update_query);
        $stmt->bind_param("ss", $status, $orderID);
        $result = $stmt->execute();
        return $result;
    }

    function updateStockSold($db, $stockTypeID, $quantity) {
        $sql = "UPDATE stocktype SET typeSold = typeSold + ? WHERE typeID = ?";
        $stmt = $db->prepare($sql);
        $stmt->bind_param("is", $quantity, $stockTypeID);
        $stmt->execute();
        if ($stmt->errno) {
            return false;
        } else {
            return true;
        }
    }

}
?>
