<?php

class UserInsertModel {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function insertCustomer($new_id_formatted, $name, $email) {
        $insert = "INSERT INTO customer (IDCust, CustName, Email) VALUES (?, ?, ?)";
        $stmt = $this->db->prepare($insert);
        $stmt->bind_param("sss", $new_id_formatted, $name, $email);
        $stmt->execute();
        return $stmt->affected_rows; // คืนค่าจำนวนแถวที่ถูกเพิ่ม
    }    
    

    public function insertWebCustomer($new_id_formatted, $username, $hashedPassword, $name, $address, $tel) {
        $insert = "INSERT INTO customer (IDCust, username, password,  CustName, Address, Tel, Email) 
        VALUES (?, ?, ?, ?, ?, ?, 'email')";
        $stmt = $this->db->prepare($insert);
        $stmt->bind_param("ssssss", $new_id_formatted, $username, $hashedPassword, $name, $address, $tel);
        $stmt->execute();
        return $stmt->affected_rows;
    }

    public function insertWebGuest($new_id_formatted, $name) {
        $insert = "INSERT INTO customer (IDCust, username, password,  CustName, Address, Tel, Email) 
        VALUES (?, ?, ?, ?, ?, ?, 'email')";
        $stmt = $this->db->prepare($insert);
        $stmt->bind_param("ssssss", $new_id_formatted, $username, $hashedPassword, $name, $address, $tel);
        $stmt->execute();
        return $stmt->affected_rows;
    }

    public function insertOrderDetail($CustID, $orderDate, $CustName, $lastName, $email, $tel, $address, $paymentMethod, $grandTotal, $paymentStatus, $vat, $subTotal, $print, $taxname, $taxlastname, $taxemail, $taxtel, $taxaddress) {
        $waitStatus = 'wait';
        $insert = "INSERT INTO order_detail (IDCust, OrderDate, CustName, lastname, email, tel, address, paymentMethod, totalPrice, paymentStatus, status, VAT, subTotal, print, taxName, taxLastname, taxEmail, taxTel, taxAddress) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($insert);
        $stmt->bind_param("sssssssssssssisssss", $CustID, $orderDate, $CustName, $lastName, $email, $tel, $address, $paymentMethod, $grandTotal, $paymentStatus, $waitStatus, $vat, $subTotal, $print, $taxname, $taxlastname, $taxemail, $taxtel, $taxaddress);
        $stmt->execute();
        return $stmt->affected_rows;
    }
    
    
    public function insertOrderItem($orderID, $productID, $qty, $pricePerUnit, $totalPrice, $stockTypeID) {
        $insert = "INSERT INTO order_item (OrderID, IDProduct, Quantity, PricePerUnit, totalPrice, typeID) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->db->prepare($insert);
        $stmt->bind_param("ssssss", $orderID, $productID, $qty, $pricePerUnit, $totalPrice, $stockTypeID);
        $stmt->execute();
        return $stmt->affected_rows;
    }

    function insertCartItem($db, $id, $product_id, $quantity) {
        $insert_query = "INSERT INTO cart (IDCust, IDProduct, Quantity) VALUES (?, ?, ?)";
        $stmt = $db->prepare($insert_query);
        $stmt->bind_param("ssi", $id, $product_id, $quantity);
        $insert_result = $stmt->execute();
        $stmt->close();
        return $insert_result;
    }
    
}
?>
