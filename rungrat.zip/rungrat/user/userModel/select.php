<?php

class UserModel {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function getUserByUsername($username) {
        $query = "SELECT password, IDCust, CustName FROM customer WHERE username = ?";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    function selectProductByName($db, $search_query) {
        $sql = "SELECT * FROM stock WHERE ProductName LIKE '%$search_query%'";
        $result = mysqli_query($db, $sql);
        if ($result) {
            return $result;
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($db);
            return false;
        }
        mysqli_close($db);
    }

    function selectOrderItemsByOrderID($db, $orderID) {
        $sql = "SELECT * FROM order_item WHERE orderID = ?";
        $stmt = $db->prepare($sql);
        $stmt->bind_param("i", $orderID);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result;
    }

    public function getToCheck($username) {
        $query = "SELECT username FROM customer WHERE username = ?";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    function getQuantityFromOrderItem($db, $orderID, $productID) {
        $query = "SELECT Quantity FROM order_item WHERE OrderID = ? AND IDProduct = ?";
        $stmt = $db->prepare($query);
        $stmt->bind_param("ss", $orderID, $productID);
        $stmt->execute();
        $stmt->bind_result($quantity);
        $stmt->fetch();
        $stmt->close();
        return $quantity;
    }

    private function fetchUsername($username) {
        $query = "SELECT username FROM customer WHERE username = ?";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function checkUsernameAvailability($username) {
        $result = $this->fetchUsername($username);
        return $result ? 'taken' : 'available';
    }

    public function getUserByEmail($email) {
        $query = "SELECT IDCust FROM customer WHERE Email = ?";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
    
    
    public function selectStarStockAll() {
        $query = "SELECT * FROM stock";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function selectStarStockFromId($productID) {
        $query = "SELECT * FROM stock WHERE IDProduct=?";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("s", $productID);
        $stmt->execute();
        return $stmt->get_result();
    }
    

    public function selectCustName($id) {
        $query = "SELECT CustName, Email, Tel, Address FROM customer WHERE IDCust='$id'";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        return $stmt->get_result();
    }

    public function selectForEmailRegis() {
        $query = "SELECT MAX(CAST(SUBSTRING(IDCust, 2) AS UNSIGNED)) AS max_id FROM customer";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return $row['max_id'];
    } 

    public function getProductById($db, $id) {
        $query = "SELECT * FROM stock WHERE IDProduct='$id'";
        $result = mysqli_query($db, $query);
        return mysqli_fetch_array($result);
    }

    public function getSimilarProducts($db, $id, $typeID) {
        $query = "SELECT * FROM stock WHERE IDProduct != '$id' AND typeID = '$typeID' LIMIT 5";
        $result = mysqli_query($db, $query);
        // $products = [];
        // while ($row = mysqli_fetch_array($result)) {
        //     $products[] = $row;
        // }
        return $result;
    }

    public function getCartItems($db, $username, $callerFileName) {
        $query = "SELECT stock.*, cart.Quantity AS CartQuantity FROM stock INNER JOIN cart ON stock.IDProduct = cart.IDProduct WHERE cart.IDCust = '$username'";
        $result = mysqli_query($db, $query);
        return $result;
    }
    
    public function getItems($db, $idproduct, $callerFileName) {
        $query = "SELECT * FROM stock WHERE IDProduct='$idproduct'";
        $result = mysqli_query($db, $query);
        return $result;
    }
    
    public function getOrder($db, $orderID, $callerFileName) {
        $query = "SELECT order_detail.*, order_item.IDProduct, order_item.Quantity, order_item.PricePerUnit, order_item.TotalPrice, stock.image_url, stock.ProductName
        FROM order_detail 
        INNER JOIN order_item ON order_detail.orderID = order_item.orderID
        INNER JOIN stock ON order_item.IDProduct = stock.IDProduct
        WHERE order_detail.orderID = '$orderID'";
        $result = mysqli_query($db, $query);
        return $result;
    }

    function getTotalOrderPrice($db, $orderID) {
        $get_total_price_query = "SELECT SUM(PricePerUnit * Quantity) AS total_price FROM order_item WHERE OrderID = ?";
        $stmt = $db->prepare($get_total_price_query);
        $stmt->bind_param("s", $orderID);
        $stmt->execute();
        $total_price_result = $stmt->get_result();
        $total_price_row = $total_price_result->fetch_assoc();
        return $total_price_row['total_price'];
    }
    

    public function getOrderDetails($db, $orderID) {
        $orderQuery = mysqli_query($db, "SELECT * FROM order_detail WHERE OrderID='$orderID'");
        return mysqli_fetch_assoc($orderQuery);
    }

    public function getPaymentStatus($db, $orderID) {
        $cur = mysqli_query($db, "SELECT paymentStatus FROM order_detail WHERE OrderID='$orderID'");
        return mysqli_fetch_assoc($cur)['paymentStatus'];
    }

    public function getOrderItems($db, $orderID) {
        $orderItemsQuery = mysqli_query($db, "SELECT * FROM order_item WHERE OrderID='$orderID'");
        return $orderItemsQuery;
    }

    function checkCartExistence($db, $username, $product_id) {
        $check_query = "SELECT * FROM cart WHERE IDCust='$username' AND IDProduct='$product_id'";
        $check_result = mysqli_query($db, $check_query);
        return $check_result;
    }

    public function getCartProductsByCustomerId($db, $customer_id) {
        $query = "SELECT cart.IDProduct, cart.Quantity, stock.PricePerUnit, stock.typeID 
                  FROM cart 
                  INNER JOIN stock ON cart.IDProduct = stock.IDProduct
                  WHERE cart.IDCust='$customer_id'";
        $result = mysqli_query($db, $query);

        return $result;
    }

    function getHistory($db, $status, $username) {
        $orderQuery = mysqli_query($db, "SELECT * FROM order_detail WHERE IDCust='$username' AND status = '$status' ORDER BY OrderId DESC");
        return $orderQuery;
    }
    
    function itemsQuery($db, $orderID){
        $orderItemsQuery = mysqli_query($db, "SELECT * FROM order_item WHERE OrderID='$orderID'");
        return $orderItemsQuery;
    }
    
    function productQuery($db, $productID){
        $productQuery = mysqli_query($db, "SELECT * FROM stock WHERE IDProduct='$productID'");
        return $productQuery;
    }

    function productQuantityQuery($db, $productID){
        $productQuery = "SELECT StockQty FROM stock WHERE IDProduct='$productID'";
        return $productQuery;
    }    
    
    function orderRow($db, $orderID){
        $orderQuery = mysqli_query($db, "SELECT * FROM order_detail WHERE OrderID='$orderID'");
        $orderRow = mysqli_fetch_assoc($orderQuery);
        return $orderRow;
    }
}
?>
