<?php

class UserDeleteModel {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function deleteCartItemsByCustomerId($db, $customer_id) {
        $delete_query = "DELETE FROM cart WHERE IDCust='$customer_id'";
        mysqli_query($db, $delete_query);
    }

    public function deleteCartItem($db, $productID, $username) {
        $stmt = mysqli_prepare($db, "DELETE FROM cart WHERE IDProduct = ? AND IDCust = ?");
        mysqli_stmt_bind_param($stmt, "ss", $productID, $username);
        if (!mysqli_stmt_execute($stmt)) {
            return false;
        }
        return true;
    }
}
?>
