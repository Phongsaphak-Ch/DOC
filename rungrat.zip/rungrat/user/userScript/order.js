function calculateTotalPrice(pricePerUnit, quantity, totalField) {
    var totalPrice = pricePerUnit * quantity;
    document.getElementById(totalField).innerText = totalPrice.toFixed(2); // Display total price with 2 decimal places
    calculateTotalOrderPrice(); // Calculate total order price
}

function calculateTotalOrderPrice() {
    var totalOrderPrice = 0;
    var vat = 0;
    var totalElements = document.getElementsByClassName('totalPrice');
    for (var i = 0; i < totalElements.length; i++) {
        totalOrderPrice += parseFloat(totalElements[i].innerText);
    }
    var vat = totalOrderPrice * 0.07;
    subtotal = totalOrderPrice;
    totalOrderPrice += vat;
    document.getElementById('totalOrderPrice').innerText = totalOrderPrice.toFixed(2);
    document.getElementById('vat').innerText = vat.toFixed(2);
    document.getElementById('subtotal').innerText = subtotal.toFixed(2);
}

function hideDeliveryAddress() {
    document.getElementById('delivery-address').style.display = 'none';
}

function showDeliveryAddress() {
    document.getElementById('delivery-address').style.display = 'block';
}