<?php
    require '../../../vendor/autoload.php';
    use Firebase\JWT\JWT;
    use Firebase\JWT\Key;

    $key = $secretkey;

    if(isset($_COOKIE['token'])){
        $decoded = JWT::decode($_COOKIE['token'], new Key($key, 'HS256'));
        if(!isset($decoded->data->IDCust) || !isset($decoded->data->login_method)) {
            header('location: ../userView/userSignonPage.php');
            exit();
        }

        $id = $decoded->data->IDCust;
        $login_method = $decoded->data->login_method;
    } else {
        header('location: ../userView/userSignonPage.php');
    }
?>