<?php
    require_once '../userModel/connectDatabase.php';
    require_once '../userModel/update.php';
    require_once '../JWT/JWTConnect.php';
    $db = mysqli_connect($host, $user, $password, $database);

if (isset($_POST['quantity']) && isset($_POST['product_id'])) {
    $userUpdateModel = new UserUpdateModel($db);
    $quantities = $_POST['quantity'];
    $product_ids = $_POST['product_id'];

    // วนลูปเพื่ออัปเดตจำนวนสินค้าในตะกร้า
    for ($i = 0; $i < count($product_ids); $i++) {
        $quantity = $quantities[$i];
        $product_id = $product_ids[$i];

        // อัปเดตจำนวนสินค้าในตาราง cart
        $update_query = $userUpdateModel->updateCartItemQuantity($db, $id, $product_id, $quantity);
    }

    // เมื่ออัปเดตจำนวนสินค้าเสร็จแล้ว ให้ redirect ไปยังหน้า cartOrder.php
    header("Location: ../userView/userCartOrder.php");
    exit();
} else {
    // ถ้าไม่มีข้อมูลจำนวนสินค้าที่ส่งมา ให้ redirect กลับไปยังหน้า cart.php
    header("Location: ../userView/userHome.php");
    exit();
}
?>
