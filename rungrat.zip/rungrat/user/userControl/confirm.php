<?php
    require_once '../userModel/connectDatabase.php';
    require_once '../userModel/select.php';
    require_once '../userModel/insert.php';
    require_once '../userModel/update.php';
    require_once '../JWT/JWTConnect.php';
    $db = mysqli_connect($host, $user, $password, $database);
    $userModel = new UserModel($db);
    $userInsertModel = new UserInsertModel($db);
    $userUpdateModel = new UserUpdateModel($db);
    $CustID = $id;
    $CustName = $_POST['name'];
    $productID = $_POST["product_id"];
    $qty = $_POST["quantity"];
    $lastName = $_POST["lastname"];
    $email = $_POST["email"];
    $tel = $_POST["tel"];
    $address = $_POST["address"];
    $grandTotal = $_POST['grandtotal'];
    $subTotal = $_POST['subTotal'];
    $vat = $_POST['vat'];

    if (!isset($_POST['payment_method'])) {
        header("Location: ../userView/userOrder.php?error=invalidPayment&&product_id=". $productID ."&&quantity=". $qty ."");
        exit();
    }

    $paymentMethod = $_POST['payment_method'];

    if(isset($_POST['tax']) && $_POST['tax'] == 'tax') {
        $taxname = $_POST["name"];
        $taxlastname = $_POST["lastname"];
        $taxemail = $_POST["email"];
        $taxtel = $_POST["tel"];
        $taxaddress = $_POST["address"];
    } else {
        if(isset($_POST["taxname"]) || isset($_POST["taxlastname"]) || isset($_POST["taxemail"]) || isset($_POST["taxtel"]) || isset($_POST["taxaddress"])){
            header("Location: ../userView/userOrder.php?error=invalidTax&&product_id=". $productID ."&&quantity=". $qty ."");
            exit();
        } else {
            $taxname = $_POST["taxname"];
            $taxlastname = $_POST["taxlastname"];
            $taxemail = $_POST["taxemail"];
            $taxtel = $_POST["taxtel"];
            $taxaddress = $_POST["taxaddress"];
        }
    }

    date_default_timezone_set('Asia/Bangkok');
    $orderDate = date("Y-m-d H:i:s");
    $stmt = $userModel->selectStarStockFromId($productID);
    $productRow = $stmt->fetch_assoc();
    $subTotal = $productRow['PricePerUnit'] * $qty;
    $vat = $subTotal * 0.07;
    $grandTotal = $subTotal + $vat;
 
    if ($paymentMethod == "cash_on_delivery") $paymentStatus = "unpaid"; else $paymentStatus = "paid";
    $insertOrderQuery = $userInsertModel->insertOrderDetail($CustID, $orderDate, $CustName, $lastName, $email, $tel, $address, $paymentMethod, $grandTotal, $paymentStatus, $vat, $subTotal, '0', $taxname, $taxlastname, $taxemail, $taxtel, $taxaddress);

    // Get the ID of the inserted order
    $orderID = mysqli_insert_id($db);

    // Get product details



    // Check if there is enough stock
    if ($qty <= $productRow['StockQty']) {
        $newStockQty = $productRow['StockQty'] - $qty;
        $totalPrice = $qty * $productRow['PricePerUnit'];

        $userUpdateModel->updateStockQty($productID, $newStockQty);

        $price = $productRow['PricePerUnit'];
        $typeID = $productRow['typeID'];
        // Insert into order_Item
        $insertOrderItemQuery = $userInsertModel->insertOrderItem($orderID, $productID, $qty, $price, $totalPrice, $typeID);
    } else {
        // Handle insufficient stock error
        echo "<p>Insufficient stock for product with ID $productID</p>";
        // You might want to redirect or display an error message
    }


    // Close the database connection
    mysqli_close($db);

    // Redirect to success page
    header("Location: ../userView/success_page.php?orderID=$orderID");
    exit();
?>