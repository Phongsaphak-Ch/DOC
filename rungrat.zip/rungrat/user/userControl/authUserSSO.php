<?php
require '../../vendor/autoload.php';
require_once '../userModel/select.php';
require_once '../userModel/insert.php';
require_once '../userModel/connectDatabase.php';

use Firebase\JWT\JWT;

if (isset($_GET['name']) && isset($_GET['email'])) {
    $db = mysqli_connect($host, $user, $password, $database);
    if ($db->connect_error) {
        die("Connection failed: " . $db->connect_error);
    }

    if (isset($token['access_token'])) {
        $client->setAccessToken($token['access_token']);

        $google_oauth = new Google_Service_Oauth2($client);

        $google_profile = $google_oauth->userinfo->get();

    }

    // รับค่า Email และ Name จาก session
    $name = $_GET['name'];
    $email = $_GET['email'];

    // เช็คว่า Email นี้มีอยู่ในฐานข้อมูลหรือไม่
    $userModel = new UserModel($db);
    $userData = $userModel->getUserByEmail($email);

    if ($userData) {
        // Email นี้มีอยู่แล้วในฐานข้อมูล
        $key = $secretkey;
        $token = JWT::encode(
            array(
                'iat'       =>  time(),
                'nbf'       =>  time(),
                'exp'       =>  time() + 3600,
                'data'  => array(
                    'IDCust'    =>  $userData['IDCust'],
                    'username'  =>  $email,
                    'login_method' => 'google'
                )
            ),
            $key,
            'HS256'
        );
        setcookie("token", $token, time() + 3600, "/", "", true, true);

        header("Location: ../userView/userHome.php");
        exit();
    } else {
        // กำหนดรหัสลูกค้าใหม่โดยหาค่า ID ที่มากที่สุดแล้วเพิ่มขึ้นอีก 1
        $sql_max_id = $userModel->selectForEmailRegis();
        $max_id = $sql_max_id; // เรียกใช้ฟังก์ชันโดยตรง
        $new_id = ++$max_id;
        $new_id_formatted = "C" . sprintf("%03d", $new_id);
        
        // เตรียมคำสั่ง SQL สำหรับการ insert ข้อมูลลูกค้าใหม่
        $userInsertModel = new UserInsertModel($db);
        $insert_query = $userInsertModel->insertCustomer($new_id_formatted, $name, $email);
        
        if ($insert_query) {
            // เก็บ IDCust ใน session
            $key = $secretkey;
            $token = JWT::encode(
                array(
                    'iat'       =>  time(),
                    'nbf'       =>  time(),
                    'exp'       =>  time() + 3600,
                    'data'  => array(
                        'IDCust'    =>  $new_id_formatted,
                        'username'  =>  $email,
                        'login_method' => 'google'
                    )
                ),
                $key,
                'HS256'
            );
            setcookie("token", $token, time() + 3600, "/", "", true, true);
            
            // ส่งต่อไปยัง userHome.php
            header("Location: ../userView/userHome.php");
            exit();
        } else {
            echo "Error: Unable to insert user.";
        }
        
    }

    $db->close();
} else {
    header("Location: ../userView/userSignonPage.php");
    exit();
}
?>
