<?php
    require_once '../userModel/connectDatabase.php';
    require_once '../userModel/select.php';
    require_once '../userModel/insert.php';
    require_once '../userModel/update.php';
    require_once '../JWT/JWTConnect.php';
    $db = mysqli_connect($host, $user, $password, $database);
    if(isset($_POST['quantity'])) {
        $userModel = new UserModel($db);
        $userInsertModel = new UserInsertModel($db);
        $userUpdateModel = new UserUpdateModel($db);
        $product_id = $_POST['product_id'];
        $quantity = $_POST['quantity'];
        $check_result = $userModel->checkCartExistence($db, $id, $product_id);
        $num_rows = mysqli_num_rows($check_result);

        if($num_rows > 0) {
            $row = mysqli_fetch_assoc($check_result);
            $current_quantity = $row['Quantity'];
            $new_quantity = $current_quantity + $quantity;

            $new_quantity = $current_quantity + $quantity;
            $update_result = $userUpdateModel->updateCartItemQuantity($db, $id, $product_id, $new_quantity);
            if($update_result) {
                header("Location: ../userView/userCart.php");
            } else {
                echo "เกิดข้อผิดพลาดในการอัปเดตจำนวนสินค้าในรถเข็น";
            }
        } else {
            $insert_result = $userInsertModel->insertCartItem($db, $id, $product_id, $quantity);

            if($insert_result) {
                header("Location: ../userView/userCart.php");
            } else {
                echo "เกิดข้อผิดพลาดในการเพิ่มสินค้าในรถเข็น";
            }
        }
    }
?>
