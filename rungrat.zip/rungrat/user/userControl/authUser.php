<?php
require '../../vendor/autoload.php';
require_once '../userModel/select.php';
require_once '../userModel/connectDatabase.php';

use Firebase\JWT\JWT;

if (!isset($_POST["lusername"]) || empty($_POST["lusername"])) {
    header("Location: ../userView/userSignonPage.php");
    exit();
} else {
    $db = mysqli_connect($host, $user, $password, $database);
    $userModel = new UserModel($db);
    $user = $userModel->getUserByUsername($_POST["lusername"]);

    if ($user) {
        $dbPassword = $user['password'];
        $id = $user['IDCust'];
        if (password_verify($_POST["password"], $dbPassword)) {
            $key = $secretkey;
            $token = JWT::encode(
                array(
                    'iat'       =>  time(),
                    'nbf'       =>  time(),
                    'exp'       =>  time() + 3600,
                    'data'  => array(
                        'IDCust'        =>  $id,
                        'username'  =>  $user['CustName'],
                        'login_method' => '0'
                    )
                ),
                $key,
                'HS256'
            );
            setcookie("token", $token, time() + 3600, "/", "", true, true);

            header("Location: ../userView/userHome.php");
            exit();
        } else {
            header("Location: ../userView/userSignonPage.php?error=InvalidCredentials");
        }
    } else {
        header("Location: ../userView/userSignonPage.php?error=InvalidCredentials");
        exit();
    }
}
?>
