<?php
    require_once '../userModel/connectDatabase.php';
    require_once '../userModel/delete.php';
    require_once '../JWT/JWTConnect.php';
    $db = mysqli_connect($host, $user, $password, $database);
    $userDeleteModel = new UserDeleteModel($db);
    $productID = $_GET['message'];  // Adjust this line to retrieve the correct parameter

    // Execute statement
    if (!$userDeleteModel->deleteCartItem($db, $productID, $id)) {
        // Error
        // echo '<div class="error">Error: Unable to delete product from cart</div>';
    } else {
        // Success
        // echo '<div class="success">Product deleted from cart successfully</div>';
    }

    mysqli_close($db);

    // Redirect back to the cart page after 3 seconds
    header("Location: ../userView/userCart.php");
    exit(); // Add this line to stop script execution immediately after redirection
?>
