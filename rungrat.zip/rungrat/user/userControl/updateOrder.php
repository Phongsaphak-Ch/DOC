<?php
    require_once '../userModel/connectDatabase.php';
    require_once '../userModel/select.php';
    require_once '../userModel/update.php';
    $db = mysqli_connect($host, $user, $password, $database);

    require_once '../JWT/JWTConnect.php';
    $userModel = new UserModel($db);
    $userUpdateModel = new UserUpdateModel($db);
    $orderID = $_POST["orderID"];
    $name = $_POST["name"];
    $lastName = $_POST["lastname"];
    $address = $_POST["address"];
    $email = $_POST["email"];
    $tel = $_POST["tel"];
    $quantities = $_POST['quantity'];

    // Calculate total price from order items
    $totalOrderPrice = 0;

    foreach ($quantities as $key => $quantity) {
        // Get the product ID associated with the current item
        $productID = $_POST['productID'][$key];

        $currentQuantity = $userModel->getQuantityFromOrderItem($db, $orderID, $productID);
        $quantityDifference = $currentQuantity - $quantity;
        $updateResult = $userUpdateModel->updateStockQuantity($db, $productID, $quantityDifference);
        $update_result = $userUpdateModel->updateOrderItemQuantity($db, $orderID, $productID, $quantity);
    
        if (!$update_result) {
            // Handle query execution error
            echo "Error updating quantity: " . mysqli_error($db);
        } else {
            $totalOrderPrice = $userModel->getTotalOrderPrice($db, $orderID);
        }
    }

    // Calculate VAT
    $vat = $totalOrderPrice * 0.07;
    $totalOrderPrice += $vat;

    // Update other details (customer information, total order price, VAT) for the entire order
    $update_result = $userUpdateModel->updateOrderDetails($db, $orderID, $name, $lastName, $email, $tel, $address, $totalOrderPrice, $vat);
    if (!$update_result) {
        // Handle query execution error
        echo "Error updating order details: " . mysqli_error($db);
    }

    // Redirect to historywait.php
    header("Location: ../userView/historywait.php");

    // Close the database connection
    mysqli_close($db);
?>
