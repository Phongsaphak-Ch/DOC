<?php
require_once '../userModel/select.php';
require_once '../userModel/insert.php';
require_once '../userModel/connectDatabase.php';
$db = mysqli_connect($host, $user, $password, $database);

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$username = $_POST['username'];
$password = $_POST['password'];
$name = $_POST['name'];
$address = $_POST['address'];
$tel = $_POST['tel'];

$userModel = new UserModel($db);
$max_id = $userModel->selectForEmailRegis();
$new_id = ++$max_id;
$new_id_formatted = "C" . sprintf("%03d", $new_id);

$hashedPassword = password_hash($password , PASSWORD_BCRYPT);

$userInsertModel = new UserInsertModel($db);
$insert_query = $userInsertModel->insertWebCustomer($new_id_formatted, $username, $hashedPassword, $name, $address, $tel);

if ($insert_query > 0) {
    header("Location: ../userView/userSignonPage.php");
} else {
    echo "Error: Failed to create new record";
}

$db->close();
?>
