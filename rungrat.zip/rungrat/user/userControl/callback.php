<?php
require '../../vendor/autoload.php';
require_once '../userModel/select.php';
require_once '../userModel/insert.php';
require_once '../userModel/connectDatabase.php';

use Firebase\JWT\JWT;
require_once('LineLogin.php');

$line = new LineLogin();
$get = $_GET;

$code = $get['code'];
$state = $get['state'];
$token = $line->token($code, $state);

if (property_exists($token, 'error'))
    header('location: ../userView/userSignonPage.php');

if ($token->id_token) {
    $profile = $line->profileFormIdToken($token);
    
    // เพิ่มการบันทึก $name และ $email ลงในฐานข้อมูล
    $name = $profile->name;
    $email = $profile->email;

    $db = mysqli_connect($host, $user, $password, $database);
    if ($db->connect_error) {
        die("Connection failed: " . $db->connect_error);
    }

    // เช็คว่ามีข้อมูลซ้ำในฐานข้อมูลหรือไม่
    $userModel = new UserModel($db);
    $userData = $userModel->getUserByEmail($email);

    if ($userData) {
        $key = $secretkey;
        $token = JWT::encode(
            array(
                'iat'		=>	time(),
                'nbf'		=>	time(),
                'exp'		=>	time() + 3600,
                'data'	=> array(
                    'IDCust'	=>	$userData['IDCust'],
                    'username'	=>	$email,
                    'profile'   => $profile,
                    'login_method' => 'line'
                )
            ),
            $key,
            'HS256'
        );
        setcookie("token", $token, time() + 3600, "/", "", true, true);
        header("Location: ../userView/userHome.php");
    } else {

        // กำหนดรหัสลูกค้าใหม่โดยหาค่า ID ที่มากที่สุดแล้วเพิ่มขึ้นอีก 1
        $sql_max_id = $userModel->selectForEmailRegis();
        $max_id = $sql_max_id; // เรียกใช้ฟังก์ชันโดยตรง
        $new_id = ++$max_id;
        $new_id_formatted = "C" . sprintf("%03d", $new_id);
        
        // เตรียมคำสั่ง SQL สำหรับการ insert ข้อมูลลูกค้าใหม่
        $userInsertModel = new UserInsertModel($db);
        $insert_query = $userInsertModel->insertCustomer($new_id_formatted, $name, $email);
        
        if ($insert_query) {
            // ส่งต่อไปยัง userHome.php
            $key = $secretkey;
				$token = JWT::encode(
					array(
						'iat'		=>	time(),
						'nbf'		=>	time(),
						'exp'		=>	time() + 3600,
						'data'	=> array(
							'IDCust'	=>	$new_id_formatted,
							'username'	=>	$email,
                            'profile'   => $profile,
                            'login_method' => 'line'
						)
					),
					$key,
					'HS256'
				);
				setcookie("token", $token, time() + 3600, "/", "", true, true);
            header("Location: ../userView/userHome.php");
            exit();
        } else {
            echo "Error: " . $insert_query . "<br>" . $db->error;
        }
    }

    // ปิดการเชื่อมต่อกับฐานข้อมูล
    $db->close();
}
?>
