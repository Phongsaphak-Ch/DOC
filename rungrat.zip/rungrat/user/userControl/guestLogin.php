<?php
require '../../vendor/autoload.php';
require_once '../userModel/insert.php';
require_once '../userModel/connectDatabase.php';

use Firebase\JWT\JWT;
$db = mysqli_connect($host, $user, $password, $database);
$key = $secretkey;
$objectID = uniqid();
$userInsertModel = new UserInsertModel($db);
$insert_query = $userInsertModel->insertWebGuest($objectID, 'guest');
$token = JWT::encode(
    array(
        'iat'       =>  time(),
        'nbf'       =>  time(),
        'exp'       =>  time() + 3600,
        'data'  => array(
            'IDCust'        =>  $objectID,
            'login_method' => '1'
        )
    ),
    $key,
    'HS256'
);
setcookie("token", $token, time() + 3600, "/", "", true, true);
header("Location: ../userView/userHome.php");
?>