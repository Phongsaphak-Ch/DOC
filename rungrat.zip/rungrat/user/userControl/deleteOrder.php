<?php
    require_once '../userModel/connectDatabase.php';
    require_once '../userModel/select.php';
    require_once '../userModel/update.php';
    require_once '../JWT/JWTConnect.php';
    $db = mysqli_connect($host, $user, $password, $database);
    $orderID = $_GET["orderID"];
    $status = "cancel";
    $userModel = new UserModel($db);
    $userUpdateModel = new UserUpdateModel($db);

    // อัปเดตสถานะในตาราง order_detail
    $result = $userUpdateModel->updateOrderStatus($db, $orderID, $status);

    if($result) {
        // ดึงข้อมูล order_item ที่เกี่ยวข้องกับ OrderID นี้
        // $orderItemsQuery = $userModel->itemsQuery($db, $orderID);
        $orderItemsResult = $userModel->itemsQuery($db, $orderID);


        // ลูปเพื่ออัปเดต StockQty ในตาราง stock
        while ($orderItem = mysqli_fetch_assoc($orderItemsResult)) {
            $productID = $orderItem['IDProduct'];
            $quantityCancelled = $orderItem['Quantity'];

            // ดึงข้อมูลจำนวนสินค้าที่มีอยู่ในสต็อก
            $stockQuery = $userModel->productQuantityQuery($db, $productID);
            $productResult = mysqli_query($db, $stockQuery);
            $productRow = mysqli_fetch_assoc($productResult);
            $currentStock = $productRow['StockQty'];
            

            // คำนวณจำนวนสินค้าใหม่ในสต็อก
            $newStockQty = $currentStock + $quantityCancelled;

            // อัปเดต StockQty ในตาราง stock
            $updateStockQuery = $userUpdateModel->updateStockQty($productID, $newStockQty);
        }

        header("Location: ../userView/historyCancel.php");
    } else {
        echo "เกิดข้อผิดพลาดในการลบสินค้าออกจากรถเข็น";
    }
?>
