<?php
    require_once '../userModel/connectDatabase.php';
    require_once '../userModel/select.php';
    require_once '../userModel/insert.php';
    require_once '../userModel/update.php';
    require_once '../userModel/delete.php';
    require_once '../JWT/JWTConnect.php';
    $db = mysqli_connect($host, $user, $password, $database);
    $userModel = new UserModel($db);
    $userInsertModel = new UserInsertModel($db);
    $userUpdateModel = new UserUpdateModel($db);
    $userDeleteModel = new UserDeleteModel($db);
    $name = $_POST["name"];
    $lastName = $_POST["lastname"];
    $email = $_POST["email"];
    $tel = $_POST["tel"];
    $address = $_POST["address"];
    $grandTotal = $_POST['grandtotal'];
    $subTotal = $_POST['subTotal'];
    $vat = $_POST['vat'];
    $quantities = $_POST['quantity'];
    $product_ids = $_POST['product_id'];

    if (!isset($_POST['payment_method'])) {
        header("Location: ../userView/userCartOrder.php?error=invalidPayment");
        exit();
    }

    $paymentMethod = $_POST['payment_method'];

    if(isset($_POST['tax']) && $_POST['tax'] == 'tax') {
        // ให้ใช้ค่าจากช่องข้อมูล "ที่อยู่การจัดส่ง" ในการเติมค่าในช่องข้อมูล "ที่อยู่ออกใบกำกับภาษี"
        $taxname = $_POST["name"];
        $taxlastname = $_POST["lastname"];
        $taxemail = $_POST["email"];
        $taxtel = $_POST["tel"];
        $taxaddress = $_POST["address"];
    } else {
        if(isset($_POST["taxname"]) || isset($_POST["taxlastname"]) || isset($_POST["taxemail"]) || isset($_POST["taxtel"]) || isset($_POST["taxaddress"])){
            header("Location: ../userView/userCartOrder.php?error=invalidTax");
            exit();
        } else {
            $taxname = $_POST["taxname"];
            $taxlastname = $_POST["taxlastname"];
            $taxemail = $_POST["taxemail"];
            $taxtel = $_POST["taxtel"];
            $taxaddress = $_POST["taxaddress"];
        }
    }

    // วนลูปเพื่ออัปเดตจำนวนสินค้าในตะกร้า
    for ($i = 0; $i < count($product_ids); $i++) {
        $quantity = $quantities[$i];
        $product_id = $product_ids[$i];

        // อัปเดตจำนวนสินค้าในตาราง cart
        $update_query = $userUpdateModel->updateCartItemQuantity($db, $id, $product_id, $quantity);
    }
    date_default_timezone_set('Asia/Bangkok');
    $cur = $userModel->getCartProductsByCustomerId($db, $id);
    $orderDate = date("Y-m-d H:i:s");
    $products = array();
    $total_order_price = 0;
    
    while ($row = mysqli_fetch_assoc($cur)) {
        $products[] = $row;
        $total_order_price += ($row['Quantity'] * $row['PricePerUnit']);
    }

    $vat = $total_order_price * 0.07;
    $total_order_price += $vat;

    // สร้างข้อมูลในตาราง order_detail
    if ($paymentMethod == "cash_on_delivery") $paymentStatus = "unpaid"; else $paymentStatus = "paid";
    $insertOrderQuery = $userInsertModel->insertOrderDetail($id, $orderDate, $name, $lastName, $email, $tel, $address, $paymentMethod, $total_order_price, $paymentStatus, $vat, $subTotal, '0', $taxname, $taxlastname, $taxemail, $taxtel, $taxaddress);

    // ดึง orderID ที่เพิ่งเพิ่มลงใน order_detail
    $orderID = mysqli_insert_id($db);

    // สร้างข้อมูลในตาราง order_item และลดจำนวนสินค้าใน stock
    foreach ($products as $product) {
        $productID = $product['IDProduct'];
        $Quantity = $product['Quantity']; // ต้องตรวจสอบว่า key 'Quantity' มีการกำหนดค่าหรือไม่
        $PricePerUnit = $product['PricePerUnit'];
        $typeID = $product['typeID'];

        if(isset($product['Quantity'])) {
            $result = $userModel->selectStarStockFromId($productID);
            $stock_row = $result->fetch_assoc();
            
            // ถ้ามีสินค้าพอให้ทำการ insert ข้อมูลลงในตาราง order_item และลดจำนวนสินค้าใน stock
            if ($stock_row['StockQty'] >= $Quantity) {
                $newStockQty = $stock_row['StockQty'] - $Quantity;
                $userUpdateModel->updateStockQty($productID, $newStockQty);
                
                // คำนวณราคารวมของสินค้าแต่ละรายการ
                $total_item_price = $Quantity * $PricePerUnit;

                // เพิ่มข้อมูลลงในตาราง order_item
                $insertOrderItemQuery = $userInsertModel->insertOrderItem($orderID, $productID, $Quantity, $PricePerUnit, $total_item_price, $typeID);
            } else {
                // กรณีจำนวนสินค้าใน stock ไม่พอ
                echo "สินค้า $productID มีจำนวนไม่เพียงพอ";
            }
        } else {
            echo "ไม่พบข้อมูลจำนวนสินค้าสำหรับสินค้า $productID";
        }
    }

    // ลบข้อมูลในตาราง cart
    $userDeleteModel->deleteCartItemsByCustomerId($db, $id);
    header("Location: ../userView/success_page.php?orderID=$orderID");
?>