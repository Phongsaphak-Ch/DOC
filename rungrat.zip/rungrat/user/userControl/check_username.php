<?php
require_once '../userModel/connectDatabase.php';
require_once '../userModel/select.php';
if(isset($_POST['username'])) {
    $db = mysqli_connect($host, $user, $password, $database);
    if ($db->connect_error) {
        die("Connection failed: " . $db->connect_error);
    }

    $userModel = new UserModel($db);
    $username = $_POST['username'];
    echo $userModel->checkUsernameAvailability($username);

    $db->close();
}
?>
