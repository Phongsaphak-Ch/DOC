<?php
session_start();
require_once("LineLogin.php");
$line = new LineLogin();
$link = $line->getLink();
header("Location: $link");
exit();
?>
