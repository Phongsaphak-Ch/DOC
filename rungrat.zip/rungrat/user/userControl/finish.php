<?php
    require_once '../userModel/connectDatabase.php';
    require_once '../userModel/select.php';
    require_once '../userModel/update.php';
    
    $db = mysqli_connect($host, $user, $password, $database);
    $userSelectModel = new UserModel($db);
    $userUpdateModel = new UserUpdateModel($db);
    $orderID = $_GET["orderID"];
    $status = "finish";
    $result = $userUpdateModel->updateOrderStatus($db, $orderID, $status);
    $orderItems = $userSelectModel->selectOrderItemsByOrderID($db, $orderID);
    $totalQuantity = array();
    while ($orderItem = mysqli_fetch_assoc($orderItems)) {
        $stockTypeID = $orderItem['typeID'];
        $quantity = $orderItem['Quantity'];
        if (!isset($totalQuantity[$stockTypeID])) {
            $totalQuantity[$stockTypeID] = 0;
        }
        $totalQuantity[$stockTypeID] += $quantity;
    }
    foreach ($totalQuantity as $stockTypeID => $quantity) {
        $result = $userUpdateModel->updateStockSold($db, $stockTypeID, $quantity);
        if (!$result) {
            echo "เกิดข้อผิดพลาดในการอัปเดตข้อมูลสินค้า";
            exit;
        }
    }
    header("Location: ../userView/historyFinish.php");
?>
