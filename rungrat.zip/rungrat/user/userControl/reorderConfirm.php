<?php
require_once '../userModel/connectDatabase.php';
require_once '../userModel/select.php';
require_once '../userModel/insert.php';
require_once '../userModel/update.php';
require_once '../JWT/JWTConnect.php';

$db = mysqli_connect($host, $user, $password, $database);
$userModel = new UserModel($db);
$userInsertModel = new UserInsertModel($db);
$userUpdateModel = new UserUpdateModel($db);

$CustID = $id;
$CustName = $_POST['name'];
$productIDs = $_POST["product_id"];
$quantities = $_POST["quantity"];
$lastName = $_POST["lastname"];
$email = $_POST["email"];
$tel = $_POST["tel"];
$address = $_POST["address"];
$orderID = $_POST['orderID'];

if (!isset($_POST['payment_method'])) {
    header("Location: ../userView/userReorder.php?error=invalidPayment&&orderID=". $orderID ."");
    exit();
}

$paymentMethod = $_POST['payment_method'];

if(isset($_POST['tax']) && $_POST['tax'] == 'tax') {
    // ให้ใช้ค่าจากช่องข้อมูล "ที่อยู่การจัดส่ง" ในการเติมค่าในช่องข้อมูล "ที่อยู่ออกใบกำกับภาษี"
    $taxname = $_POST["name"];
    $taxlastname = $_POST["lastname"];
    $taxemail = $_POST["email"];
    $taxtel = $_POST["tel"];
    $taxaddress = $_POST["address"];
} else {
    if(isset($_POST["taxname"]) || isset($_POST["taxlastname"]) || isset($_POST["taxemail"]) || isset($_POST["taxtel"]) || isset($_POST["taxaddress"])){
        header("Location: ../userView/userReorder.php?error=invalidTax&&orderID=". $orderID ."");
        exit();
    } else {
        $taxname = $_POST["taxname"];
        $taxlastname = $_POST["taxlastname"];
        $taxemail = $_POST["taxemail"];
        $taxtel = $_POST["taxtel"];
        $taxaddress = $_POST["taxaddress"];
    }
}

date_default_timezone_set('Asia/Bangkok');
$orderDate = date("Y-m-d H:i:s");
$totalOrderPrice = 0;

foreach ($productIDs as $key => $productID) {
    $quantity = $quantities[$key];
    $stmt = $userModel->selectStarStockFromId($productID);
    $productRow = $stmt->fetch_assoc();
    $totalOrderPrice += $productRow['PricePerUnit'] * $quantity;
}

$vat = $totalOrderPrice * 0.07;
$grandTotal = $totalOrderPrice + $vat;

if ($paymentMethod == "cash_on_delivery") {
    $paymentStatus = "unpaid";
} else {
    $paymentStatus = "paid";
}

$insertOrderQuery = $userInsertModel->insertOrderDetail($CustID, $orderDate, $CustName, $lastName, $email, $tel, $address, $paymentMethod, $grandTotal, $paymentStatus, $vat, $totalOrderPrice, '0', $taxname, $taxlastname, $taxemail, $taxtel, $taxaddress);

// Get the ID of the inserted order
$orderID = mysqli_insert_id($db);

foreach ($productIDs as $key => $productID) {
    // Get product details
    $result = $userModel->selectStarStockFromId($productID);
    $productRow = $result->fetch_assoc();       

    // Get quantity from the posted data
    $quantity = $quantities[$key];

    if ($quantity <= $productRow['StockQty']) {
        $totalPrice = $quantity * $productRow['PricePerUnit'];
        $totalOrderPrice += $totalPrice;
        $price = $productRow['PricePerUnit'];
        $typeID = $productRow['typeID'];

        // Insert into order_Item
        $insertOrderItemQuery = $userInsertModel->insertOrderItem($orderID, $productID, $quantity, $price, $totalPrice, $typeID);

        // Update stock quantity
        $newStockQty = $productRow['StockQty'] - $quantity;
        $userUpdateModel->updateStockQty($productID, $newStockQty);
    } else {
        // Handle insufficient stock error
        echo "<p>Insufficient stock for product with ID $productID</p>";
        // You might want to redirect or display an error message
    }
}

// Close the database connection
mysqli_close($db);

// Redirect to success page
header("Location: ../userView/success_page.php?orderID=$orderID");
exit();
?>