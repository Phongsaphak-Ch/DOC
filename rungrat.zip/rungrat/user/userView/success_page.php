<?php
    require '../../../vendor/autoload.php';
    require_once '../userModel/connectDatabase.php';
    require_once '../userModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);

    require_once '../JWT/JWTConnect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="../userStyle/history.css">
</head>
<body>
    <div class="area">
        <div class="circles">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </div>
        <div class="navBar"><center>
            <?php 
                $userModel = new UserModel($db);
                include_once 'userNavBar.php' 
            ?>
        </div><br><br><br><br>
        <center>
        <?php
            $orderID = $_GET['orderID'];
            $paymentStatus = $userModel->getPaymentStatus($db, $orderID);

            
            // Check if the query was successful
            if ($paymentStatus !== false) {
                // Check the payment status
                if ($paymentStatus == 'unpaid') {
                    echo "<h1><font color='#fff'><br>คำสั่งซื้อของคุณ<br></font></h1>";
                    // Additional code for invoice display can be added here
                } else {
                    echo "<h1><font color='#fff'><br>คำสั่งซื้อของคุณ<br></font></h1>";
                    // Additional code for receipt display can be added here
                }
            } else {
                echo "Error: Unable to retrieve payment status.";
            }
        ?>
        <!-- <h1><font color='#fff'><br>ใบเสร็จ<br></font></h1> -->
        <div class="container">
        <?php
        if (isset($_GET['orderID'])) {
            // $orderID = $_GET['orderID'];

            $orderRow = $userModel->getOrderDetails($db, $orderID);

            // Display order information
            echo "<p><span style='float: left;'>Order ID: &nbsp&nbsp</span>" . $orderRow['OrderID'] . "</span></p>";
            echo "<p><span style='float: left;'>Customer ID: &nbsp&nbsp</span>" . $orderRow['IDCust'] . "</span></p>";
            echo "<p><span style='float: left;'>Customer name: &nbsp&nbsp</span>" . $orderRow['CustName'] . "&nbsp&nbsp&nbsp&nbsp&nbsp". $orderRow['lastName'] . "</span></p>";
            echo "<p><span style='float: left;'>Customer address: &nbsp&nbsp</span>" . $orderRow['address'] . "</span></p>";
            echo "<p><span style='float: left;'>Payment Method: &nbsp&nbsp</span>" . $orderRow['paymentMethod'] . "</span></p>";
            echo "<p><span style='float: left;'>Tel: &nbsp&nbsp</span>" . $orderRow['tel'] . "</span></p>";

            echo "<p>Order Date: &nbsp&nbsp" . $orderRow['OrderDate'] . "</p>";

            echo "<style>";
            echo "table { border-collapse: collapse; }";
            echo "table, th, td { border: 1px solid #ecf0f1; }";
            echo "</style>";

            // Display ordered items
            echo "<center>";
            echo "<table>";
            echo "<tr>";
            echo "<th>รูปสินค้า</th>";
            echo "<th>ชื่อสินค้า</th>";
            echo "<th>ราคาต่อชิ้น</th>";
            echo "<th>จำนวน</th>";
            echo "<th>ราคารวม</th>";
            echo "</tr>";

            $totalOrderPrice = 0; // Initialize total order price
            $orderItemsQuery = $userModel->getOrderItems($db, $orderID);
            while ($row = mysqli_fetch_assoc($orderItemsQuery)) {
                $productID = $row['IDProduct'];
                $productRow = $userModel->getProductById($db, $productID);
                // $productRow = mysqli_fetch_assoc($productQuery);
                $totalPrice = $row["PricePerUnit"] * $row["Quantity"];
                echo "<tr>";
                echo '<td><img src="' . $productRow["image_url"] . '" alt="Product Image" style="width: 100px; height: 120px;"></td>';
                echo "<td>" . $productRow["ProductName"] . "</td>";
                echo "<td>" . $row["PricePerUnit"] . "</td>";
                echo "<td>" . $row["Quantity"] . "</td>";
                echo "<td>$totalPrice</td>";
                echo "</tr>";
                $totalOrderPrice += $totalPrice; // Add the item's total price to the overall total
            }

            echo "</table>";

            // Display total order price
            echo "<p style='text-align: right; font-weight: bold;'>Total Order Price: " . $orderRow['totalPrice'] . " Baht(VAT 7%)</p>";
        }
        mysqli_close($db);
        ?>
        <form action="userHome.php" method="post">
            <div class="button-container">
                <button type="submit" value="ตกลง">ตกลง
            </div>
        </form>
        </div>
        <br><br><br>
    </div>
</body>
</html>
