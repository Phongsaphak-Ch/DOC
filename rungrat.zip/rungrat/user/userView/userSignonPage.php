<?php
    $error = isset($_GET['error']) ? $_GET['error'] : '';
    if(isset($decoded->data->IDCust) || isset($decoded->data->login_method)) {
        header('location: ../userView/userHome.php');
        exit();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="../userStyle/style.css">
    <title>Login</title>
</head>

<body>
<?php
    require_once '../google/google.php';

    // authenticate code from Google OAuth Flow
    if (isset($_GET['code'])) {
        // $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
        // $client->setAccessToken($token['access_token']);

        // // get profile info
        // $google_oauth = new Google_Service_Oauth2($client);
        // $google_account_info = $google_oauth->userinfo->get();
        // $email =  $google_account_info->email;
        // $name =  $google_account_info->name;
        // header("Location: ../userControl/authUserSSO.php?name=$name&email=$email");
        // exit();
    } else {
?>


<div class="container" id="container">
        <div class="form-container sign-up">
            <form action="../userControl/userRegisterProcess.php" method="post">
                <h1>Create Account</h1><br>
                <span>or use your email for registration</span><br>
                <input type="text" name="username" placeholder="username">
                <span id="usernameError" style="color: red;"></span>
                <input type="password" id="password" name="password" placeholder="password" required oninput="validatePassword()">
                <span id="passwordStatus" style="color: red;"></span>
                <input type="password" name="cpassword" id="cpassword" placeholder="confirm password" oninput="checkPasswordMatch()">
                <span id="cpasswordStatus" style="color: red;"></span>
                <input type="text" name="name" placeholder="Name">
                <input type="text" name="address" placeholder="Address">
                <input type="tel" name="tel" placeholder="Tel" pattern="[0-9]+" title="Please enter only numeric characters" required minlength="10" required maxlength="11">
                <button id="signupButton" disabled>Sign Up</button>
            </form>
        </div>
        <div class="form-container sign-in">
            <form action="../userControl/authUser.php" method="post">
                <h1>Sign In</h1>
                <div class="social-icons">
                    <a href="<?php echo $client->createAuthUrl() ?>" class="icon"><img src="../../pic/icon/google.png" alt="Google Plus" style="width: 40px; height: 40px;"></a>
                    <a href="../userControl/Line.php" class="icon">
                        <img src="../../pic/icon/line.png" alt="line" style="width: 40px; height: 40px; border-radius: 10px;">
                    </a>
                </div>
                <span>or use your username for Sign In</span>
                <?php if ($error === 'InvalidCredentials'): ?>
                    <br><span style="color: red;">Username or password is invalid.</span>
                <?php endif; ?>
                <input type="text" name="lusername" placeholder="username">
                <input type="password" name="password" placeholder="password">
                <a href="#">Forget your password</a><br>
                <a href="../userControl/guestLogin.php">Login with guest</a>
                <button>Sign In</button>
            </form>
        </div>
        <div class="toggle-container">
            <div class="toggle">
                <div class="toggle-panel toggle-left">
                    <h1>Welcome Back!</h1>
                    <p>Please, Enter your username and password</p>
                    <button class="hidden" id="login">Sign In</button>
                </div>
                <div class="toggle-panel toggle-right">
                    <h1>Hello!</h1>
                    <p>Please, Register with your personal details to use all of the site features</p>
                    <button class="hidden" id="register">Sign Up</button>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="../userScript/script.js"></script>
    <script>
        $(document).ready(function() {
            $('input[name="username"]').blur(function() {
                var username = $(this).val();

                $.ajax({
                    url: '../userControl/check_username.php',
                    method: 'POST',
                    data: {username: username},
                    success: function(response) {
                        if (response == 'taken') {
                            // ถ้า username ซ้ำ
                            $('#usernameError').text('Username is already taken. Please choose another one.');
                            $('input[name="username"]').val('');
                        } else {
                            $('#usernameError').text('');
                        }
                    },
                    error: function(xhr, status, error) {
                        alert('Error occurred while checking username: ' + error);
                    }
                });
            });
        });
    </script>
<?php } ?>
</body>
</html>
