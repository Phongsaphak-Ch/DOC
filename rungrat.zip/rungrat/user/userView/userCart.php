<?php
    require_once '../userModel/connectDatabase.php';
    require_once '../userModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);

    require_once '../JWT/JWTConnect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="../userStyle/cart.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="../userScript/script.js"></script>
  <script src="../userScript/order.js"></script>
</head>
<body>
    <div class="area">
        <div class="circles">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </div>
        <div class="navBar"><center>
            <?php 
                $userModel = new UserModel($db);
                include_once 'userNavBar.php' 
            ?>
        </div><br><br><br><br>
        <h1><font color='#fff'>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspรถเข็นของคุณ</font></h1>
        <form action='../userControl/cartUpdate.php' method='post'>
        <?php
            $result = $userModel->getCartItems($db, $id, basename(__FILE__));
            $count = mysqli_num_rows($result);
            if ($count == 0) {
                echo "<div class='cart'>";
                echo "<h2><center>ไม่มีสินค้าในรถเข็น</center></h2>";
                echo "</div>";
            } else {
                echo "<div class='cart'>";
                echo "<center>";
                echo "<table>";
                echo "<tr>";
                echo "<th></th>";
                echo "<th>ชื่อสินค้า</th>";
                echo "<th>ราคาต่อหน่วย</th>";
                echo "<th>จำนวนที่ซื้อ</th>";
                echo "<th>ราคารวม</th>";
                echo "<th></th>";
                echo "</tr>";
                $totalPrice = 0;
                $product_ids = [];

                while ($row = mysqli_fetch_array($result)) {
                    $subtotal = $row["PricePerUnit"] * $row["CartQuantity"];
                    $totalPrice += $subtotal;
                    $product_ids[] = $row["IDProduct"];
                    echo "<tr>";
                    echo '<td><img src="' . $row["image_url"] . '" alt="Product Image" style="width: 150px; height: 170px;"></td>';
                    echo "<td>" . $row["ProductName"] . "</td>";
                    echo "<td>" . $row["PricePerUnit"] . "</td>";
                    echo "<td><input type='number' name='quantity[]' min = '1' max = '" .$row["StockQty"] . "' value='". $row["CartQuantity"] . "' onChange=\"calculateTotalPrice(" . $row["PricePerUnit"] . ", this.value, 'total_" . $row["IDProduct"] . "')\"></td>";
                    echo "<td><span id='total_" . $row["IDProduct"] . "' class='totalPrice'>$subtotal</span></td>";
                    echo "<td><a href='../userControl/deleteProductCart.php?message=" . $row["IDProduct"] . "'>"; 
                    echo "<img src='../../pic/icon/deleted.png' alt='cart' style='width: 30px; height: 30px;'> &nbsp&nbsp&nbsp</td>";
                    echo "</tr>";
                }

                foreach ($product_ids as $product_id) {
                    echo "<input type='hidden' name='product_id[]' value='$product_id'>";
                }
                $vat = $totalPrice * 0.07;
                $grandTotal = $vat + $totalPrice;
                echo "</table><br>";
                echo "</div>";
                echo "<br><br><br><br><div class='bill'>";
                echo "<h2>สรุปรายการสั่งซื้อ</h2>";
                echo "<hr>";
                echo "<p><h3><span style='float: left;'>ราคารวม : </span><span style='float: right;'><span id='subtotal'>$totalPrice.00</span>&nbsp&nbsp&nbspบาท</span></h3><br></p>";
                echo "<p><h3><span style='float: left;'>ค่าขนส่ง : </span><span style='float: right;'>0.00 &nbsp&nbsp&nbspบาท</span></h3><br></p>";
                echo "<p><h3><span style='float: left;'>ภาษีมูลค่าเพิ่ม (VAT 7%) : </span><span style='float: right;'><span id='vat'>$vat</span>&nbsp&nbsp&nbspบาท</span></h3><br></p>";
                echo "<hr>";
                echo "<p><h2><span style='float: left;'>ราคารวมทั้งสิ้น : </span><span style='float: right;'><span id='totalOrderPrice'>$grandTotal</span>&nbsp&nbsp&nbspบาท</span></h2></p>";
                echo "<br><br><br>";
                echo "<center>";
                echo "<input type='submit' value='สั่งซื้อ'>";
                echo "</center></form>";
                echo "</div>";
            }
                ?>
            
            <br><br>
        </div>
    </body>
</html>
