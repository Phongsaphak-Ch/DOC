<?php
// เชื่อมต่อกับฐานข้อมูล
require_once '../userModel/connectDatabase.php';
require_once '../userModel/select.php';
$db = mysqli_connect($host, $user, $password, $database);
require_once '../JWT/JWTConnect.php';
// รับค่า category ที่ส่งมาจาก AJAX
$category = $_GET['category'];

// สร้าง query เพื่อดึงข้อมูลสินค้าตาม category
if ($category == 'all') {
    $query = "SELECT * FROM stock";
} else {
    $query = "SELECT * FROM stock WHERE typeID = '$category'";
}

if(isset($_GET['category'])) {
    $result = mysqli_query($db, $query);
    echo "<section>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<div class='card'>";
        echo "<div class='badge'>Hot</div>";
        echo "<div class='tump'>";
        echo "<a href='bookDetail.php?product_id=" . $row["IDProduct"] . "'>";
        echo "<div class='banner'><img src='" . $row["image_url"] . "' alt='Product Image' style='width: 150px; height: 200px;'></a></div></div>";
        echo "<h4><a href='bookDetail.php?product_id=" . $row["IDProduct"] . "'>ชื่อ : " . $row["ProductName"] . "</a></h4>";
        echo "ราคา : " . $row["PricePerUnit"] . "";
        echo "<p>จำนวนคงเหลือ : " . $row["StockQty"] . "</p></h4>";

        echo "<div class='button-container'>";
        echo "<form action='userOrder.php' method='post'>";
        echo "<input type='hidden' name='product_id' value='" . $row["IDProduct"] . "'>";
        echo "<input type='hidden' name='quantity' id='quantity_hidden' value='1'>";
        echo "<input type='submit' value='สั่งซื้อ'>";
        echo "</form></div>";

        echo "<div class='button-container'>";
        echo "<form action='../userControl/addToCart.php' method='post'>";
        echo "<input type='hidden' name='product_id' value='" . $row["IDProduct"] . "'>";
        echo "<input type='hidden' name='quantity' id='quantity_hidden' value='1'>";
        echo "<input type='submit' value='หยิบใส่รถเข็น'>";
        echo "</form></div>";
        echo "</div>";
    }
} else {
    $result = mysqli_query($db, "SELECT * FROM stock");
    echo "<section>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<div class='card'>";
        echo "<div class='badge'>Hot</div>";
        echo "<div class='tump'>";
        echo "<a href='bookDetail.php?product_id=" . $row["IDProduct"] . "'>";
        echo "<div class='banner'><img src='" . $row["image_url"] . "' alt='Product Image' style='width: 150px; height: 200px;'></a></div></div>";
        echo "<h4><a href='bookDetail.php?product_id=" . $row["IDProduct"] . "'>ชื่อ : " . $row["ProductName"] . "</a></h4>";
        echo "ราคา : " . $row["PricePerUnit"] . "";
        echo "<p>จำนวนคงเหลือ : " . $row["StockQty"] . "</p></h4>";

        echo "<div class='button-container'>";
        echo "<form action='userOrder.php' method='post'>";
        echo "<input type='hidden' name='product_id' value='" . $row["IDProduct"] . "'>";
        echo "<input type='hidden' name='quantity' id='quantity_hidden' value='1'>";
        echo "<input type='submit' value='สั่งซื้อ'>";
        echo "</form></div>";

        echo "<div class='button-container'>";
        echo "<form action='../userControl/addToCart.php' method='post'>";
        echo "<input type='hidden' name='product_id' value='" . $row["IDProduct"] . "'>";
        echo "<input type='hidden' name='quantity' id='quantity_hidden' value='1'>";
        echo "<input type='submit' value='หยิบใส่รถเข็น'>";
        echo "</form></div>";
        echo "</div>";
    }
}
echo "</section>";
?>
