<?php
    require_once '../userModel/connectDatabase.php';
    require_once '../userModel/select.php';
    require_once '../JWT/JWTConnect.php';
    $db = mysqli_connect($host, $user, $password, $database);
    $orderID = $_GET["orderID"];

    $error = isset($_GET['error']) ? $_GET['error'] : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="../userStyle/order.css">
  <script src="../userScript/order.js"></script>
</head>
<body>
<div class="area">
        <div class="circles">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </div>
        <div class="navBar"><center>
            <?php 
                $userModel = new UserModel($db);
                include_once 'userNavBar.php' 
            ?>
        </div><br><br><br><br>
        <?php
            date_default_timezone_set('Asia/Bangkok');
            echo "<form action='../userControl/reorderConfirm.php' method='post'>";
            $result = $userModel->getOrder($db, $orderID, basename(__FILE__));
            $cur = $result;
            include_once "userOrderTemplate.php"; 
                $totalOrderPrice = 0;
                $grandTotal=0;
                $idproduct = array();
                while ($row = mysqli_fetch_array($cur)) {
                    $totalPrice = $row["PricePerUnit"] * $row["Quantity"];
                    echo "<tr>";
                    echo '<td><img src="' . $row["image_url"] . '" alt="Product Image" style="width: 100px; height: 120px;"></td>';
                    echo "<td>" . $row["ProductName"] . "</td>";
                    echo "<td>" . $row["PricePerUnit"] . "</td>";
                    echo "<td><input type='number' name='quantity[]' min = '1' value='". $row["Quantity"] . "' onChange=\"calculateTotalPrice(" . $row["PricePerUnit"] . ", this.value, 'total_" . $row["IDProduct"] . "')\"></td>";
                    echo "<td><span id='total_" . $row["IDProduct"] . "' class='totalPrice'>$totalPrice</span></td>";
                    $idproduct[] = $row["IDProduct"];
                    echo "</tr>";
                    $totalOrderPrice += $totalPrice;
                }
                $vat = $totalOrderPrice * 0.07;
                $subTotal = $totalOrderPrice;
                $totalOrderPrice += $vat;
                echo "</table>";
                echo "<p style='text-align: right; font-weight: bold;'>Total Order Price: <span id='totalOrderPrice'>$totalOrderPrice</span> Baht (VAT 7%)</p>";
                echo "<p style='text-align: right; font-weight: bold;'>VAT: <span id='vat'>$vat</span> Baht</p>";
            
                include_once "userOrderFooter.php";
        ?>
        <center>
            <?php
                foreach ($idproduct as $product) {
                    echo "<input type='hidden' name='product_id[]' value='$product'>";
                }
                echo "<input type='hidden' name='orderID' value='$orderID'>";
                echo "<br><br><button type='submit' name='confirm'>ยืนยัน</button>&nbsp&nbsp&nbsp";
                echo "<button type='button' onclick=\"window.location.href='userHome.php';\">ยกเลิก</button>";
                echo "</form>";
            ?>
        </div><br><br><br></center>
    </div>
</body>
</html>
<script>
        document.querySelectorAll('input[name="payment_method"]').forEach(function(radio) {
            radio.addEventListener('change', function() {
                if (this.value === 'promptpay') {
                    document.getElementById('credit_card_info').style.display = 'block';
                } else {
                    document.getElementById('credit_card_info').style.display = 'none';
                }
            });
        });

        document.getElementById('tax').addEventListener('change', function() {
            var taxInfo = document.getElementById('tax-info');
            if (this.checked) {
                taxInfo.style.display = 'none';
                hideDeliveryAddress();
            } else {
                taxInfo.style.display = 'block';
                showDeliveryAddress();
            }
        });

        function hideDeliveryAddress() {
            document.getElementById('delivery-address').style.display = 'none';
        }

        function showDeliveryAddress() {
            document.getElementById('delivery-address').style.display = 'block';
        }
    </script>