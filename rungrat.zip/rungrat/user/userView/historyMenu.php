<div class="history">
    <h4>|&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <a href="historywait.php">คำสั่งซื้อรอการยืนยัน</a>
        |&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <a href="historyDelivery.php">คำสั่งซื้อที่รอจัดส่ง</a>
        |&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <a href="historyConfirm.php">คำสั่งซื้อที่ต้องได้รับ</a>
        |&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <a href="historyFinish.php">คำสั่งซื้อที่สำเร็จแล้ว</a>
        |&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <a href="historyCancel.php">คำสั่งซื้อที่ยกเลิกแล้ว</a>
        |&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
    </h4>
</div>