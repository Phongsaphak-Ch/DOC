<?php
    require_once '../userModel/connectDatabase.php';
    require_once '../userModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);

    require_once '../JWT/JWTConnect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="../userStyle/styles.css">
  <script src="../customerScript/script.js"></script>
</head>
<body>
<div class="area">
        <div class="circles">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </div>
        <div class="navBar"><center>
            <?php 
                $userModel = new UserModel($db);
                include_once 'userNavBar.php' 
            ?>
        </div><br><br><br><br>
        <?php 
            $id = $_GET['product_id'];
            $product = $userModel->getProductById($db, $id);
            $similarProducts = $userModel->getSimilarProducts($db, $id, $product["typeID"]);
            echo "<div class='grid-containers'>";
            echo "<div class='menu'>";
            echo "<img src='" . $product["image_url"] . "' alt='Product Image' style='width: 250px; height: 350px;'></div>";
            echo "<div class='main'>";
            echo "<h2>" . $product["ProductName"] ."</h2>";
            echo "<h3>รายละเอียด : <br>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp" . $product["details"] . "</h3></div>";
            echo "<div class='right'>";
            echo "<h3>ราคา : &nbsp&nbsp" . $product["PricePerUnit"] . "  บาท / เล่ม";
            echo "<h3>จำนวนคงเหลือ : &nbsp&nbsp" . (int)$product["StockQty"] . "  เล่ม</h3>";
            echo "<h3>จำนวนที่ซื้อ : &nbsp&nbsp<input type='number' id='quantity_input' name='quantity' value='1' min='1' max='".  (int)$product["StockQty"] . "'  onchange='updateQuantity()'> &nbsp&nbspเล่ม </h3><br><br><br><br>";            
            echo "<div class='button-container'>";
            echo "<form action='userOrder.php' method='post' id='order_form'>";
            echo "<input type='hidden' name='product_id' value='" . $product["IDProduct"] . "'>";
            echo "<input type='hidden' name='quantity' id='quantity_hidden_order' value='1'>";
            echo "<input type='submit' value='สั่งซื้อ'>";
            echo "</form></div>";
            
            echo "<form action='../userControl/addToCart.php' method='post' id='cart_form'>";
            echo "<input type='hidden' name='product_id' value='" . $product["IDProduct"] . "'>";
            echo "<input type='hidden' name='quantity' id='quantity_hidden' value='1'>";
            echo "<div class='button-container'>";
            echo "<input type='submit' value='หยิบใส่รถเข็น'>";
            echo "</form></div>";

            echo "</div>";
            echo "</div>";
            echo "<br>";
            echo "<center><h2><font color='#ffffff'>" . str_repeat("-", 50). ""; 
            echo "&nbsp&nbsp&nbspหนังสือที่คล้ายกัน&nbsp&nbsp&nbsp" . str_repeat("-", 50) . "</font></h2></center>";

            echo "<section>";
            $cnt=0;
            // $cur = $userModel->selectStarStockAll();
            while ($row = mysqli_fetch_array($similarProducts)) {
                if ($row["IDProduct"] == $id) {
                    continue;
                } if ($cnt >= 5) {
                    break;
                }
                $cnt++;
                echo "<div class='card'>";
                echo "<div class='badge'>Hot</div>";
                echo "<div class='tump'>";
                echo "<a href='bookDetail.php?product_id=" . $row["IDProduct"] . "'>";
                echo "<div class='banner'><img src='" . $row["image_url"] . "' alt='Product Image' style='width: 150px; height: 200px;'></a></div></div>";
                echo "<h4><a href='bookDetail.php?product_id=" . $row["IDProduct"] . "'>ชื่อ : " . $row["ProductName"] . "</a></h4>";
                echo "ราคา : " . $row["PricePerUnit"] . "";
                echo "<p>จำนวนคงเหลือ : " . $row["StockQty"] . "</p></h4>";

                echo "<div class='button-container'>";
                echo "<form action='userOrder.php' method='post'>";
                echo "<input type='hidden' name='product_id' value='" . $row["IDProduct"] . "'>";
                echo "<input type='hidden' name='quantity' id='quantity_hidden' value='1'>";
                echo "<input type='submit' value='สั่งซื้อ'>";
                echo "</form></div>";

                echo "<div class='button-container'>";
                echo "<form action='../customerModel/addToCart.php' method='post'>";
                echo "<input type='hidden' name='product_id' value='" . $row["IDProduct"] . "'>";
                echo "<input type='hidden' name='quantity' id='quantity_hidden' value='1'>";
                echo "<input type='submit' value='หยิบใส่รถเข็น'>";
                echo "</form></div>";

                echo "</div>";
            }
            echo "</section>";
            mysqli_close($db);
        ?>
    </div>

<script>
function updateQuantity() {
    var quantity = document.getElementById("quantity_input").value;
    document.getElementById("quantity_hidden").value = quantity;
    document.getElementById("quantity_hidden_order").value = quantity;
    var maxQuantity = <?php echo (int)$product["StockQty"]; ?>;
  
    if (quantity > maxQuantity) {
        alert("จำนวนที่ระบุมากกว่าจำนวนคงเหลือ");
        document.getElementById("quantity_input").value = maxQuantity; // กำหนดให้ค่าที่ระบุเป็น max
        quantity = maxQuantity; // อัพเดทค่า quantity เป็น max
    }

    document.getElementById("quantity_hidden").value = quantity;
    document.getElementById("quantity_hidden_order").value = quantity;

    // ตรวจสอบว่าจำนวนที่ระบุมากกว่า max หรือไม่ และเปิด/ปิดปุ่มตามเงื่อนไข
    var addToCartButton = document.getElementById("cart_form").querySelector("input[type='submit']");
    var orderButton = document.getElementById("order_form").querySelector("input[type='submit']");
  
    if (quantity > maxQuantity || maxQuantity == 0) {
        addToCartButton.disabled = true;
        orderButton.disabled = true;
    } else {
        addToCartButton.disabled = false;
        orderButton.disabled = false;
    }
}
</script>

</body>
</html>

