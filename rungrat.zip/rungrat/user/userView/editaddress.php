<?php
    require_once '../userModel/connectDatabase.php';
    require_once '../userModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);

    require_once '../JWT/JWTConnect.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="../userStyle/order.css">
  <script src="../userScript/order.js"></script>
</head>
<body>
    <div class="area">
        <div class="circles">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </div>
        <div class="navBar"><center>
            <?php 
                $userModel = new UserModel($db);
                include_once 'userNavBar.php' 
            ?>
        </div><br><br><br><br>
        <center>
        <h1><font color='#fff'><br>แก้ไขข้อมูล<br></font></h1>
        <div class="container">
        <form action="../userControl/updateOrder.php" method="post">
        <?php
        if (isset($_GET['orderID'])) {
            $orderID = $_GET['orderID'];
            $orderRow = $userModel->orderRow($db, $orderID);

            // Display order information
            echo "<p><span style='float: left;'>Order ID: &nbsp&nbsp</span>" . $orderRow['OrderID'] . "</span></p>";
            echo "<p><span style='float: left;'>Customer ID: &nbsp&nbsp</span>" . $orderRow['IDCust'] . "</span></p>";
            echo "<p><span style='float: left;'>Customer name: &nbsp&nbsp</span><input type='text' name='name' value='" . $orderRow['CustName'] . "'>&nbsp&nbsp&nbsp&nbsp&nbsp<input type='text' name='lastname' value='". $orderRow['lastName'] . "'></span></p>";
            echo "<p><span style='float: left;'>Customer address: &nbsp&nbsp</span><input type='text' name='address' value='" . $orderRow['address'] . "'></span></p>";
            echo "<p><span style='float: left;'>Customer Email: &nbsp&nbsp</span><input type='email' name='email' value='" . $orderRow['email'] . "'></span></p>";
            echo "<p><span style='float: left;'>Payment Method: &nbsp&nbsp</span>" . $orderRow['paymentMethod'] . "</span></p>";
            echo "<p><span style='float: left;'>Tel: &nbsp&nbsp</span><input type='tel' name='tel' value='" . $orderRow['tel'] . "'></span></p>";

            echo "<p>Order Date: &nbsp&nbsp" . $orderRow['OrderDate'] . "</p>";

            echo "<style>";
            echo "table { border-collapse: collapse; }";
            echo "table, th, td { border: 1px solid #ecf0f1; }";
            echo "</style>";

            // Display ordered items
            echo "<center>";
            echo "<table>";
            echo "<tr>";
            echo "<th>รูปสินค้า</th>";
            echo "<th>ชื่อสินค้า</th>";
            echo "<th>ราคาต่อชิ้น</th>";
            echo "<th>จำนวน</th>";
            echo "<th>ราคารวม</th>";
            echo "</tr>";

            $totalOrderPrice = 0; // Initialize total order price
            $orderItemsQuery = $userModel->itemsQuery($db, $orderID);
            while ($row = mysqli_fetch_assoc($orderItemsQuery)) {
                $productID = $row['IDProduct'];
                $productQuery = $userModel->productQuery($db, $productID);
                $productRow = mysqli_fetch_assoc($productQuery);
                $totalPrice = $row["PricePerUnit"] * $row["Quantity"];
                echo "<input type='hidden' name='productID[]' value='". $productRow["IDProduct"] ."'>";
                echo "<tr>";
                echo '<td><img src="' . $productRow["image_url"] . '" alt="Product Image" style="width: 100px; height: 120px;"></td>';
                echo "<td>" . $productRow["ProductName"] . "</td>";
                echo "<td>" . $row["PricePerUnit"] . "</td>";
                echo "<td><input type='number' name='quantity[]' min = '1' max = '". $productRow["StockQty"] . "' value='". $row["Quantity"] . "' onChange=\"calculateTotalPrice(" . $row["PricePerUnit"] . ", this.value, 'total_" . $productRow["IDProduct"] . "')\"></td>";
                echo "<td><span id='total_" . $productRow["IDProduct"] . "' class='totalPrice'>$totalPrice</span></td>";
                echo "</tr>";
                $totalOrderPrice += $totalPrice;
            }
            $vat = $totalOrderPrice * 0.07;
            $totalOrderPrice += $vat;

            echo "</table>";

            // Display total order price
            echo "<p style='text-align: right; font-weight: bold;'>Total Order Price: <span id='totalOrderPrice'>$totalOrderPrice</span> Baht(VAT 7%)</p>";
        }
        mysqli_close($db);
        ?>
            <input type="hidden" name="orderID" value='<?php echo $orderID;?>'>
            <div class="button-container">
                <button type="submit" name='confirm' value="ยืนยัน">ยืนยัน</button>&nbsp&nbsp&nbsp
                <?php
                    echo "<button type='button' onclick=\"window.location.href='historywait.php';\">ยกเลิก</button>";
                ?>
            </div>
        </form>
        </div>
        <br><br><br><br><br><br><br><br><br>
    </div>
</body>
</html>
