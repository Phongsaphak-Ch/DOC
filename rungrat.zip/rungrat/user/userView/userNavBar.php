<form action="../userView/userHomeQuery.php" method="get">
    <div style="margin: 0; display: flex; align-items: center;"> 
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <a href="../userView/userHome.php" style="color: #000;">Home</a>
        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <input type="text" name="query" placeholder="Search..."> 
        &nbsp&nbsp
        <button type="submit">Search</button>
        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp

        <a href="../userView/userCart.php"><img src='../../pic/icon/cart.png' alt='cart' style='width: 30px; height: 30px;'></a>
        <a href="../userView/userCart.php">&nbsp&nbsp&nbspรถเข็น </a>
        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <?php  
            $cur = $userModel->selectCustName($id);
            $row = $cur->fetch_assoc();
        ?>
        <div class="dropdown">
        <?php
            if ($login_method === 'line') {
                $profile = $decoded->data->profile;
                echo "<img src='" . $profile->picture . "' class='rounded' alt='profile picture' style='width: 35px; height: 35px;'>&nbsp&nbsp&nbsp" . $row["CustName"];
            }
            else if ($login_method === '0' || $login_method === 'google'){
                echo "<img src='../../pic/icon/user.png' alt='cart' style='width: 30px; height: 30px;'> &nbsp;&nbsp;&nbsp;" . $row["CustName"];
            }else {
                echo "<img src='../../pic/icon/user.png' alt='cart' style='width: 30px; height: 30px;'> &nbsp;&nbsp;&nbsp; guest";
            }
                
        ?>
            <div class="dropdown-content">
            <h4><a href="historywait.php">ดูประวัติการสั่งซื้อ</a>
                <a href="../userControl/logout.php">ออกจากระบบ</h4></a>
            </div>
        </div>
    </div>
</form></center>