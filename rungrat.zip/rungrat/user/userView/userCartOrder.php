<?php
    require_once '../userModel/connectDatabase.php';
    require_once '../userModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);

    require_once '../JWT/JWTConnect.php';
    
    $error = isset($_GET['error']) ? $_GET['error'] : '';
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="../userStyle/order.css">
  <script src="../userScript/order.js"></script>
</head>
<body>
<div class="area">
        <div class="circles">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </div>
        <div class="navBar"><center>
            <?php 
                $userModel = new UserModel($db);
                include_once 'userNavBar.php' 
            ?>
        </div><br><br><br><br>
        <?php
            date_default_timezone_set('Asia/Bangkok');
            echo "<form action='../userControl/cartConfirm.php' method='post'>";
            $result = $userModel->getCartItems($db, $id, basename(__FILE__));
            $cur = $result;
            include_once "userOrderTemplate.php";
            $grandTotal=0;
            $idproduct = array();
                while ($row = mysqli_fetch_array($cur)) {
                    $totalPrice = $row["PricePerUnit"] * $row["CartQuantity"];
                    echo "<tr>";
                    echo '<td><img src="' . $row["image_url"] . '" alt="Product Image" style="width: 100px; height: 120px;"></td>';
                    echo "<td>" . $row["ProductName"] . "</td>";
                    echo "<td>" . $row["PricePerUnit"] . "</td>";
                    echo "<td><input type='number' name='quantity[]' min = '1' max = '" . $row["StockQty"] . "'  value='". $row["CartQuantity"] . "' onChange=\"calculateTotalPrice(" . $row["PricePerUnit"] . ", this.value, 'total_" . $row["IDProduct"] . "')\"></td>";
                    echo "<td><span id='total_" . $row["IDProduct"] . "' class='totalPrice'>$totalPrice</span></td>";
                    echo "</tr>";
                    $idproduct[] = $row["IDProduct"];
                    $grandTotal += $totalPrice;
                }
                $vat = $grandTotal * 0.07;
                $subTotal = $grandTotal;
                $grandTotal += $vat;
                echo "</table>";
                echo "<span style='float: right;'><h2>รวมทั้งสิ้น&nbsp&nbsp&nbsp&nbsp<span id='totalOrderPrice'>$grandTotal</span>&nbsp&nbsp&nbsp&nbspบาท</h2>(vat 7%&nbsp&nbsp&nbsp<span id='vat'>$vat</span>&nbsp&nbsp&nbspบาท)</span>";
                include_once "userOrderFooter.php";
                ?>
                <center>
                <?php
                    foreach ($idproduct as $product) {
                        echo "<input type='hidden' name='product_id[]' value='$product'>";
                    }
                    echo "<br><br><button type='submit' name='confirm'>ยืนยัน</button>&nbsp&nbsp&nbsp";
                    echo "<button type='button' onclick=\"window.location.href='userCart.php';\">ยกเลิก</button>";
                    echo "<input type='hidden' name='grandtotal' value='$grandTotal'>";
                    echo "<input type='hidden' name='subTotal' value='$subTotal'>";
                    echo "<input type='hidden' name='vat' value='$vat'>";
                    echo "</form>";
                ?>
                </div><br><br><br></center>

    </div>
</body>
</html>

<script>
    document.querySelectorAll('input[name="payment_method"]').forEach(function(radio) {
        radio.addEventListener('change', function() {
            if (this.value === 'promptpay') {
                document.getElementById('credit_card_info').style.display = 'block';
            } else {
                document.getElementById('credit_card_info').style.display = 'none';
            }
        });
    });

    document.getElementById('tax').addEventListener('change', function() {
        var taxInfo = document.getElementById('tax-info');
        // ถ้า checkbox ถูกเลือก
        if (this.checked) {
            taxInfo.style.display = 'none'; // แสดงข้อมูลที่อยู่ในใบกำกับภาษี
            hideDeliveryAddress(); // ซ่อนข้อมูลที่อยู่ในการจัดส่ง
        } else {
            taxInfo.style.display = 'block'; // ซ่อนข้อมูลที่อยู่ในใบกำกับภาษี
            showDeliveryAddress(); // แสดงข้อมูลที่อยู่ในการจัดส่ง
        }
    });

    // ซ่อนข้อมูลที่อยู่ในการจัดส่ง
    function hideDeliveryAddress() {
        document.getElementById('delivery-address').style.display = 'none';
    }

    // แสดงข้อมูลที่อยู่ในการจัดส่ง
    function showDeliveryAddress() {
        document.getElementById('delivery-address').style.display = 'block';
    }
</script>