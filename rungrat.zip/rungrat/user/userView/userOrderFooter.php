</center>
<br><br><br><h2>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspวิธีการชำระเงิน : </h2>
<?php if ($error === 'invalidPayment'): ?>
    <br><span style="color: red;">กรุณาเลือกวิธีการชำระเงิน</span>
<?php endif; ?>
<h3>&nbsp&nbsp&nbsp&nbsp<input type="radio" id="credit_card" name="payment_method" value="promptpay">
<label for="credit_card">พร้อมเพย์</label><br><br>
<div id="credit_card_info" style="display: none;">
    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspหมายเลขพร้อมเพย์: 08123456789<br><br>
</div>
&nbsp&nbsp&nbsp&nbsp<input type="radio" id="cash_on_delivery" name="payment_method" value="cash_on_delivery">
<label for="cash_on_delivery">ชำระเงินปลายทาง</label><br><br>

</h3>