<?php 

function historyView($callerFileName, $orderQuery, $db){
    while ($orderRow = mysqli_fetch_assoc($orderQuery)) {
        echo "<div class='order'>";
        echo "<p><span style='float: left;'>Order ID: &nbsp&nbsp</span>" . $orderRow['OrderID'] . "</p>";
        echo "<p><span style='float: left;'>Customer ID: &nbsp&nbsp</span>" . $orderRow['IDCust'] . "</p>";
        echo "<p><span style='float: left;'>Customer name: &nbsp&nbsp</span>" . $orderRow['CustName'] . "&nbsp&nbsp&nbsp&nbsp&nbsp". $orderRow['lastName'] . "</p>";
        echo "<p><span style='float: left;'>Customer address: &nbsp&nbsp</span>" . $orderRow['address'] . "</p>";
        echo "<p><span style='float: left;'>Payment Method: &nbsp&nbsp</span>" . $orderRow['paymentMethod'] . "</p>";
        echo "<p><span style='float: left;'>Tel: &nbsp&nbsp</span>" . $orderRow['tel'] . "</p>";
        echo "<p>Order Date: &nbsp&nbsp" . $orderRow['OrderDate'] . "</p>";

        // Fetch ordered items for each order
        echo "<style>";
        echo "table { border-collapse: collapse; }";
        echo "table, th, td { border: 1px solid #ecf0f1; }";
        echo "</style>";

        // Display ordered items
        echo "<center>";
        echo "<table>";
        echo "<tr>";
        echo "<th>รูปสินค้า</th>";
        echo "<th>ชื่อสินค้า</th>";
        echo "<th>ราคาต่อชิ้น</th>";
        echo "<th>จำนวน</th>";
        echo "<th>ราคารวม</th>";
        echo "</tr>";

        $totalOrderPrice = 0; // Initialize total order price
        $orderID = $orderRow['OrderID'];
        $userModel = new UserModel($db);
        $orderItemsQuery = $userModel->itemsQuery($db, $orderID);
        while ($row = mysqli_fetch_assoc($orderItemsQuery)) {
            $productID = $row['IDProduct'];
            $productQuery = $userModel->productQuery($db, $productID);
            $productRow = mysqli_fetch_assoc($productQuery);
            $totalPrice = $row["PricePerUnit"] * $row["Quantity"];
            echo "<tr>";
            echo '<td><img src="' . $productRow["image_url"] . '" alt="Product Image" style="width: 100px; height: 120px;"></td>';
            echo "<td>" . $productRow["ProductName"] . "</td>";
            echo "<td>" . $row["PricePerUnit"] . "</td>";
            echo "<td>" . $row["Quantity"] . "</td>";
            echo "<td>$totalPrice</td>";
            echo "</tr>";
            $totalOrderPrice += $totalPrice; // Add the item's total price to the overall total
        }

        echo "</table>";
        echo "<p style='text-align: right; font-weight: bold;'>Total Order Price: " . $orderRow['totalPrice'] . " Baht(VAT 7%)</p>";
        if ($callerFileName === "historywait.php") {
            echo "<form action='editaddress.php?OrderID=$orderID' method='get'>";
            echo "<input type='hidden' name='orderID' value='" . $orderRow['OrderID'] . "'>";
            echo "<br><br><button type='submit' name='edit'>แก้ไข</button>";
            echo "</form>";
    
            echo "<form action='../userControl/deleteOrder.php?OrderID=$orderID' method='get'>";
            echo "<input type='hidden' name='orderID' value='" . $orderRow['OrderID'] . "'>";
            echo "<button type='submit' name='delete'>ยกเลิกคำสั่งซื้อ</button>";
            echo "</form>";
        } else if ($callerFileName === "historyConfirm.php"){
            echo "<form action='../userControl/finish.php?OrderID=$orderID' method='get'>";
            echo "<input type='hidden' name='orderID' value='" . $orderRow['OrderID'] . "'>";
            echo "<br><br><button type='submit' name='confirm'>ได้รับสินค้าแล้ว</button>";
            echo "</form>";
        } else if ($callerFileName === "historyFinish.php" || $callerFileName === "historyCancel.php"){
            echo "<form action='../userView/userReorder.php?OrderID=$orderID' method='get'>";
            echo "<input type='hidden' name='orderID' value='" . $orderRow['OrderID'] . "'>";
            echo "<br><br><button type='submit' name='reorder'>สั่งซื้ออีกครั้ง</button>";
            echo "</form>";
        }
        echo "<hr><br></div>";
    }
}
?>