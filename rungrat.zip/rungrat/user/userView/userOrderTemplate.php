<center>
    <h1><font color='#fff'><br>สั่งซื้อสินค้า<br></font></h1>
    <div class="container"><h2>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspข้อมูลที่อยู่การจัดส่ง : </h2><h4>
        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        ชื่อ :&nbsp&nbsp&nbsp<input type="text" name='name' placeholder="name" value="<?php echo isset($row['CustName']) ? $row['CustName'] : ''; ?>" required>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        นามสกุล :&nbsp&nbsp&nbsp<input type="text" name='lastname' placeholder="lastname" value="<?php echo isset($row['CustName']) ? $row['CustName'] : ''; ?>" required><br><br>
        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        อีเมล :&nbsp&nbsp<input type="email" name="email" placeholder="example@gmail.com" value="<?php echo isset($row['Email']) ? $row['Email'] : ''; ?>" required>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        เบอร์โทร :&nbsp&nbsp<input type="tel" name="tel" placeholder="123-456-7890" value="<?php echo isset($row['Tel']) ? $row['Tel'] : ''; ?>" required><br><br>        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        <?php
        $address_value = isset($row["Address"]) ? $row["Address"] : "";
        $address_placeholder = isset($row["Address"]) ? $row["Address"] : "ที่อยู่ของคุณ";
        ?>

        ที่อยู่ :&nbsp&nbsp&nbsp<input type="text" name="address" value="<?php echo $address_value ?>" placeholder="<?php echo $address_placeholder ?>"><br>


        <h2>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspที่อยู่ออกใบกำกับภาษี : </h2><h4>
        <!-- &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp -->
        <?php if ($error === 'invalidTax'): ?>
            <br><span style="color: red;">กรุณากรอกข้อมูลให้ครบ</span>
        <?php endif; ?>
        <h3>&nbsp&nbsp&nbsp&nbsp<input type="checkbox" id="tax" name="tax" value="tax" checked>
        <label for="tax">ที่อยู่เดียวกันกับจัดส่ง</label><br><br>
        <div id="tax-info" style="display: none;">
        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspชื่อ :&nbsp&nbsp&nbsp<input type="text" name='taxname' placeholder="<?php echo $row["CustName"]?>" >&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        นามสกุล :&nbsp&nbsp&nbsp<input type="text" name='taxlastname' placeholder="<?php echo $row["CustName"]?>" ><br><br>
        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        อีเมล :&nbsp&nbsp<input type="email" name='taxemail' placeholder="example@gmail.com" >&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        เบอร์โทร :&nbsp&nbsp&nbsp<input type="tel" name='taxtel' placeholder="123-456-7890" ><br><br>
        &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp
        ที่อยู่ :&nbsp&nbsp&nbsp<input type="text" name='taxaddress' placeholder="ที่อยู่ของคุณ" ><br></h4>
        <h2>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspรายละเอียดสินค้า :</h2>
            <center>
            <table>
            <tr>
            <th>รูปสินค้า</th>
            <th>ชื่อสินค้า</th>
            <th>ราคาต่อชิ้น</th>
            <th>จำนวน</th>
            <th>ราคารวม</th>
            </tr>


            <script>
        document.querySelectorAll('input[name="payment_method"]').forEach(function(radio) {
            radio.addEventListener('change', function() {
                if (this.value === 'promptpay') {
                    document.getElementById('credit_card_info').style.display = 'block';
                } else {
                    document.getElementById('credit_card_info').style.display = 'none';
                }
            });
        });

        document.getElementById('tax').addEventListener('change', function() {
            var taxInfo = document.getElementById('tax-info');
            if (this.checked) {
                taxInfo.style.display = 'none'; // ซ่อนข้อมูลที่อยู่ในใบกำกับภาษี
                hideDeliveryAddress(); // แสดงข้อมูลที่อยู่ในการจัดส่ง
                // ตั้งค่าให้ทุกช่องใน tax-info เป็นไม่ required
                document.querySelectorAll('tax-info input').forEach(function(input) {
                    input.removeAttribute('required');
                });
            } else {
                taxInfo.style.display = 'block'; // แสดงข้อมูลที่อยู่ในใบกำกับภาษี
                showDeliveryAddress(); // ซ่อนข้อมูลที่อยู่ในการจัดส่ง
                // ตั้งค่าให้ทุกช่องใน tax-info เป็น required
                document.querySelectorAll('tax-info input').forEach(function(input) {
                    input.setAttribute('required', '');
                });
            }
        });

        function hideDeliveryAddress() {
            document.getElementById('delivery-address').style.display = 'none';
        }

        function showDeliveryAddress() {
            document.getElementById('delivery-address').style.display = 'block';
        }
    </script>
