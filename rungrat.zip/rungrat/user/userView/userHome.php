<?php
    require_once '../userModel/connectDatabase.php';
    require_once '../userModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);

    require_once '../JWT/JWTConnect.php';
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="../userStyle/styles.css">
</head>
<body>
    <div class="area">
        <div class="circles">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </div>
        <div class="navBar"><center>
            <?php 
                $userModel = new UserModel($db);
                include_once 'userNavBar.php' 
            ?>

<form>
    <label for="category">เลือกหมวดหมู่สินค้า:</label>
    <select name="category" id="category">
        <option value="all" selected>ทั้งหมด</option>
        <?php
        $type_query = "SELECT * FROM stocktype";
        $type_result = mysqli_query($db, $type_query);
        while($type_row = mysqli_fetch_assoc($type_result)) {
            echo "<option value='" . $type_row['typeID'] . "'>" . $type_row['typeName'] . "</option>";
        }
        ?>
    </select>
</form>


        </div><br><br><br><br><br>
        <section>
            <div id="product-list">
                <!-- สินค้าที่ถูกดึงจะแสดงที่นี่ -->
            </div>
        </section> 
    </div>
</body>
</html>


<!-- เพิ่ม JavaScript -->
<script>
    document.getElementById('category').addEventListener('change', function() {
        var category = this.value; // รับค่าหมวดหมู่ที่เลือก
        var productList = document.getElementById('product-list'); // เลือก div ที่จะแสดงผลลัพธ์

        // สร้าง XMLHttpRequest object
        var xhr = new XMLHttpRequest();
        xhr.open('GET', 'getProducts.php?category=' + category, true);

        // เมื่อ XMLHttpRequest เสร็จสิ้น
        xhr.onload = function() {
            if (xhr.status == 200) {
                // แทรก HTML ที่ได้รับมาลงใน div
                productList.innerHTML = xhr.responseText;
            }
        };

        // ส่งคำขอ
        xhr.send();
    });

    // เรียกฟังก์ชันเพื่อแสดงสินค้าทั้งหมดเมื่อหน้าเว็บโหลดเสร็จ
    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('category').value = 'all';
        document.getElementById('category').dispatchEvent(new Event('change'));
    });
</script>