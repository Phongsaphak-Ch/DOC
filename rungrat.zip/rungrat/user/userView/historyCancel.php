<?php
    require_once '../userModel/connectDatabase.php';
    require_once '../userModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);

    require_once '../JWT/JWTConnect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="../userStyle/history.css">
</head>
<body>
    <div class="area">
        <div class="circles">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
        </div>
        <div class="navBar"><center>
            <?php 
                $userModel = new UserModel($db);
                include_once 'userNavBar.php' 
            ?>
        </div><br><br><br><br>
        <center><br><br>
        <?php include_once "historyMenu.php"; ?>
        <h1><font color='#fff'><br>คำสั่งซื้อที่ยกเลิกแล้ว<br></font></h1>
        <div class="container">
        <?php
        $orderQuery = $userModel->getHistory($db, "cancel", $id);
        if (mysqli_num_rows($orderQuery) == 0) {
            echo "<p><center><h2>ไม่มีคำสั่งซื้อที่ยกเลิก</h2></center></p>";
        } else {
            include_once "historyView.php";
            historyView(basename(__FILE__), $orderQuery, $db);
        }

        mysqli_close($db);
        ?>
        </div>
        <br><br><br>
    </div>
</body>
</html>
