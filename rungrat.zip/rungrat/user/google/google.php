<?php
    require_once '../../vendor/autoload.php';

    // init configuration
    $clientID = '809558311878-m3lu1j7dld5cpg10i39vhlg2v2cg9e2m.apps.googleusercontent.com';
    $clientSecret = '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';
    $redirectUri = 'http://localhost:8080/work/user/google/google.php';

    // create Client Request to access Google API
    $client = new Google_Client();
    $client->setClientId($clientID);
    $client->setClientSecret($clientSecret);
    $client->setRedirectUri($redirectUri);
    $client->addScope("email");
    $client->addScope("profile");

    if (isset($_GET['code'])) {
        $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);
        $client->setAccessToken($token['access_token']);

        // get profile info
        $google_oauth = new Google_Service_Oauth2($client);
        $google_account_info = $google_oauth->userinfo->get();
        $email =  $google_account_info->email;
        $name =  $google_account_info->name;
        header("Location: ../userControl/authUserSSO.php?name=$name&email=$email");
        exit();
    }
?>