<?php 
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/select.php';
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
    $id = $_GET['message']; 
    $db = mysqli_connect($host, $user, $password, $database);
    $adminModel = new adminModel($db);
    $row = $adminModel->getStockData($db, $id);

    echo "<label for='productImage'>Product Image:</label>";
    echo "<input type='file' name='productImage' id='productImage' accept='image/*' value='" . $row["image_url"] . "'>";

    echo "<label for='productCode'>Product Code: " . $row['IDProduct']; "</label>";
    echo "<input type='hidden' name='IDProduct' id='IDProduct' value='" . $row["IDProduct"] . "' required>";

    echo "<label for='productName'><br>Product Name:</label>";
    echo "<input type='text' name='ProductName' id='ProductName' value='" . $row["ProductName"] . "' required>";

    echo "<label for='productPrice'>Product Price:</label>";
    echo "<input type='number' name='PricePerUnit' id='productPrice' step='0.01' value='" . $row["PricePerUnit"] . "' required>";

    echo "<label for='productQuantity'>Product Quantity:</label>";
    echo "<input type='number' name='StockQty' id='StockQty' placeholder='จำนวนที่ต้องการเพิ่มเข้า'>";

    echo "<label for='productDetails'>Product Details:</label>";
    echo "<textarea name='detail' id='detail' rows='4' required>" . $row["details"] . "</textarea>";

?>