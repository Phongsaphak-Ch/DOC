<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/select.php';
    require_once '../adminModel/update.php';
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
    $db = mysqli_connect($host, $user, $password, $database);
    $adminModel = new adminModel($db);
    $adminUpdateModel = new adminUpdateModel($db);
    $orderID = $_GET["orderID"];
    $status = "cancel";
    $result =  $adminUpdateModel->updateOrderStatus($db, $orderID, $status);
    if($result) {
    $orderItems = $adminModel->getOrderItems($db, $orderID);

    // ลูปเพื่ออัปเดต StockQty ในตาราง stock
    foreach ($orderItems as $orderItem) {
        $productID = $orderItem['IDProduct'];
        $quantityCancelled = $orderItem['Quantity'];

        // ดึงข้อมูลจำนวนสินค้าที่มีอยู่ในสต็อก
        $currentStock = $adminModel->getStockQty($db, $productID);

        // คำนวณจำนวนสินค้าใหม่ในสต็อก
        $newStockQty = $currentStock + $quantityCancelled;

        // อัปเดต StockQty ในตาราง stock
        $updateResult = $adminUpdateModel->updateStockQuantity($db, $productID, $newStockQty);
    }

    // echo "ลบสินค้าออกจากรถเข็นสำเร็จ";
    mysqli_close($db);
    // ส่งกลับไปยังหน้าตะกร้าหลักหลังจากทำการลบสินค้า
    header("Location: ../adminView/adminOrdernotConfirm.php");
} else {
    echo "เกิดข้อผิดพลาดในการลบสินค้าออกจากรถเข็น";
}
?>