<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/insert.php';
    require_once '../adminModel/select.php';
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
    $db = mysqli_connect($host, $user, $password, $database);

$product_name = $_POST['productName']; 
$product_price = $_POST['productPrice'];
$product_qty = $_POST['productQuantity'];
$product_detail = $_POST['productDetails'];

$adminModel = new adminModel($db);
$adminInsertModel = new adminInsertModel($db);

// จัดการอัพโหลดไฟล์รูปภาพ
$image_name = $_FILES['productImage']['name'];  
$tmp_image = $_FILES['productImage']['tmp_name'];
$image_error = $_FILES['productImage']['error'];

if($image_error === 0){
  $image_path = "../../pic/book/" . $image_name;  
  move_uploaded_file($tmp_image, $image_path); 
}

$typeid = $_POST['adminType'];
if ($typeid === 'T') {
    $new_type_name = $_POST['newType'];
    $get_last_id_result = $adminModel->getLastStockType($db);
    if (mysqli_num_rows($get_last_id_result) > 0) {
      $last_row = mysqli_fetch_assoc($get_last_id_result);
      $last_id = $last_row['typeID'];
      $numeric_part = (int)substr($last_id, 1);
      $next_numeric_part = $numeric_part + 1;
      $next_numeric_part_padded = str_pad($next_numeric_part, 3, '0', STR_PAD_LEFT);
      $typeid = 'T' . $next_numeric_part_padded;
    } else {
      $typeid = 'T001';
    }

    $result = $adminInsertModel->insertStockType($db, $typeid, $new_type_name);
}

$get_last_id_result = $adminModel->getLastStock($db);

if (mysqli_num_rows($get_last_id_result) > 0) {
  $last_row = mysqli_fetch_assoc($get_last_id_result);
  $last_id = $last_row['IDProduct'];
  $numeric_part = (int)substr($last_id, 1);
  $next_numeric_part = $numeric_part + 1;
  $next_numeric_part_padded = str_pad($next_numeric_part, 3, '0', STR_PAD_LEFT);
  $product_id = 'P' . $next_numeric_part_padded;
} else {
  $product_id = 'P001';
}

// เตรียมและประมวลผลคําสั่ง SQL
$result = $adminInsertModel->insertStock($db, $product_id, $product_name, $product_price, 
                      $product_qty, $product_detail, $image_path, '0', $typeid);

if($result){
  // $message = "Insert product successfully";
}else{
  //$message = "Insert product failed";    
}

// ปิดการเชื่อมต่อ
$db->close();

// ส่งกลับไปยังหน้าแสดงผล
header("Location: ../adminView/adminProduct.php?");  
?>