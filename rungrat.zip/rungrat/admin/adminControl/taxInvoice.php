<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);
    require_once '../JWT/JWT.php';
?>
<style>
    .printed {
        color: #bc544b;
    }

    .not-printed {
        color: blue;
    }
</style>
<label for="productDetails">สถานะ :</label>
<select name="adminType" id="print" onChange="onChangeType()">
    <option value="0" selected>ยังไม่ปรินต์</option>
    <option value="1">ปรินต์แล้ว</option>
    <option value="all">ทั้งหมด</option>
</select>
<?php
$adminModel = new adminModel($db);
echo "<div id='report_table'></div>";
echo "<div style='text-align: left;'>";

echo "<form>";
echo "<input type='checkbox' id='checkbox1' name='checkbox1' value='checkbox1'>";
echo "<label for='checkbox1'>Check All</label><br>";
echo "</form>";
echo date("d-M-Y H:i:s") . ".<br>";

echo "</div><br>";

mysqli_close($db);
?>

<script>
    function toggleCheckboxes() {
        var checkboxes = document.querySelectorAll('input[name="checkbox_name"]');
        var checkAllCheckbox = document.getElementById('checkbox1');

        for (var i = 0; i < checkboxes.length; i++) {
            checkboxes[i].checked = checkAllCheckbox.checked;
        }
    }
    document.getElementById('checkbox1').addEventListener('click', toggleCheckboxes);

    function onChangeType() {
        var print = document.getElementById("print").value;

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("report_table").innerHTML = this.responseText;
            }
        };

        var url = "../adminControl/fetch_taxInvoice.php?" + "print=" + print;
        xhttp.open("GET", url, true);
        xhttp.send();
    }

    function loadRe() {
        onChangeType();
    }
</script>