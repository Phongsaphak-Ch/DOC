<?php
require_once '../adminModel/connectDatabase.php';
require_once '../adminModel/update.php';
require_once '../JWT/JWT.php';
if ($super == '0') {
    header("Location: ../adminControl/logout.php");
    exit();
}
$db = mysqli_connect($host, $user, $password, $database);
$adminUpdateModel = new adminUpdateModel($db);
$a1 = $_POST['IDCust'];
$a2 = $_POST['CustName'];
$a4 = $_POST['Address'];
$a5 = $_POST['Tel'];

$result = $adminUpdateModel->updateCustomer($db, $a1, $a2, $a4, $a5);

if (!$result) {
    echo '<div class="error">Error: Unable to update data</div>';
} else {
    echo '<div class="success">Update data: <span style="color: red;">' . $a1 . '</span> is Successful!</div>';

    header("refresh:3;url=../adminView/adminCustomer.php");
}
mysqli_close($db);
?>
