<?php    
function displayOrderDetails($orderRow, $db, $callerFileName, $super) {
    $adminModel = new adminModel($db);
    echo "<div class='order'>";
    echo "<p><span style='float: left;'>Order ID: &nbsp&nbsp</span>" . $orderRow['OrderID'] . "</p>";
    echo "<p><span style='float: left;'>Customer ID: &nbsp&nbsp</span>" . $orderRow['IDCust'] . "</p>";
    echo "<p><span style='float: left;'>Customer name: &nbsp&nbsp</span>" . $orderRow['CustName'] . "&nbsp&nbsp&nbsp&nbsp&nbsp". $orderRow['lastName'] . "</p>";
    echo "<p><span style='float: left;'>Customer address: &nbsp&nbsp</span>" . $orderRow['address'] . "</p>";
    echo "<p><span style='float: left;'>Payment Method: &nbsp&nbsp</span>" . $orderRow['paymentMethod'] . "</p>";
    echo "<p><span style='float: left;'>Tel: &nbsp&nbsp</span>" . $orderRow['tel'] . "</p>";
    echo "<p><span style='float: left;'>Payment Status: &nbsp&nbsp</span>" . $orderRow['paymentStatus'] . "</p>";
    echo "<p>Order Date: &nbsp&nbsp" . $orderRow['OrderDate'] . "</p>";

    // Fetch ordered items for each order
    echo "<style>";
    echo "table { border-collapse: collapse; }";
    echo "table, th, td { border: 1px solid #ecf0f1; }";
    echo "</style>";

    // Display ordered items
    echo "<center>";
    echo "<table>";
    echo "<tr>";
    echo "<th>รูปสินค้า</th>";
    echo "<th>ชื่อสินค้า</th>";
    echo "<th>ราคาต่อชิ้น</th>";
    echo "<th>จำนวน</th>";
    echo "<th>ราคารวม</th>";
    echo "</tr>";

    $totalOrderPrice = 0; // Initialize total order price
    $orderID = $orderRow['OrderID'];
    $orderItems = $adminModel->getOrderItems($db, $orderID);
    foreach ($orderItems as $row) {
        $productID = $row['IDProduct'];
        $productRow = $adminModel->getProductByID($db, $productID);
        $totalPrice = $row["PricePerUnit"] * $row["Quantity"];
        echo "<tr>";
        echo '<td><img src="' . $productRow["image_url"] . '" alt="Product Image" style="width: 100px; height: 120px;"></td>';
        echo "<td>" . $productRow["ProductName"] . "</td>";
        echo "<td>" . $row["PricePerUnit"] . "</td>";
        echo "<td>" . $row["Quantity"] . "</td>";
        echo "<td>$totalPrice</td>";
        echo "</tr>";
        $totalOrderPrice += $totalPrice; // Add the item's total price to the overall total
    }
    $vat = $totalOrderPrice * 0.07;
    $totalOrderPrice += $vat;

    echo "</table>";
    echo "<p style='text-align: right; font-weight: bold;'>Total Order Price: " . $totalOrderPrice . " Baht(VAT 7%)</p>";

    if ($callerFileName === "ordernotConfirmDisplayMain.php") {
        echo "<form action='../adminControl/adminConfirmOrder.php?OrderID=$orderID' method='get'>";
        echo "<input type='hidden' name='orderID' value='$orderID'>";
        echo "<br><br><button type='submit' name='confirm'>ยืนยันคำสั่งซื้อ</button>";
        echo "</form>";

        if ($super == '1') {
            echo "<form action='adminEditAddress.php?OrderID=$orderID' method='get'>";
            echo "<input type='hidden' name='orderID' value='$orderID'>";
            echo "<button type='submit' name='edit'>แก้ไข</button>";
            echo "</form>";
    
            echo "<form action='../adminControl/adminDeleteOrder.php?OrderID=$orderID' method='get'>";
            echo "<input type='hidden' name='orderID' value='$orderID'>";
            echo "<button type='submit' name='delete'>Reject</button>";
            echo "</form>";
        }
    }

    if ($callerFileName === "orderDeliveryDisplayMain.php") {
        echo "<a href='../adminView/taxInvoice.php?orderID=" . $orderRow["OrderID"] . "' class='btn-pdf'> ใบกำกับภาษี/ใบส่งของ </a>";
    }
    
    echo "<hr><br></div>";
}
?>
<style>
    .btn-pdf {
        display: inline-block;
        padding: 10px 20px;
        background-color: #0854b8; /* สีเขียว */
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
        margin-right: 10px;
    }

    .btn-pdf:hover {
        background-color: #008fe2; /* สีน้ำเงินเข้มเมื่อ hover */
    }

    .btn-back {
        display: inline-block;
        padding: 10px 20px;
        background-color: #FF0000; /* สีแดง */
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
    }

    .btn-back:hover {
        background-color: #8b0000; /* สีแดงเข้มเมื่อ hover */
    }

</style>
