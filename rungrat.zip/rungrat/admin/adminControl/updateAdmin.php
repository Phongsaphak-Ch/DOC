<?php 
    $id = $_GET['message']; 
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/select.php';
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
    $db = mysqli_connect($host, $user, $password, $database);
    $adminModel = new adminModel($db);
    $row = $adminModel->selectAdminById($db, $id);

    echo "<label for='productCode'>ID: " . $row['admin_id']; "</label>";
    echo "<input type='hidden' name='admin_id' id='admin_id' value='" . $row["admin_id"] . "' required>";

    echo "<label for='productName'><br>Name:</label>";
    echo "<input type='text' name='name' id='name' value='" . $row["adminName"] . "' required>";

    echo "<label for='productPrice'>Email:</label>";
    echo "<input type='email' name='email' id='email' value='" . $row["email"] . "' required>";

    echo "<label for='productQuantity'>Address:</label>";
    echo "<input type='text' name='address' id='address' value='" . $row["address"] . "' required>";

    echo "<label for='productDetails'>Tel:</label>";
    echo "<input type='tel' name='Tel' id='Tel' value='"  . $row["tel"] . "' required>";

?>
