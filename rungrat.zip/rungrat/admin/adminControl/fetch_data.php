<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);
    require_once '../JWT/JWT.php';
    // ตรวจสอบการเชื่อมต่อ
    if (!$db) {
        die("Connection failed: " . mysqli_connect_error());
    }
    if (isset($_GET['start_date']) && isset($_GET['end_date'])) {
        $adminModel = new adminModel($db);
        $start_date = $_GET['start_date'];
        $end_date = $_GET['end_date'];
        $result = $adminModel->getOrdersByDateRange($db, $start_date, $end_date);
        $totalVAT = 0;
        $totalSubTotal = 0;
        $totalPrice = 0;

        if (mysqli_num_rows($result) > 0) {
            echo "<center><table border='1'>";
            echo "<tr><th>OrderID</th><th>Order Time</th><th>Name</th><th>VAT</th><th>Subtotal</th><th>TotalPrice</th></tr>";

            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row["OrderID"] . "</td>";
                echo "<td>" . $row["orderTime"] . "</td>";
                echo "<td>" . $row["CustName"] . "</td>";
                echo "<td>" . $row["VAT"] . "</td>";
                echo "<td>" . $row["subTotal"] . "</td>";
                echo "<td>" . $row["totalPrice"] . "</td>";
                echo "</tr>";

                $totalVAT += $row["VAT"];
                $totalSubTotal += $row["subTotal"];
                $totalPrice += $row["totalPrice"];
            }
            echo "<tr><td colspan='3'><strong>รวมทั้งสิ้น</strong></td><td><strong>" . number_format($totalVAT, 2) . "</strong></td><td><strong>" . number_format($totalSubTotal, 2) . "</strong></td><td><strong>" . number_format($totalPrice, 2) . "</strong></td></tr>";
            echo "</table></center>";
        } else {
            echo "No data available";
        }
    } else {
        echo "Start date or end date not specified";
    }
    // ปิดการเชื่อมต่อฐานข้อมูล
    mysqli_close($db);
?>