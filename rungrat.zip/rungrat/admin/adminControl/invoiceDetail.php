<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);
    require_once '../JWT/JWT.php';
    if (isset($_GET['orderID'])) {
        $adminModel = new adminModel($db);
        $orderID = $_GET['orderID'];

        // Fetch order details
        $orderRow = $adminModel->getOrderDetail($db, $orderID);

        // Fetch customer details including address
        $customerID = $orderRow['IDCust'];
        $customerRow = $adminModel->selectCustomerByID($db, $customerID);

        echo "<p><span style='float: left;'>Order ID: &nbsp&nbsp</span>" . $orderRow['OrderID'] . "</span></p>";
        echo "<p><span style='float: left;'>Customer ID: &nbsp&nbsp</span>" . $orderRow['IDCust'] . "</span></p>";
        echo "<p><span style='float: left;'>Customer name: &nbsp&nbsp</span>" . $orderRow['CustName'] . "&nbsp&nbsp&nbsp&nbsp&nbsp". $orderRow['lastName'] . "</span></p>";
        echo "<p><span style='float: left;'>Customer address: &nbsp&nbsp</span>" . $orderRow['address'] . "</span></p>";
        echo "<p><span style='float: left;'>Payment Method: &nbsp&nbsp</span>" . $orderRow['paymentMethod'] . "</span></p>";
        echo "<p><span style='float: left;'>Tel: &nbsp&nbsp</span>" . $orderRow['tel'] . "</span></p>";
        echo "<p><span style='float: left;'>Payment Status: &nbsp&nbsp</span>" . $orderRow['paymentStatus'] . "</p>";

        echo "<p>Order Date: &nbsp&nbsp" . $orderRow['OrderDate'] . "</p>";

        echo "<style>";
        echo "table { border-collapse: collapse; }";
        echo "table, th, td { border: 1px solid #ecf0f1; }";
        echo "</style>";

        echo "<center>";
        echo "<table>";
        echo "<tr>";
        echo "<th>รูปสินค้า</th>";
        echo "<th>ชื่อสินค้า</th>";
        echo "<th>ราคาต่อชิ้น</th>";
        echo "<th>จำนวน</th>";
        echo "<th>ราคารวม</th>";
        echo "</tr>";

        $totalOrderPrice = 0; // Initialize total order price
        $orderItems = $adminModel->getOrderItems($db, $orderID);
        foreach ($orderItems as $row) {
            $productID = $row['IDProduct'];
            $productRow = $adminModel->getProductByID($db, $productID);
            $totalPrice = $row["PricePerUnit"] * $row["Quantity"];
            echo "<tr>";
            echo '<td><img src="' . $productRow["image_url"] . '" alt="Product Image" style="width: 100px; height: 120px;"></td>';
            echo "<td>" . $productRow["ProductName"] . "</td>";
            echo "<td>" . $row["PricePerUnit"] . "</td>";
            echo "<td>" . $row["Quantity"] . "</td>";
            echo "<td>$totalPrice</td>";
            echo "</tr>";
            $totalOrderPrice += $totalPrice; // Add the item's total price to the overall total
        }

        echo "</table>";

        // Display total order pric
        echo "<p style='text-align: right; font-weight: bold;'>Total Order Price: " . $orderRow['totalPrice'] . " Baht(VAT 7%)</p>";
        echo "<a href='../adminView/pdf1.php?orderID=" . $orderRow["OrderID"] . "' class='btn-pdf'> PDF </a>";
        echo "<a href='../adminView/invoice.php' class='btn-back'> ย้อนกลับ </a>";
    }
    mysqli_close($db);
?>
<style>
    .btn-pdf {
        display: inline-block;
        padding: 10px 20px;
        background-color: #0854b8; /* สีเขียว */
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
        margin-right: 10px;
    }

    .btn-pdf:hover {
        background-color: #008fe2; /* สีน้ำเงินเข้มเมื่อ hover */
    }

    .btn-back {
        display: inline-block;
        padding: 10px 20px;
        background-color: #FF0000; /* สีแดง */
        color: #fff;
        text-decoration: none;
        border-radius: 5px;
    }

    .btn-back:hover {
        background-color: #8b0000; /* สีแดงเข้มเมื่อ hover */
    }

</style>