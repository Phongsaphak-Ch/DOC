<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/delete.php';
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
    $db = mysqli_connect($host, $user, $password, $database);
    $code = $_GET['message'];
    $adminDeleteModel = new adminDeleteModel($db);
    $result = $adminDeleteModel->deleteAdminData($db, $code);
    if (!$result) {
        // echo '<div class="error">Error: Unable to delete data</div>';
    } else {
        // echo '<div class="success">Delete data: <span style="color: red;">' . $code . '</span> is Successful!</div>';
    }
    mysqli_close($db);
    header("refresh:3;url=../adminView/adminList.php");
?>