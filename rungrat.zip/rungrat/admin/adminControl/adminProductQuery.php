<?php
    if (isset($_POST['search'])) {
        $search_type = $_POST['search_type'];
        $search_query = $_POST['search'];

        if ($search_type == 'id') {
            $sql = "SELECT image_url, IDProduct, ProductName, PricePerUnit, StockQty, typeID FROM stock WHERE IDProduct LIKE '%$search_query%'";
        } else if ($search_type == 'name') {
            $sql = "SELECT image_url, IDProduct, ProductName, PricePerUnit, StockQty, typeID FROM stock WHERE ProductName LIKE '%$search_query%'";
        } else if ($search_type == 'type') {
            $sql = "SELECT stocktype.typeName, stock.image_url, stock.IDProduct, stock.ProductName, stock.PricePerUnit, stock.StockQty, stock.typeID 
            FROM stock 
            INNER JOIN stocktype ON stock.typeID = stocktype.typeID 
            WHERE stock.typeID LIKE '%$search_query%' OR stocktype.typeName LIKE '%$search_query%'";
        } else {
            $sql = "SELECT image_url, IDProduct, ProductName, PricePerUnit, StockQty, typeID FROM stock";
        }
    } else {
        $sql = "SELECT image_url, IDProduct, ProductName, PricePerUnit, StockQty, typeID FROM stock";
    }

    $result = mysqli_query($db, $sql);
    echo "<br><table>";
    echo "<tr>";
    if ($super == 1) {
        echo "<th>Select</th>";
    }
    echo "<th>Product image</th>";
    echo "<th>IDProduct</th>";
    echo "<th>ProductType</th>";
    echo "<th>ProductName</th>";
    echo "<th>PricePerUnit</th>";
    echo "<th>StockQty</th>";
    if ($super == 1) {
        echo "<th>Update</th>";
        echo "<th>Delete</th>";
    }
    echo "</tr>";

    while ($row = mysqli_fetch_array($result)) {
        echo "<tr>";
        if ($super == 1) {
            echo "<td><input type='checkbox' id='checkbox_' name='checkbox_name' value='" . $row["IDProduct"] . "'></td>";
        }
        echo '<td><img src="' . $row["image_url"] . '" alt="Product Image" style="width: 50px; height: 50px;"></td>';
        echo "<td>" . $row["IDProduct"] . "</td>";
        echo "<td>" . $row["typeID"] . "</td>";
        echo "<td>" . $row["ProductName"] . "</td>";
        echo "<td>" . $row["PricePerUnit"] . "</td>";
        echo "<td>" . $row["StockQty"] . "</td>";

        if ($super == 1) {
            echo "<td>";
            echo "<a href='updateStock.php?message=" . $row["IDProduct"] . "'>";
            echo "<img src='../../pic/icon/update.png' alt='Edit'>";
            echo "</a>";
            echo "</td>";

            
            echo "<td><a href='#' onclick='confirmDelete(\"" . $row["IDProduct"] . "\");return false;'>
                <img src='../../pic/icon/delete.png' alt='Delete'></a></td>";
            echo "</a>";
            echo "</td>";
        }
    
        echo "</tr>";
    }
    
    echo "</table><br>";
    echo "<div style='text-align: left;'>";
    if ($super == 1) {
        echo "<form>";
        echo "<input type='checkbox' id='checkbox1' name='checkbox1' value='checkbox1'>";
        echo "<label for='checkbox1'>Check All</label><br>";
        echo "</form>";
    }
    if ($super == 1) { echo '
        <form action="../adminControl/Delete_stock1.php" method="post" id="delete" onsubmit="return confirmDeletes()">
            <input type="hidden" name="IDProducts" id="IDProducts">
            <input type="submit" value="Delete" class="insert">
        </form>';}
    echo date("d-M-Y H:i:s") . ".<br>";
    echo "</div><br>";
    mysqli_close($db);
?>

<script>
function confirmDelete(IDProduct) {
    if (confirm("Are you sure you want to delete Product ID " + IDProduct + "?")) {
        window.location.href = '../adminControl/Delete_stock.php?message=' + IDProduct;
    } else {
        return false;
    }
}

function toggleCheckboxes() {
        var checkboxes = document.querySelectorAll('input[name="checkbox_name"]');
        var checkAllCheckbox = document.getElementById('checkbox1');

        for (var i = 0; i < checkboxes.length; i++) {
            checkboxes[i].checked = checkAllCheckbox.checked;
        }
    }
    document.getElementById('checkbox1').addEventListener('click', toggleCheckboxes);

    function deleteSelected() {
        var checkboxes = document.querySelectorAll('input[name="checkbox_name"]:checked');
        var IDProducts = [];
        checkboxes.forEach(function(checkbox) {
            IDProducts.push(checkbox.value);
        });
        document.getElementById('IDProducts').value = JSON.stringify(IDProducts);
        document.getElementById('delete').submit();
    }

    function confirmDeletes() {
        var IDProductsArray = [];
        var checkboxes = document.querySelectorAll('input[name="checkbox_name"]:checked');
        checkboxes.forEach(function(checkbox) {
            IDProductsArray.push(checkbox.value);
        });
        var IDProducts = IDProductsArray.join(',');
        if (confirm("Are you sure you want to delete Product ID(s): " + IDProducts + "?")) {
            document.getElementById('IDProducts').value = IDProducts;
            document.getElementById('delete').submit();
        } else {
            return false;
        }
    }
</script>