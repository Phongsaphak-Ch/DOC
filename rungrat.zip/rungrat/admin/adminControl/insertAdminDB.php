<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/insert.php';
    require_once '../adminModel/select.php';
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
$db = mysqli_connect($host, $user, $password, $database);

if (!$db) {
    die("Connection failed: " . mysqli_connect_error());
}

$adminModel = new adminModel($db);
$adminInsertModel = new adminInsertModel($db);

$username = $_POST['username'];
$password = password_hash($_POST['password'], PASSWORD_BCRYPT);
$email = $_POST['email'];
$name = $_POST['name'];
$address = $_POST['address'];
$tel = $_POST['tel'];
$adminType = $_POST['adminType'];

$sql = $adminInsertModel->insertAdmin();

// สร้างค่า admin_id
$get_last_id_result = $adminModel->getLastAdminID($db);

if (mysqli_num_rows($get_last_id_result) > 0) {
    $last_row = mysqli_fetch_assoc($get_last_id_result);
    $last_id = $last_row['admin_id'];
    $next_id = ++$last_id;
    $admin_id = 'A' . str_pad($next_id, 3, '0', STR_PAD_LEFT);
} else {
    $admin_id = 'A001';
}

$admin_id = $adminModel->getNewAdminID($db);

$stmt = $db->prepare($sql);
$stmt->bind_param("sssssssi", $admin_id, $username, $password, $email, $name, $address, $tel, $adminType);
$result = $stmt->execute();

if ($result) {
    header("Location: ../adminView/adminList.php");
    exit();
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($db);
}

// ปิดการเชื่อมต่อฐานข้อมูล
$stmt->close();
mysqli_close($db);
?>
