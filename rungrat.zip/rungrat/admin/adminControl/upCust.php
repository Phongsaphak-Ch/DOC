<?php 
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/select.php';
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
    $id = $_GET['message']; 
    $db = mysqli_connect($host, $user, $password, $database);
    $adminModel = new adminModel($db);
    $row = $adminModel->selectCustomerByID($db, $id);

    echo "<label for='productCode'>IDCust: " . $row['IDCust']; "</label>";
    echo "<input type='hidden' name='IDCust' id='IDCust' value='" . $row["IDCust"] . "' required>";

    echo "<label for='productName'><br>CustName:</label>";
    echo "<input type='text' name='CustName' id='CustName' value='" . $row["CustName"] . "' required>";
    
    echo "<label for='productQuantity'>Address:</label>";
    echo "<input type='text' name='Address' id='Address' value='" . $row["Address"] . "' required>";

    echo "<label for='productDetails'>Tel:</label>";
    echo "<input type='text' name='Tel' id='Tel' value='"  . $row["Tel"] . "' required>";

?>
