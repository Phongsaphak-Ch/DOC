<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/update.php';
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
    $db = mysqli_connect($host, $user, $password, $database);
    $adminUpdateModel = new adminUpdateModel($db);
    $a1 = $_POST['admin_id'];
    $a2 = $_POST['name'];
    $a3 = $_POST['email'];
    $a4 = $_POST['address'];
    $a5 = $_POST['Tel'];

    $result = $adminUpdateModel->updateAdminData($db, $a1, $a2, $a3, $a4, $a5);

    if (!$result) {
        echo '<div class="error">Error: Unable to update data</div>';
    } else {
        echo '<div class="success">Update data: <span style="color: red;">' . $a1 . '</span> is Successful!</div>';

        header("refresh:1;url=../adminView/adminList.php");
    }

    mysqli_close($db);
?>
