<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../JWT/JWT.php';
    include_once "orderDisplayFunctions.php";
    $db = mysqli_connect($host, $user, $password, $database);
    $adminModel = new adminModel($db);
    $status = 'finish';
    $orders = $adminModel->getOrdersByStatus($db, $status);
    foreach ($orders as $orderRow) {
        displayOrderDetails($orderRow, $db, basename(__FILE__), $super);
    }

mysqli_close($db);
?>
