<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);
    require_once '../JWT/JWT.php';
    // ตรวจสอบการเชื่อมต่อ
    if (!$db) {
        die("Connection failed: " . mysqli_connect_error());
    }
    if (isset($_GET['print'])) {
        $adminModel = new adminModel($db);
        $print = $_GET['print'];
        $result = $adminModel->getAllOrderDetailForInvoice($db, $print);

        if (mysqli_num_rows($result) > 0) {
            date_default_timezone_set('Asia/Bangkok');
            echo "<center><br><table>";
            echo "<tr>";
            echo "<th>Select</th>";
            echo "<th>OrderID</th>";
            echo "<th>IDCust</th>";
            echo "<th>CustName</th>";
            echo "<th>Address</th>";
            echo "<th>Tel</th>";
            echo "<th>สถานะคำสั่งซื้อ</th>";
            echo "<th>วิธีการชำระเงิน</th>";
            echo "<th>สถานะการชำระเงิน</th>";
            echo "<th>สถานะการปรินต์</th>";
            echo "<th>รายละเอียด</th>";
            echo "</tr>";
            
            $row_count = 0;
            
            while ($row = mysqli_fetch_array($result)) {
                $row_count++;
                echo "<tr class='" . (($row_count % 2 == 0) ? 'even' : 'odd') . "'>";
                echo "<td><input type='checkbox' id='checkbox_' name='checkbox_name' value='" . $row["OrderID"] . "'></td>";
                echo "<td>" . $row["OrderID"] . "</td>";
                echo "<td>" . $row["IDCust"] . "</td>";
                echo "<td>" . $row["CustName"] . "</td>";
                echo "<td>" . $row["address"] . "</td>";
                echo "<td>" . $row["tel"] . "</td>"; 
                echo "<td>" . $row["status"] . "</td>"; 
                echo "<td>" . $row["paymentMethod"] . "</td>"; 
                echo "<td>" . $row["paymentStatus"] . "</td>"; 
                echo "<td class='" . ($row["print"] == 1 ? "printed" : "not-printed") . "'>";
                echo $row["print"] == 1 ? "ปรินต์แล้ว" : "ยังไม่ปรินต์";
                echo "</td>";
                echo "<td><a href='../adminView/invoiceShow.php?orderID=" . $row["OrderID"] . "'>รายละเอียด</a></td>"; 
                echo "</tr>";
            }
        
        echo "</center></table><br>";
        } else {
            echo "No data available";
        }
    } else {
        echo "Start date or end date not specified";
    }
    // ปิดการเชื่อมต่อฐานข้อมูล
    mysqli_close($db);
?>