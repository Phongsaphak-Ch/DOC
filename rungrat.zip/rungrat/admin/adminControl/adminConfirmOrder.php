<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/update.php';
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
    $db = mysqli_connect($host, $user, $password, $database);
    $adminUpdateModel = new adminUpdateModel($db);
    $orderID = $_GET["orderID"];
    $status = "deli";
    
    // อัปเดตสถานะในตาราง order_detail
    $result = $adminUpdateModel->updateOrderStatus($db, $orderID, $status);

    if($result) {
        
        // อัปเดตจำนวนสินค้าที่ขายไปในตาราง stock
        $result = $adminUpdateModel->updateProductSold($db, $orderID);
        // ส่งกลับไปยังหน้าตะกร้าหลักหลังจากทำการลบสินค้า
        header("Location: ../adminView/adminOrderDelivery.php");
    } else {
        echo "เกิดข้อผิดพลาดในการลบสินค้าออกจากรถเข็น";
    }
?>
