<?php
    date_default_timezone_set('Asia/Bangkok');
    if (isset($_POST['search'])) {
        $search_type = $_POST['search_type'];
        $search_query = $_POST['search'];

        if ($search_type == 'id') {
            $sql = "SELECT IDCust, CustName, Address, Tel FROM customer WHERE IDCust LIKE '%$search_query%'";
        } else if ($search_type == 'name') {
            $sql = "SELECT IDCust, CustName, Address, Tel FROM customer WHERE CustName LIKE '%$search_query%'";
        } else {
            $sql = "SELECT IDCust, CustName, Address, Tel FROM customer";
        }
    } else {
        $sql = "SELECT IDCust, CustName, Address, Tel FROM customer";
    }

    $result = mysqli_query($db, $sql);   
    echo "<center><br><table>";
    echo "<tr>";
    if ($super == 1) {
        echo "<th>Select</th>";
    }
    echo "<th>IDCust</th>";
    echo "<th>CustName</th>";
    echo "<th>Address</th>";
    echo "<th>Tel</th>";
    if ($super == 1) {
        echo "<th>Update</th>";
        echo "<th>Delete</th>";
    }
    echo "</tr>";

    $row_count = 0;

    while ($row = mysqli_fetch_array($result)) {
        $row_count++;
        echo "<tr class='" . (($row_count % 2 == 0) ? 'even' : 'odd') . "'>";
        if ($super == 1) {
            echo "<td><input type='checkbox' id='checkbox_' name='checkbox_name' value='" . $row["IDCust"] . "'></td>";
        }               
        echo "<td>" . $row["IDCust"] . "</td>";
        echo "<td>" . $row["CustName"] . "</td>";
        echo "<td>" . $row["Address"] . "</td>";
        echo "<td>" . $row["Tel"] . "</td>";
        if ($super == 1) {
            echo "<td><a href='updateCustomer.php?message=" . $row["IDCust"] . "'>"; 
            echo "<img src='../../pic/icon/update.png' alt='Edit'></a></td>";  
            echo "<td><a href='#' onclick='confirmDelete(\"" . $row["IDCust"] . "\");return false;'>
                <img src='../../pic/icon/delete.png' alt='Delete'></a></td>";
        }
        echo "</tr>";
    }

    echo "</table><br>";
    
    echo "<div style='text-align: left;'>";
    if ($super == 1) {
        echo "<form>";
        echo "<input type='checkbox' id='checkbox1' name='checkbox1' value='checkbox1'>";
        echo "<label for='checkbox1'>Check All</label><br>";
        echo "</form>";
    }
    if ($super == 1) { echo '
        <form action="../adminControl/Delete_consumer1.php" method="post" id="delete" onsubmit="return confirmDeletes()">
            <input type="hidden" name="IDCusts" id="IDCusts">
            <input type="submit" value="Delete" class="insert">
        </form>';}
    echo date("d-M-Y H:i:s") . ".<br>";
    echo "</div><br>";
    mysqli_close($db);
?>

<script>
function confirmDelete($IDCust) {
    if (confirm("Are you sure you want to delete Customer ID " + $IDCust + "?")) {
        window.location.href = '../adminControl/Delete_consumer.php?message=' + $IDCust;
    } else {
        return false;
    }
}

function toggleCheckboxes() {
        var checkboxes = document.querySelectorAll('input[name="checkbox_name"]');
        var checkAllCheckbox = document.getElementById('checkbox1');

        for (var i = 0; i < checkboxes.length; i++) {
            checkboxes[i].checked = checkAllCheckbox.checked;
        }
    }
    document.getElementById('checkbox1').addEventListener('click', toggleCheckboxes);
</script>
