<?php
require_once '../adminModel/connectDatabase.php';
require_once '../adminModel/select.php';
require_once '../adminModel/update.php';
require_once '../JWT/JWT.php';
if ($super == '0') {
    header("Location: ../adminControl/logout.php");
    exit();
}
$db = mysqli_connect($host, $user, $password, $database);
$adminModel = new adminModel($db);
$adminUpdateModel = new adminUpdateModel($db);

$orderID = $_POST["orderID"];
$name = $_POST["name"];
$lastName = $_POST["lastname"];
$address = $_POST["address"];
$email = $_POST["email"];
$tel = $_POST["tel"];
$quantities = $_POST['quantity'];

// Calculate total price from order items
$totalOrderPrice = 0;

foreach ($quantities as $key => $quantity) {
    // Get the product ID associated with the current item
    $productID = $_POST['productID'][$key];

    $currentQuantity = $adminModel->getQuantityFromOrderItem($db, $orderID, $productID);
    $quantityDifference = $currentQuantity - $quantity;
    $updateResult = $adminUpdateModel->updateStockQuantityCust($db, $productID, $quantityDifference);
    $update_result = $adminUpdateModel->updateOrderItemQuantity($db, $orderID, $productID, $quantity);
    if (!$adminUpdateModel->updateOrderItemQuantity($db, $orderID, $productID, $quantity)) {
        // Handle query execution error
        echo "Error updating quantity: " . mysqli_error($db);
    } else {
        // Query successful, update total order price
        $totalOrderPrice = $adminModel->getTotalOrderPrice($db, $orderID);
    }
}

// Calculate VAT
$vat = $totalOrderPrice * 0.07;
$totalOrderPrice += $vat;

// Update other details (customer information, total order price, VAT) for the entire order
if (!$adminUpdateModel->updateOrderDetails($db, $name, $lastName, $email, $tel, $address, $totalOrderPrice, $vat, $orderID)) {
    // Handle query execution error
    echo "Error updating order details: " . mysqli_error($db);
}

// Redirect to historywait.php
header("Location: ../adminView/adminOrdernotConfirm.php");

// Close the database connection
mysqli_close($db);
?>
