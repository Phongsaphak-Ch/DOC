<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/delete.php';
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
    ob_start(); // เริ่ม output buffering
    $db = mysqli_connect($host, $user, $password, $database);
    $adminDeleteModel = new adminDeleteModel($db);
    $code = $_GET['message'];  // Adjust this line to retrieve the correct parameter
    $result = $adminDeleteModel->deleteCustomer($db, $code);

    mysqli_close($db);
    header("Location: ../adminView/adminCustomer.php");
    ob_end_flush(); // สิ้นสุด output buffering และส่งข้อมูลที่ถูกเก็บไว้ไปยังเบราว์เซอร์
?>
