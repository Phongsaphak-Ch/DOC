<?php
require_once '../adminModel/connectDatabase.php';
require_once '../adminModel/select.php';

header('Content-Type: application/json'); // เพิ่มบรรทัดนี้เพื่อระบุ Content-Type เป็น application/json

if(isset($_POST['username'])) {
    $db = mysqli_connect($host, $user, $password, $database);
    if ($db->connect_error) {
        die("Connection failed: " . $db->connect_error);
    }

    $adminModel = new adminModel($db);
    $username = $_POST['username'];
    echo json_encode($adminModel->checkUsernameAvailability($username)); // แปลงผลลัพธ์เป็น JSON

    $db->close();
}

?>
