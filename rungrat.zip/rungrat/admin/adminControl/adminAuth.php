<?php
require '../../vendor/autoload.php';
require_once '../adminModel/select.php';
require_once '../adminModel/connectDatabase.php';

use Firebase\JWT\JWT;

if (!isset($_POST["username"]) || empty($_POST["username"])) {
    header("Location: ../adminView/adminLogin.html");
    exit();
} else {
    $db = mysqli_connect($host, $user, $password, $database);
    $adminModel = new adminModel($db);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $row = $adminModel->getUserByUsername($db, $_POST["username"]);
    
    if ($row) {
        $dbPassword = $row['password'];
        $id = $row['admin_id'];
        $pepper = 'me';
        if (password_verify($_POST["password"], $dbPassword)) {
            $key = $secretkey;
            $token = JWT::encode(
                array(
                    'iat'       =>  time(),
                    'nbf'       =>  time(),
                    'exp'       =>  time() + 3600,
                    'data'  => array(
                        'admin_id'   =>  $id,
                        'username'  =>  $row['adminName'],
                        'super'     => $row['super']
                    )
                ),
                $key,
                'HS256'
            );
            setcookie("token", $token, time() + 3600, "/", "", true, true);

            header("Location: ../adminView/adminMenu.php");
            exit();
        } else {
            // Redirect to logout.php if admin is null
            header("Location: ../adminView/adminLogin.php?error=InvalidCredentials");
            exit(); // Make sure to exit after redirection
        }
    } else {
        header("Location: ../adminView/adminLogin.php?error=InvalidCredentials");
    }
} else {
    header("Location: ../adminView/adminLogin.php?error=InvalidCredentials");
}
?>
