<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/insert.php';
    require_once '../adminModel/select.php';
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
    $db = mysqli_connect($host, $user, $password, $database);
    $username = $_POST['username'];
    $password = $_POST['password'];
    $name = $_POST['name'];
    $address = $_POST['address'];
    $tel = $_POST['tel'];

    $adminModel = new adminModel($db);
    $adminInsertModel = new adminInsertModel($db);
    $max_id = $adminModel->selectForEmailRegis();

    $new_id = ++$max_id;
    $new_id_formatted = "C" . sprintf("%03d", $new_id);

    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    /* run insert */
    $result = $adminInsertModel->insertCustomer($db, $new_id_formatted, $username, $hashedPassword, $name, $address, $tel);
    /* execute statement */
    if (!$result) {
        /* error */
        echo "Error";
    } else {
        echo "<font top=20 color=green> Insert data = </font><Font color=red> '$username'</Font> <font color=green> is Successful! </font>";
    }

    mysqli_close($db);
    header("refresh:3;url=../adminView/adminCustomer.php");
?>