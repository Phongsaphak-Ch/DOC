<?php
require_once '../adminModel/connectDatabase.php';
require_once '../adminModel/select.php';
require_once '../adminModel/update.php';
require_once '../JWT/JWT.php';
if ($super == '0') {
    header("Location: ../adminControl/logout.php");
    exit();
}
$db = mysqli_connect($host, $user, $password, $database);
$adminModel = new adminModel($db);
$adminUpdateModel = new adminUpdateModel($db);
$a1 = $_POST['IDProduct'];
$a2 = $_POST['ProductName'];
$a3 = $_POST['PricePerUnit'];
$a4 = $_POST['StockQty'];
$a5 = $_POST['detail'];

$image_name = $_FILES['productImage']['name'];  
$tmp_image = $_FILES['productImage']['tmp_name'];
$image_error = $_FILES['productImage']['error'];

// ตรวจสอบว่ามีการอัปโหลดรูปภาพใหม่หรือไม่
if($image_error === 0){
    $image_path = "book/" . $image_name;  
    move_uploaded_file($tmp_image, $image_path); 
} else {
    $image_path = $adminModel->getImagePath($db, $a1);
}

$old_stock_qty = $adminModel->getStockQty($db, $a1);

// คำนวณค่า StockQty ใหม่
$a4 = (int)$a4;
$new_stock_qty = $old_stock_qty + $a4;


$result = $adminUpdateModel->updateStock($db, $a1, $a2, $a3, $new_stock_qty, $a5, $image_path);
if (!$result) {
    echo '<div class="error">Error: Unable to update data</div>';
} else {
    header("Location: ../adminView/adminProduct.php");
}

mysqli_close($db);
?>
