<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/update.php';
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
    $db = mysqli_connect($host, $user, $password, $database);
    $adminUpdateModel = new adminUpdateModel($db);
    $status = "deli";


    $cur = $adminUpdateModel->updateOrderStatusAll($db, $status);
    if ($cur) {
        echo "Quantity updated successfully";
        header("Location: ../adminView/adminOrderConfirmed.php");
    } else {
        echo "Error updating quantity: " . mysqli_error($db);
    }

    mysqli_close($db);
?>