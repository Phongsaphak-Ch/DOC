<?php
date_default_timezone_set('Asia/Bangkok');
$db = mysqli_connect($host, $user, $password, $database);
if ($super == '1') {
    echo "<center><br><table>";
    echo "<tr>";
    echo "<th>Admin ID</th>";
    echo "<th>Admin name</th>";
    echo "<th>Address</th>";
    echo "<th>Email</th>";
    echo "<th>Tel</th>";
    echo "<th>Role</th>";
    echo "<th>Update</th>";
    echo "<th>Delete</th>";
    echo "</tr>";
    $row_count = 0;
    while ($row = mysqli_fetch_array($result)) {
        $row_count++;
        echo "<tr class='" . (($row_count % 2 == 0) ? 'even' : 'odd') . "'>";
        echo "<td>" . $row["admin_id"] . "</td>";
        echo "<td>" . $row["adminName"] . "</td>";
        echo "<td>" . $row["address"] . "</td>";
        echo "<td>" . $row["email"] . "</td>";
        echo "<td>" . $row["tel"] . "</td>";
        echo "<td>";
        if ($row["super"] == 1) {
            echo "super admin";
        } else {
            echo "user admin";
        }
        echo "</td>";
        echo "<td><a href='updateAdmin.php?message=" . $row["admin_id"] . "'>
                <img src='../../pic/icon/update.png' alt='Edit'></a></td>";
        echo "<td><a href='#' onclick='confirmDelete(\"" . $row["admin_id"] . "\");return false;'>
            <img src='../../pic/icon/delete.png' alt='Delete'></a></td>";
        echo "</tr>";
    }
    echo "</table><br>";
    echo "<div style='text-align: left;'>";
    echo date("d-M-Y H:i:s") . ".<br>";
    echo "</div><br>";
}
mysqli_close($db);
?>
