<?php
    $code = $_GET['message'];  // Adjust this line to retrieve the correct parameter

    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/delete.php';
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
    
    $db = mysqli_connect($host, $user, $password, $database);
    $adminDeleteModel = new adminDeleteModel($db);

    $result = $adminDeleteModel->deleteProduct($db, $code);

    if (!$result) {
        // echo '<div class="error">Error: Unable to delete data</div>';
    } else {
        // echo '<div class="success">Delete data: <span style="color: red;">' . $code . '</span> is Successful!</div>';
    }
    mysqli_close($db);
    header("refresh:1;url=../adminView/adminProduct.php");
    exit(); // เพิ่ม exit() เพื่อหยุดการทำงานของสคริปต์ทันทีหลังจากการ redirect
?>
