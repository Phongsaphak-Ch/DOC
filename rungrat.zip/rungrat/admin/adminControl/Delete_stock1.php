<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/delete.php';
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $IDProducts = explode(",", $_POST['IDProducts']);
        $db = mysqli_connect($host, $user, $password, $database);
        $adminDeleteModel = new adminDeleteModel($db);
        foreach ($IDProducts as $IDProduct) {
            $result = $adminDeleteModel->deleteProduct($db, $IDProduct);
        }
        mysqli_close($db);
    }
    header("refresh:1;url=../adminView/adminProduct.php");
?>