<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);
    require_once '../JWT/JWT.php';
    // ตรวจสอบการเชื่อมต่อ
    if (isset($_GET['start_date']) && isset($_GET['end_date'])) {
        if(isset($_GET['start_date']) && isset($_GET['end_date'])) {
            $start_date = $_GET['start_date'];
            $end_date = $_GET['end_date'];
            // ค้นหา OrderID ที่อยู่ในช่วงวันที่ระบุ
            $order_id_sql = "SELECT OrderID FROM order_detail WHERE orderDate BETWEEN '$start_date' AND '$end_date' AND status = 'finish'";
            $order_id_result = mysqli_query($db, $order_id_sql);
            $order_ids = [];
            while($row = mysqli_fetch_assoc($order_id_result)) {
                $order_ids[] = $row['OrderID'];
            }
            // หาสินค้าที่ถูกสั่งซื้อใน OrderID ที่พบ
            $product_sales = [];
            foreach ($order_ids as $order_id) {
                $product_sql = "SELECT IDProduct, Quantity FROM order_item WHERE OrderID = '$order_id'";
                $product_result = mysqli_query($db, $product_sql);
                while($row = mysqli_fetch_assoc($product_result)) {
                    $product_id = $row['IDProduct'];
                    $quantity = $row['Quantity'];
                    // เพิ่มจำนวนสินค้าที่ขายไปในรายงาน
                    if(isset($product_sales[$product_id])) {
                        $product_sales[$product_id] += $quantity;
                    } else {
                        $product_sales[$product_id] = $quantity;
                    }
                }
            }
            arsort($product_sales);
            // แสดงผลลัพธ์
            if(empty($product_sales)) {
                echo "result 0";
            } else {
                echo "<table border='1'>";
                echo "<tr><th>ProductID</th><th>Product Name</th><th>Stock Quantity</th><th>Quantity Sold</th></tr>";
                foreach ($product_sales as $product_id => $quantity_sold) {
                    // ดึงข้อมูลสินค้าจากฐานข้อมูล
                    $product_info_sql = "SELECT * FROM stock WHERE IDProduct = '$product_id'";
                    $product_info_result = mysqli_query($db, $product_info_sql);
                    $product_info = mysqli_fetch_assoc($product_info_result);
                    $product_name = $product_info['ProductName'];
                    $qty = $product_info['StockQty'];
                    // แสดงข้อมูลในตาราง
                    echo "<tr><td>$product_id</td><td>$product_name</td><td>$qty</td><td>$quantity_sold</td></tr>";
                }
                echo "</table>";
            }
        }
    } 

    // ปิดการเชื่อมต่อฐานข้อมูล
    mysqli_close($db);
?>