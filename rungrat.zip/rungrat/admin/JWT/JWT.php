<?php
    require '../../../vendor/autoload.php';
    use Firebase\JWT\JWT;
    use Firebase\JWT\Key;

    $key = $secretkey;

    if(isset($_COOKIE['token'])){
        $decoded = JWT::decode($_COOKIE['token'], new Key($key, 'HS256'));
        if(!isset($decoded->data->admin_id) || !isset($decoded->data->super)) {
            header('location: ../adminView/adminLogin.php');
            exit();
        }

        $id = $decoded->data->admin_id;
        $username = $decoded->data->username;
        $super = $decoded->data->super;
    } else {
        header('location: ../adminView/adminLogin.php');
    }
?>