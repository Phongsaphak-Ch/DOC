<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../adminStyle/insert.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <title>Insert</title>
</head>
<body>
    <div class="area">
        <div class="circles">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>        
            <div class="context">
                <center>
                    <div class="container">
                        <div class="input-group">
                            <form action="../adminControl/insertAdminDB.php" method="post" enctype="multipart/form-data">
                                <h2><center>Insert Admin</center></h2>

                                <label for="productName">username :</label>
                                <input type="text" name="username" placeholder="username">
                                <span id="usernameError" style="color: red;"></span>

                                <label for="productName">password :</label>
                                <input type="password" id="password" name="password" required oninput="validatePassword()">
                                <span id="passwordStatus" style="color: red;"></span>
                                
                                <label for="productName">confirm password :</label>
                                <input type="password" name="cpassword" id="cpassword" oninput="checkPasswordMatch()">
                                <span id="cpasswordStatus" style="color: red;"></span>
                                
                                <label for="productName">email :</label>
                                <Input Type="email" Name="email" required>

                                <label for="productPrice">name :</label>
                                <Input Type="Text" Name="name" required>

                                <label for="productQuantity">ที่อยู่ :</label>
                                <Input Type="Text" Name="address" required>

                                <label for="productDetails">เบอร์โทรศัพท์ :</label>
                                <input type="tel" name="tel" placeholder="Tel" pattern="[0-9]+" title="Please enter only numeric characters" required minlength="10" required maxlength="11">

                                <label for="productDetails">Role :</label>
                                <select name="adminType" id="adminType">
                                    <option value="0" selected>admin</option>
                                    <option value="1">super admin</option>
                                </select>

                                
                                <center>
                                    <button type="submit" id="signupButton">Insert</button>
                                    <button type="button" onclick="window.location.href='../adminView/adminList.php';">Cancel</button>
                                </center>
                            </form>
                        </div>
                    </div>
                </center>
            </div>
        </div>
    </div>
</body>
</html>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="../adminScript/validAdminScript.js"></script>

