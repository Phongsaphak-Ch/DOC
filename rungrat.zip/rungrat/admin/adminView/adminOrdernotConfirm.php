<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../JWT/JWT.php';
    require_once '../adminModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../adminStyle/report.css">
</head>
<body>
    <?php include_once "adminNavbar.php"; ?>

    <div style="margin-left:200px"><br>
            <div class="backdrop">
                <h4>รายการสั่งซื้อที่ยังไม่ยืนยัน</h4><br>
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <form action="search.php" method="post" style="display: flex; align-items: center;">
                        <label for="search">Search:</label>
                        <input type="text" name="search" id="search" placeholder="Search somethings..."> 
                        <input type="submit" value="Search" class="search">
                    </form>

                    <form action="../adminControl/confirmAll.php" method="post">
                        <input type="submit" value="ยืนยันทั้งหมด" class="insert">
                    </form>
                </div>
                <?php include_once "../adminControl/ordernotConfirmDisplayMain.php" ?>
            </div>
            <br><br>
    </div>
    
</body>
</html>
