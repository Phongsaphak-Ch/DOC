<?php
ob_start();
require_once('../../TCPDF-main/tcpdf.php');

require_once '../adminModel/connectDatabase.php';
require_once '../JWT/JWT.php';
$db = mysqli_connect($host, $user, $password, $database);

    // create new PDF document
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

    // set document information
    $pdf->SetCreator(PDF_CREATOR);
    $pdf->SetAuthor('Book company');
    $pdf->SetTitle('INVOICE');

    $orderIDs = json_decode($_POST['orderIDs']);
    foreach ($orderIDs as $orderID) {
        $orderQuery = mysqli_query($db, "SELECT * FROM order_detail WHERE OrderID='$orderID'");
        $orderRow = mysqli_fetch_assoc($orderQuery);
        $orderID = $orderRow['OrderID'];
        $updateQuery = mysqli_query($db, "UPDATE order_detail SET taxPrint = '1', status = 'confirm' WHERE OrderID='$orderID'");
        $orderItemsQuery_first_page = mysqli_query($db, "SELECT * FROM order_item WHERE OrderID='$orderID'");
        $orderItems_first_page = mysqli_fetch_all($orderItemsQuery_first_page, MYSQLI_ASSOC);

        // Fetch order items for the second page
        $orderItemsQuery_second_page = mysqli_query($db, "SELECT * FROM order_item WHERE OrderID='$orderID'");
        $orderItems_second_page = mysqli_fetch_all($orderItemsQuery_second_page, MYSQLI_ASSOC);


        // set some language-dependent strings (optional)
        if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
            require_once(dirname(__FILE__).'/lang/eng.php');
            $pdf->setLanguageArray($l);
        }

        // ---------------------------------------------------------
        $pdf->SetFont('thsarabunnew', '', 14);
        // add a page
        $pdf->AddPage();

        // create some HTML content
        $html = '
        <table width="100%">
            <tr>
                <td valign="top"><h1><b>TAX INVOICE/RECEIPT</b></h1></td>
                <td align="right">
                        <h3><span>Book company</span><br>
                        <span>Company representative name</span><br>
                        <span>Company address</span><br>
                        <span>Tax ID: 0123456789</span><br>
                        <span>Phone: 089123456</span><br>
                        <span>Fax: 1234</span></h3>
                </td>
            </tr>
        </table><br><br>
        <table width="100%">
            <tr>
                <td valign="top">From: King Mongkut\'s Institute of Technology Ladkrabang</td>
                <td align="right">To: '.$orderRow['taxName'].' '.$orderRow['taxLastname'].' '.$orderRow['taxAddress'].'</td>
            </tr>
        </table><br><hr>
        <table width="115%">
            <thead style="background-color: lightgray;">
            <br><br><tr>
                    <th>#</th>
                    <th>Description</th>
                    <th></th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Total</th><hr>
                </tr>
            </thead>
            <tbody>';

        $subtotal = 0;
        $i = 0;
        foreach ($orderItems_first_page as $row) {
            $subtotal += $row['TotalPrice'];
            $productID = $row['IDProduct'];
            $productQuery = mysqli_query($db, "SELECT * FROM stock WHERE IDProduct='$productID'");
            $productRow = mysqli_fetch_assoc($productQuery);
            $i++;
            $html .= '
            <tr><br><br>
                <th scope="row">' . $i . '</th>
                <td>' . $productRow['ProductName'] . '</td>
                <td></td>
                <td>' . $row['Quantity'] . '</td>
                <td>' . $row['PricePerUnit'] . '</td>
                <td>' . $row['TotalPrice'] . '</td>
            </tr>';
        }

        $html .= '</tbody>
            <tfoot>
            <br><br><tr>
                    <td colspan="4"></td>
                    <td>Subtotal</td>
                    <td>' . $subtotal . '</td>
                </tr>
                <tr>
                    <td colspan="4"></td>
                    <td>Tax</td>
                    <td>' . $subtotal * 0.07 . '</td>
                </tr>
                <tr>
                    <td colspan="4"></td>
                    <td>Total</td>
                    <td class="gray">' . $orderRow['totalPrice'] . '</td>
                </tr>
            </tfoot>
        </table>';

        $pdf->writeHTML($html, true, false, true, false, '');

        $pdf->AddPage();

        $html = '
        <table width="100%">
            <tr>
                <td valign="top"><h1><b>DELIVERY NOTE</b></h1></td>
                <td align="right">
                        <h3><span>Book company</span><br>
                        <span>Company representative name</span><br>
                        <span>Company address</span><br>
                        <span>Tax ID: 0123456789</span><br>
                        <span>Phone: 089123456</span><br>
                        <span>Fax: 1234</span></h3>
                </td>
            </tr>
        </table><br><br>
        <table width="100%">
            <tr>
                <td valign="top">From: King Mongkut\'s Institute of Technology Ladkrabang</td>
                <td align="right">To: '.$orderRow['CustName'].' '.$orderRow['lastname'].' '.$orderRow['address'].'</td>
            </tr>
        </table><br><hr>
        <table width="115%">
            <thead style="background-color: lightgray;">
            <br><br><tr>
                    <th>#</th>
                    <th>Description</th>
                    <th></th>
                    <th>Quantity</th>
                    <th>Unit Price</th>
                    <th>Total</th><hr>
                </tr>
            </thead>
            <tbody>';

        $subtotal = 0;
        $i = 0;
        foreach ($orderItems_second_page as $row) {
            $subtotal += $row['TotalPrice'];
            $productID = $row['IDProduct'];
            $productQuery = mysqli_query($db, "SELECT * FROM stock WHERE IDProduct='$productID'");
            $productRow = mysqli_fetch_assoc($productQuery);
            $i++;
            $html .= '
            <tr><br><br>
                <th scope="row">' . $i . '</th>
                <td>' . $productRow['ProductName'] . '</td>
                <td></td>
                <td>' . $row['Quantity'] . '</td>
                <td>' . $row['PricePerUnit'] . '</td>
                <td>' . $row['TotalPrice'] . '</td>
            </tr>';
        }

        $html .= '</tbody>
            <tfoot>
            <br><br><tr>
                    <td colspan="4"></td>
                    <td>Subtotal</td>
                    <td>' . $subtotal . '</td>
                </tr>
                <tr>
                    <td colspan="4"></td>
                    <td>Tax</td>
                    <td>' . $subtotal * 0.07 . '</td>
                </tr>
                <tr>
                    <td colspan="4"></td>
                    <td>Total</td>
                    <td class="gray">' . $orderRow['totalPrice'] . '</td>
                </tr>
            </tfoot>
        </table>';


    // output the HTML content
    $pdf->writeHTML($html, true, false, true, false, '');
}

// reset pointer to the last page
$pdf->lastPage();

// ---------------------------------------------------------

//Close and output PDF document
ob_end_clean();

$pdf->Output('example.pdf', 'I');
?>