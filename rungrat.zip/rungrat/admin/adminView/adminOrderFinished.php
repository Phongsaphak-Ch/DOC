<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);
    require_once '../JWT/JWT.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../adminStyle/report.css">
</head>
<body>
    <?php include_once "adminNavbar.php"; ?>

    <div style="margin-left:200px">
        <div class="areas"><br>
            <div class="backdrop">
                <h4>รายการที่สำเร็จแล้ว</h4><br>
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <form action="search.php" method="post" style="display: flex; align-items: center;">
                        <label for="search">Search:</label>
                        <input type="text" name="search" id="search" placeholder="Search somethings..."> 
                        <input type="submit" value="Search" class="search">
                    </form>
                </div>
                <form>
                <?php include_once "../adminControl/orderFinishedDisplayMain.php" ?>
                </form>
            </div>
            <br><br>
        </div>
    </div>
    
</body>
</html>
