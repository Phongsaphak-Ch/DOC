<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);
    require_once '../JWT/JWT.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../adminStyle/style.css">
</head>
<body onload="loadRe()">
<?php include_once "adminNavbar.php"; ?>
    <div style="margin-left:200px">
        <div class="areas"><br>
            <div class="backdrop">
                <h4>ใบแจ้งหนี้</h4><br>
                <div style="display: flex; justify-content: space-between; align-items: center;"> <!-- Added align-items: center; -->
                    <form action="search.php" method="post" style="display: flex; align-items: center;"> <!-- Added style for flex and align-items -->
                        <label for="search">Search:</label>

                        <input type="text" name="search" id="search" placeholder="Search somethings..."> 
                        <input type="submit" value="Search" class="search">
                    </form>      
                    <!-- <form action="../adminView/detailAll.php" method="post">
                        <input type="submit" value="Detail" class="insert">
                    </form>           -->
                    <form action="pdf.php" method="post" id="printForm">
                        <input type="hidden" name="orderIDs" id="orderIDs">
                        <input type="button" value="Print" class="insert" onclick="printSelected()">
                    </form>
                </div>
                <form>
                <?php include_once "../adminControl/invoice1.php"; ?>
                </form>
            </div>
            <br><br>
        </div>
    </div>

<script>
    function printSelected() {
        var checkboxes = document.querySelectorAll('input[name="checkbox_name"]:checked');
        var orderIDs = [];

        checkboxes.forEach(function(checkbox) {
            orderIDs.push(checkbox.value);
        });

        document.getElementById('orderIDs').value = JSON.stringify(orderIDs);
        document.getElementById('printForm').submit();
    }
</script>

</body>
</html>
