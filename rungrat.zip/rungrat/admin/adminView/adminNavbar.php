<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../adminStyle/sidebar.css">
    <script src="../adminScript/navBarScript.js"></script>
</head>
<body>
    <div class="sidenav">
        <a href="../adminView/adminMenu.php"><h3><br>Admin Page</h3></a>
        <a href="#" class="menu-item"><strong>รายการ</strong></a>
        <div class="sub-menu">
        <?php if ($super == '1') {
            echo "<a href='../adminView/adminList.php'>รายการแอดมิน</a>";
        }?>
            <a href="../adminView/adminCustomer.php">รายการลูกค้า</a>
            <a href="../adminView/adminProduct.php">รายการสินค้า</a>
        </div>

        <?php if ($super == '1') {
        echo "<a href='#' class='menu-item'><strong>รายงาน</strong></a>
        <div class='sub-menu'>
            <a href='../adminView/adminDairyReport.php'>รายงานยอดการขาย</a>
            <a href='../adminView/adminProductReport.php'>รายงานยอดการขายสินค้า</a>
        </div>";
        }
        ?>

        <a href="#" class="menu-item"><strong>รายการออเดอร์</strong></a>
        <div class="sub-menu">
            <a href="../adminView/adminOrdernotConfirm.php">รายการที่ยังไม่ยืนยัน</a>
            <a href="../adminView/adminOrderDelivery.php">รายการที่รอจัดส่ง</a>
            <a href="../adminView/adminOrderConfirmed.php">รายการที่ต้องได้รับ</a>
            <a href="../adminView/adminOrderFinished.php">รายการที่สำเร็จแล้ว</a>
            <a href="../adminView/adminOrderCanceled.php">รายการที่ยกเลิกแล้ว</a>
        </div>
        <a href="../adminView/invoice.php" class="menu-item"><strong>ใบแจ้งหนี้</strong></a>
        <a href="../adminView/taxInvoiceShow.php" class="menu-item"><strong>ใบกำกับภาษี/ใบส่งของ</strong></a>

        <br><br><br><br><br><br><br>
        <a href='../adminControl/logout.php'><font color='red'>Logout</font></a>
    </div>
</body>
</html>
