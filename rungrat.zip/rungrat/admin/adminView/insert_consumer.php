<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../adminStyle/insert.css">
</head>
<body>
    <div class="area">
        <div class="circles">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>        
            <div class="context">
                <center>
                    <div class="container">
                        <div class="input-group">
                            <form action="../adminControl/insert_customer.php" method="post" enctype="multipart/form-data">
                                <h2><center>Insert Customer</center></h2>

                                <label for="productCode">username : </label>
                                <input type="text" name="username" placeholder="username">
                                <span id="usernameError" style="color: red;"></span>

                                <label for="productCode">password : </label>
                                <input type="password" id="password" name="password" required oninput="validatePassword()">
                                <span id="passwordStatus" style="color: red;"></span>

                                <label for="productCode">confrim password : </label>
                                <input type="password" name="cpassword" id="cpassword" oninput="checkPasswordMatch()">
                                <span id="cpasswordStatus" style="color: red;"></span>

                                <label for="productName">ชื่อ :</label>
                                <Input Type="Text" Name="name" required>

                                <label for="productQuantity">ที่อยู่ :</label>
                                <Input Type="Text" Name="address" required>

                                <label for="productDetails">เบอร์โทรศัพท์ :</label>
                                <Input Type="tel" Name="tel" Size="10" minlenght = '10' MaxLenght="11" required>
                                
                                <center>
                                    <button type="submit" id="signupButton">Insert</button>
                                    <button type="button" onclick="window.location.href='../adminView/adminCustomer.php';">Cancel</button>
                                </center>
                            </form>
                        </div>
                    </div>
                </center>
            </div>
        </div>
    </div>
</body>
</html>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="../adminScript/validScript.js"></script>
