<?php
$error = isset($_GET['error']) ? $_GET['error'] : '';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../adminStyle/style.css">
</head>

<body>
    <div class="area">
        <div class="circles">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <div class="context">
                <center>
                    <div class="container">
                        <header>
                            <h1>Admin Login</h1>
                        </header>
                        <?php if ($error === 'InvalidCredentials'): ?>
                            <br><span style="color: red;">Username or password is invalid.</span><br>
                        <?php endif; ?>
                        <div class="input-group">
                            <form action="../adminControl/adminAuth.php" method="post">
                                <input type="text" name="username" placeholder="Username" maxlength="20" required>
                                <br>
                                <input type="password" name="password" placeholder="Password" maxlength="20" required>
                                <br><br>
                                <input type="submit" value="Login">
                            </form>
                        </div>
                    </div>
                </center>
            </div>
        </div>
    </div>
</body>

</html>