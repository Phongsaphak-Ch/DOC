<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/select.php';
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
    $db = mysqli_connect($host, $user, $password, $database);
?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../adminStyle/order.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.4/xlsx.full.min.js"></script>
    <script>
        // JavaScript function to calculate total price
        function calculateTotalPrice(pricePerUnit, quantity, totalField) {
            var totalPrice = pricePerUnit * quantity;
            document.getElementById(totalField).innerText = totalPrice.toFixed(2); // Display total price with 2 decimal places
            calculateTotalOrderPrice(); // Calculate total order price
        }

        // JavaScript function to calculate total order price
        function calculateTotalOrderPrice() {
            var totalOrderPrice = 0;
            var totalElements = document.getElementsByClassName('totalPrice');
            for (var i = 0; i < totalElements.length; i++) {
                totalOrderPrice += parseFloat(totalElements[i].innerText);
            }
            var vat = totalOrderPrice * 0.07;
            totalOrderPrice += vat;
            document.getElementById('totalOrderPrice').innerText = totalOrderPrice.toFixed(2);
        }
    </script>
</head>

<body>
    <?php include_once "adminNavbar.php"; ?>
    <center><br>
        <div style="margin-left:200px">
            <div class="container">
                <h1>
                    <font color='#000'>แก้ไขข้อมูล<br></font>
                </h1>
                <form action="../adminControl/updateOrder.php" method="post">
                    <?php
                    $adminModel = new adminModel($db);
                    if (isset($_GET['orderID'])) {
                        $orderID = $_GET['orderID'];
                        $orderRow = $adminModel->getOrderDetail($db, $orderID);

                        // Fetch customer details including address
                        $customerID = $orderRow['IDCust'];
                        $customerRow = $adminModel->selectCustomerByID($db, $id);

                        // Display order information
                        echo "<p><span style='float: left;'>Order ID: &nbsp&nbsp</span>" . $orderRow['OrderID'] . "</span></p>";
                        echo "<p><span style='float: left;'>Customer ID: &nbsp&nbsp</span>" . $orderRow['IDCust'] . "</span></p>";
                        echo "<p><span style='float: left;'>Customer name: &nbsp&nbsp</span><input type='text' name='name' value='" . $orderRow['CustName'] . "'>&nbsp&nbsp&nbsp&nbsp&nbsp<input type='text' name='lastname' value='" . $orderRow['lastName'] . "'></span></p>";
                        echo "<p><span style='float: left;'>Customer address: &nbsp&nbsp</span><input type='text' name='address' value='" . $orderRow['address'] . "'></span></p>";
                        echo "<p><span style='float: left;'>Customer Email: &nbsp&nbsp</span><input type='email' name='email' value='" . $orderRow['email'] . "'></span></p>";
                        echo "<p><span style='float: left;'>Payment Method: &nbsp&nbsp</span>" . $orderRow['paymentMethod'] . "</span></p>";
                        echo "<p><span style='float: left;'>Tel: &nbsp&nbsp</span><input type='tel' name='tel' value='" . $orderRow['tel'] . "'></span></p>";

                        echo "<p>Order Date: &nbsp&nbsp" . $orderRow['OrderDate'] . "</p>";

                        echo "<style>";
                        echo "table { border-collapse: collapse; }";
                        echo "table, th, td { border: 1px solid #ecf0f1; }";
                        echo "</style>";

                        // Display ordered items
                        echo "<center>";
                        echo "<table>";
                        echo "<tr>";
                        echo "<th>รูปสินค้า</th>";
                        echo "<th>ชื่อสินค้า</th>";
                        echo "<th>ราคาต่อชิ้น</th>";
                        echo "<th>จำนวน</th>";
                        echo "<th>ราคารวม</th>";
                        echo "</tr>";

                        $totalOrderPrice = 0; // Initialize total order price
                        $orderItems = $adminModel->getOrderItems($db, $orderID);
                        foreach ($orderItems as $row) {
                            $productID = $row['IDProduct'];
                            $productRow = $adminModel->getProductByID($db, $productID);
                            $totalPrice = $row["PricePerUnit"] * $row["Quantity"];
                            echo "<input type='hidden' name='productID[]' value='" . $productRow["IDProduct"] . "'>";
                            echo "<tr>";
                            echo '<td><img src="' . $productRow["image_url"] . '" alt="Product Image" style="width: 100px; height: 120px;"></td>';
                            echo "<td>" . $productRow["ProductName"] . "</td>";
                            echo "<td>" . $row["PricePerUnit"] . "</td>";
                            echo "<td><input type='number' name='quantity[]' value='" . $row["Quantity"] . "' onChange=\"calculateTotalPrice(" . $row["PricePerUnit"] . ", this.value, 'total_" . $productRow["IDProduct"] . "')\"></td>";
                            echo "<td><span id='total_" . $productRow["IDProduct"] . "' class='totalPrice'>$totalPrice</span></td>";
                            echo "</tr>";
                            $totalOrderPrice += $totalPrice;
                        }
                        $vat = $totalOrderPrice * 0.07;
                        $totalOrderPrice += $vat;

                        echo "</table>";

                        // Display total order price
                        echo "<p style='text-align: right; font-weight: bold;'>Total Order Price: <span id='totalOrderPrice'>$totalOrderPrice</span> Baht(VAT 7%)</p>";
                    }
                    mysqli_close($db);
                    ?>
                    <input type="hidden" name="orderID" value='<?php echo $orderID; ?>'>
                    <div class="button-container">
                        <button type="submit" name='confirm' value="ยืนยัน">ยืนยัน</button>&nbsp&nbsp&nbsp
                        <?php
                        echo "<button type='button' onclick=\"window.location.href='adminOrdernotConfirm.php';\">ยกเลิก</button>";
                        ?>
                    </div>
                </form>
            </div>
            <br><br><br><br><br><br><br><br><br>
        </div>
    </center>
</body>

</html>