<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../JWT/JWT.php';
    $db = mysqli_connect($host, $user, $password, $database);
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../adminStyle/insert.css">
</head>
<body>
    <div class="area">
        <div class="circles">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>    
    <div class="context">
        <center>
            <div class="container">
                <div class="input-group">
                    <form action="../adminControl/insert_product.php" method="post" enctype="multipart/form-data">
                        <h2><center>Insert Product</center></h2>

                        <label for="productImage">Product Image:</label>
                        <input type="file" name="productImage" id="productImage" accept="image/*" required>

                        <!-- <label for="productCode">Product Code:</label>
                        <input type="text" name="productCode" id="productCode" required> -->

                        <label for="productName">Product Name:</label>
                        <input type="text" name="productName" id="productName" required>

                        <label for="productPrice">Product Price:</label>
                        <input type="number" name="productPrice" id="productPrice" step="0.01" required>

                        <label for="productQuantity">Product Quantity:</label>
                        <input type="number" name="productQuantity" id="productQuantity" required>

                        <label for="productType">Product Type:</label>
                        <select name="adminType" id="adminType" onchange="showTypeInput()">
                            <?php 
                                $sql = "SELECT * FROM stocktype";
                                $result = mysqli_query($db, $sql);
                                if (mysqli_num_rows($result) > 0) {
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo '<option value="' . $row['typeID'] . '">' . $row['typeName'] . '</option>';
                                    }
                                    echo "<option value='T'>Another</option>";
                                } else {
                                    echo "<option value='T'>Another</option>";
                                    echo "No stock types found.";
                                }
                            mysqli_close($db);
                            ?>
                        </select>

                        <div id="typeInput" style="display: none;">
                            <label for="newType">New Type Name:</label>
                            <input type="text" name="newType" id="newType">
                        </div>

                        <label for="productDetails">Product Details:</label>
                        <textarea name="productDetails" id="productDetails" rows="4" required></textarea>
                        
                        <center>
                            <button type="submit">Insert</button>
                            <button type="button" onclick="window.location.href='../adminView/adminProduct.php';">Cancel</button>
                        </center>
                    </form>
                </div>
            </div>
        </center>
    </div>
</div>
</div>
</body>
</html>

<script>
    function showTypeInput() {
        var selectedType = document.getElementById("adminType").value;
        var typeInput = document.getElementById("typeInput");
        if (selectedType === "T") {
            typeInput.style.display = "block";
        } else {
            typeInput.style.display = "none";
        }
    }
</script>
