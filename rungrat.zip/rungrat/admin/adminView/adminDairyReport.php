<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../adminStyle/report.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.4/xlsx.full.min.js"></script>
</head>
<body onload="loadRe()">
    <?php include_once "adminNavbar.php"; ?>

    <div style="margin-left:200px">
        <div class="backdrop">
            <h4>รายงานยอดขาย</h4><br>
            <h3 id="date_section">
                เริ่มต้น: <input type="date" name="start_date" id="start_date" value="<?php echo date('Y-m-d'); ?>" onchange="onChangeDate()"><br>
                สิ้นสุด: <input type="date" name="end_date" id="end_date" value="<?php echo date('Y-m-d'); ?>" onchange="onChangeDate()">
            </h3>
                </select>
            </h3>
            <br><div id="report_table"></div><br><br>
            <center><button onclick="exportToExcel()">Export to Excel</button></center>
        </div><br><br>
    </div>
</body>
</html>
<script>
    function exportToExcel() {
    const table = document.querySelector("table");
    const tableRows = table.querySelectorAll("tr");
    const dataArray = [];

    const columnNames = [];
    table.querySelector("tr").querySelectorAll("th").forEach(function(th) {
        columnNames.push(th.innerText);
    });
    dataArray.push(columnNames);

    tableRows.forEach(function(row, index) {
        if (index === 0) return;

        const rowData = [];
        row.querySelectorAll("td").forEach(function(cell) {
            rowData.push(cell.innerText);
        });
        dataArray.push(rowData);
    });

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(dataArray);
    XLSX.utils.book_append_sheet(wb, ws, "รายงาน");

    XLSX.writeFile(wb, "รายงาน.xlsx");
}

function onChangeDate() {
    var start_date = document.getElementById("start_date").value;
    var end_date = document.getElementById("end_date").value;

    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("report_table").innerHTML = this.responseText;
        }
    };

    var url = "../adminControl/fetch_data.php?" + "start_date=" + start_date + "&end_date=" + end_date;
    xhttp.open("GET", url, true);
    xhttp.send();
}

function loadRe() {
    onChangeDate();
}
</script>
