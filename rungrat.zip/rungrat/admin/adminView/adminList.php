<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../adminStyle/style.css">
    <script src="../adminScript/script.js"></script>
</head>

<body>
    <?php include_once "adminNavbar.php"; ?>

    <div style="margin-left:200px">
        <div class="area"><br>
            <div class="backdrop">
                <h4>Admin List</h4><br>
                <div style="display: flex; justify-content: space-between; align-items: center;">
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" style="display: flex; align-items: center;">
                    <label for="search">Search:</label>
                    <select name="search_type" id="search_type">
                        <option value="id">ID</option>
                        <option value="name">Name</option>
                    </select>
                    <input type="text" name="search" id="search" placeholder="Search somethings...">
                    <input type="submit" value="Search" class="search">
                </form>

                <?php
                    // เช็คว่ามีการส่งค่าการค้นหามาหรือไม่
                    if(isset($_POST['search'])) {
                        $search_type = $_POST['search_type'];
                        $search_query = $_POST['search'];

                        // ปรับ SQL query ตามการค้นหา
                        if ($search_type == 'id') {
                            $sql = "SELECT * FROM admin WHERE admin_id LIKE '%$search_query%'";
                        } else if ($search_type == 'name') {
                            $sql = "SELECT * FROM admin WHERE adminName LIKE '%$search_query%'";
                        } else {
                            $sql = "SELECT * FROM admin";
                        }

                        $result = mysqli_query($db, $sql);
                    } else {
                        $sql = "SELECT * FROM admin";
                        $result = mysqli_query($db, $sql);
                    }
                ?>

                    <form action="insertAdmin.php" method="post">
                        <input type="submit" value="Insert" class="insert">
                    </form>
                </div>
                <form>
                    <?php include_once "../adminControl/adminListQuery.php" ?>
                </form>
            </div>
            <br><br>
        </div>
    </div>
</body>

</html>