<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);
    require_once '../JWT/JWT.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../adminStyle/style.css">
</head>
<body>
    <?php include_once "adminNavbar.php"; ?>
    <div style="margin-left:200px">
        <div class="area"><br>
            <div class="backdrop">
                <h4>Customer List</h4><br>
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <!-- Form for search -->
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" style="display: flex; align-items: center;">
                        <label for="search">Search:</label>
                        <select name="search_type" id="search_type">
                            <option value="id">ID</option>
                            <option value="name">Name</option>
                        </select>
                        <input type="text" name="search" id="search" placeholder="Search somethings...">
                        <input type="submit" value="Search" class="search">
                    </form>
                    <!-- Insert form for super admins -->
                    <?php if ($super == 1) { echo '<form action="insert_consumer.php" method="post"> <input type="submit" value="Insert" class="insert"> </form>'; } ?>
                </div>

                <!-- Display customer list -->
                <form>
                    <?php include_once "../adminControl/adminCustomerQuery.php" ?>
                </form>
            </div>
            <br><br>
        </div>
    </div>
</body>
</html>

<script>
// JavaScript functions for deleting selected customers
function deleteSelected() {
    var checkboxes = document.querySelectorAll('input[name="checkbox_name"]:checked');
    var IDCusts = [];
    checkboxes.forEach(function(checkbox) {
        IDCusts.push(checkbox.value);
    });
    document.getElementById('IDCusts').value = JSON.stringify(IDCusts);
    document.getElementById('delete').submit();
}

function confirmDeletes() {
    var IDCustsArray = [];
    var checkboxes = document.querySelectorAll('input[name="checkbox_name"]:checked');
    checkboxes.forEach(function(checkbox) {
        IDCustsArray.push(checkbox.value);
    });
    var IDCusts = IDCustsArray.join(',');
    if (confirm("Are you sure you want to delete Customer ID(s): " + IDCusts + "?")) {
        document.getElementById('IDCusts').value = IDCusts;
        document.getElementById('delete').submit();
    } else {
        return false;
    }
}
</script>