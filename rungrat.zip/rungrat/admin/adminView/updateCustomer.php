<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);
    require_once '../JWT/JWT.php';
    if ($super == '0') {
        header("Location: ../adminControl/logout.php");
        exit();
    }
?>

<!DOCTYPE html>
<html lang ="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../adminStyle/insert.css">
</head>
<body>
    <div class="area">
        <div class="circles">
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>
            <li></li>    
    <div class="context">
        <center>
            <div class="container">
                <div class="input-group">
                    <form action="../adminControl/updatedconsumer_successful.php" method="post" enctype="multipart/form-data">
                        <h2><center>Update Customer</center></h2>
                        <?php include_once "../adminControl/upCust.php"; ?>
                        <center>
                            <button type="submit">Update</button>
                            <button type="button" onclick="window.location.href='adminCustomer.php';">Cancel</button>
                        </center>
                    </form>
                </div>
            </div>
        </center>
    </div>
</div>
</div>
</body>
</html>
