<?php
    // เชื่อมต่อกับฐานข้อมูล
    require_once '../adminModel/connectDatabase.php';
    require_once '../JWT/JWT.php';
    $db = mysqli_connect($host, $user, $password, $database);

    // ตรวจสอบว่ามีการส่งค่า parameter product มาหรือไม่
    if ($super == 1){
        $chartType = isset($_GET['chartType']) ? $_GET['chartType'] : 'sales';

        if ($chartType === 'sales') {
            // คำสั่ง SQL เพื่อดึงยอดการขายรายวัน
            $sql = "SELECT DATE(OrderDate) AS sale_date, SUM(totalprice) AS daily_sales FROM order_detail WHERE status != 'cancel' GROUP BY DATE(OrderDate)";
        } else if ($chartType === 'product') {
            // คำสั่ง SQL เพื่อดึงยอดขายของสินค้า
            $sql = "SELECT ProductName, ProductSold FROM stock GROUP BY IDProduct";
        }

        // ดึงข้อมูลจากฐานข้อมูล
        $result = mysqli_query($db, $sql);

        // สร้าง array เก็บข้อมูลสำหรับกราฟ
        $dataPoints = array();
        while ($row = mysqli_fetch_assoc($result)) {
            if ($chartType === 'sales') {
                $dataPoints[] = array("y" => $row['daily_sales'], "label" => $row['sale_date']);
            } else if ($chartType === 'product') {
                $dataPoints[] = array("y" => $row['ProductSold'], "label" => $row['ProductName']);
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Sales Chart</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" type="text/css" href="../adminStyle/style.css">
</head>

<body>
    <?php include_once "adminNavbar.php"; ?>

    <div style="margin-left:200px">
        <div class="area"><br>
        <?php
        if ($super == 1){
                echo "<p><h2>Welcome, " . $username ."!</h2></p>";
            ?>
            <div class="backdrop">
                <form id="chartForm" method="GET" action="">
                    <label for="chartType">Chart Type:</label>
                    <select name="chartType" id="chartType" onchange="document.getElementById('chartForm').submit();">
                        <option value="sales" <?php if ($chartType === 'sales') echo 'selected'; ?>>Daily Sales</option>
                        <option value="product" <?php if ($chartType === 'product') echo 'selected'; ?>>Product Sales</option>
                    </select>
                </form>
                <canvas id="salesChart"></canvas>
            </div>
        <?php } else if ($super == 0){
            echo "<div class='backdrop'>";
            echo "<p><h3>Welcome, " . $username ."!</h3></p>";
            echo "</div>";
        }
        
        ?>

            <br><br>
        </div>
    </div>

    <script>
        // สร้างกราฟด้วย Chart.js
        var ctx = document.getElementById('salesChart').getContext('2d');
        var chartType = '<?php echo $chartType; ?>';

        var chartConfig = {
            type: (chartType === 'product') ? 'bar' : 'line',
            data: {
                labels: [<?php foreach ($dataPoints as $dataPoint) echo "'" . $dataPoint['label'] . "', "; ?>],
                datasets: [{
                    label: (chartType === 'sales') ? 'Daily Sales' : 'Product Sales',
                    data: [<?php foreach ($dataPoints as $dataPoint) echo $dataPoint['y'] . ", "; ?>],
                    backgroundColor: (chartType === 'product') ? 'rgba(54, 162, 235, 0.2)' : 'rgba(255, 99, 132, 0.2)',
                    borderColor: (chartType === 'product') ? 'rgba(54, 162, 235, 1)' : 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        };

        var salesChart = new Chart(ctx, chartConfig);
    </script>
</body>

</html>
