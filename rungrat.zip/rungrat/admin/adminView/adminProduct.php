<?php
    require_once '../adminModel/connectDatabase.php';
    require_once '../adminModel/select.php';
    $db = mysqli_connect($host, $user, $password, $database);
    require_once '../JWT/JWT.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="../adminStyle/style.css">
    <style>
        body {
            background: linear-gradient(to left, #8f94fb, #4e54c8);
        }
    </style>
</head>
<body>
    <?php include_once "adminNavbar.php"; ?>

    <div style="margin-left:200px">
        <div class="backdrop">
            <h4>Product List</h4><br>
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" style="display: flex; align-items: center;">
                    <label for="search">Search:</label>
                    <select name="search_type" id="search_type">
                        <option value="id">ID</option>
                        <option value="name">Name</option>
                        <option value="type">Type</option>
                    </select>
                    <input type="text" name="search" id="search" placeholder="Search somethings...">
                    <input type="submit" value="Search" class="search">
                </form>
                <?php
                    if ($super == 1) {
                        echo '<form action="insertStock.php" method="post">
                                <input type="submit" value="Insert" class="insert">
                            </form>';
                    }
                ?>
            </div>
            <form>
                <?php include_once "../adminControl/adminProductQuery.php"; ?>
            </form>
        </div>
        <br><br>
    </div>
</body>
</html>


<script>
// JavaScript functions for deleting selected customers
// function deleteSelected() {
//     var checkboxes = document.querySelectorAll('input[name="checkbox_name"]:checked');
//     var IDProducts = [];
//     checkboxes.forEach(function(checkbox) {
//         IDProducts.push(checkbox.value);
//     });
//     document.getElementById('IDProducts').value = JSON.stringify(IDProducts);
//     document.getElementById('delete').submit();
// }

// function confirmDeletes() {
//     var IDProductsArray = [];
//     var checkboxes = document.querySelectorAll('input[name="checkbox_name"]:checked');
//     checkboxes.forEach(function(checkbox) {
//         IDProductsArray.push(checkbox.value);
//     });
//     var IDProducts = IDProductsArray.join(',');
//     if (confirm("Are you sure you want to delete Product ID(s): " + IDProducts + "?")) {
//         document.getElementById('IDProducts').value = IDProducts;
//         document.getElementById('delete').submit();
//     } else {
//         return false;
//     }
// }
</script>
