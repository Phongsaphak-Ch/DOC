$(document).ready(function() {
    $('input[name="username"]').blur(function() {
        var username = $(this).val();

        $.ajax({
            url: '../adminControl/check_username.php',
            method: 'POST',
            data: {username: username},
            success: function(response) {
                if (response == 'taken') {
                    $('#usernameError').text('Username is already taken. Please choose another one.');
                    $('input[name="username"]').val('');
                } else {
                    $('#usernameError').text('');
                }
            },
            error: function(xhr, status, error) {
                alert('Error occurred while checking username: ' + error);
            }
        });
    });
});


const container = document.getElementById('container');
const registerBtn = document.getElementById('register');
const loginBtn = document.getElementById('login');

registerBtn.addEventListener('click', () => {
    container.classList.add("active");
});

loginBtn.addEventListener('click', () => {
    container.classList.remove("active");
});

function validatePassword() {
    var password = document.getElementById("password").value;
    var passwordLength = password.length;
    var containsUppercase = /[A-Z]/.test(password);
    var containsLowercase = /[a-z]/.test(password);
    var containsNumber = /\d/.test(password);
    var containsSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);

    var statusElement = document.getElementById("passwordStatus");
    var isValid = true;

    statusElement.innerText = "*important : Requires a minimum of 8 characters, at least 1 uppercase letter, 1 lowercase letter, 1 number, and 1 special character.";

    if (passwordLength < 8 || !containsUppercase || !containsLowercase || !containsNumber || !containsSpecialChar) {
        isValid = false;
        statusElement.style.color = "red";
        statusElement.innerText = "*important : Requires a minimum of 8 characters, at least 1 uppercase letter, 1 lowercase letter, 1 number, and 1 special character.";
    } else {
        statusElement.style.color = "green";
        statusElement.innerText = "Password meets the requirements.";
    }
    checkPasswordMatch();
    return isValid;
}

function checkPasswordMatch() {
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("cpassword").value;
    var statusElement = document.getElementById("cpasswordStatus");

    if (password === confirmPassword && password !== "" && confirmPassword !== "") {
        statusElement.innerText = "Password confirmation does match.";
        statusElement.style.color = "green";
        enableDisableSignupButton(true);
    } else {
        statusElement.innerText = "Password confirmation does not match.";
        statusElement.style.color = "red";
        enableDisableSignupButton(false);
    }
}

function enableDisableSignupButton(isValid) {
    var signupButton = document.getElementById("signupButton");

    if (isValid) {
        signupButton.disabled = false;
    } else {
        signupButton.disabled = true;
    }
}