function exportToExcel() {
    const table = document.querySelector("table");
    const tableRows = table.querySelectorAll("tr");
    const dataArray = [];

    // ดึงชื่อคอลัมน์
    const columnNames = [];
    table.querySelector("tr").querySelectorAll("th").forEach(function(th) {
        columnNames.push(th.innerText);
    });
    dataArray.push(columnNames);

    // วนลูปเพื่อดึงข้อมูลจากแต่ละแถวของตาราง
    tableRows.forEach(function(row, index) {
        // ข้ามแถวแรกที่มีชื่อคอลัมน์
        if (index === 0) return;

        const rowData = [];
        row.querySelectorAll("td").forEach(function(cell) {
            rowData.push(cell.innerText);
        });
        dataArray.push(rowData);
    });

    // สร้าง Workbook ด้วยข้อมูลที่ดึงมาจากตาราง
    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.aoa_to_sheet(dataArray);
    XLSX.utils.book_append_sheet(wb, ws, "รายงาน");

    // บันทึกข้อมูลเป็นไฟล์ Excel
    XLSX.writeFile(wb, "รายงาน.xlsx");
}

function onChangeDate() {
    var start_date = document.getElementById("start_date").value;
    var end_date = document.getElementById("end_date").value;
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("report_table").innerHTML = this.responseText;
        }
    };
    var url = "../adminModel/fetch_product.php?" + "start_date=" + start_date + "&end_date=" + end_date;
    xhttp.open("GET", url, true);
    xhttp.send();
}

function loadReport() {
    onChangeDate();
}