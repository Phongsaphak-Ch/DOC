document.addEventListener("DOMContentLoaded", function() {
    var menuItems = document.querySelectorAll('.menu-item');

    menuItems.forEach(function(item) {
        item.addEventListener('click', function(event) {
            var subMenu = this.nextElementSibling;

            var allSubMenus = document.querySelectorAll('.sub-menu');
            allSubMenus.forEach(function(menu) {
                menu.classList.remove('active');
            });

            var allMenuItems = document.querySelectorAll('.menu-item');
            allMenuItems.forEach(function(menuItem) {
                menuItem.classList.remove('active');
            });

            subMenu.classList.toggle('active');
            this.classList.add('active');
        });

        item.nextElementSibling.querySelectorAll('a').forEach(function(subLink) {
            subLink.addEventListener('click', function(event) {
                var subMenu = this.parentNode;
                subMenu.classList.remove('active');
            });
        });
    });
});