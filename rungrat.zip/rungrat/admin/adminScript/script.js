function confirmDelete(admin_id) {
    if (confirm("Are you sure you want to delete admin ID " + admin_id + "?")) {
        window.location.href = '../adminControl/deleteAdmin.php?message=' + admin_id;
    } else {
        return false;
    }
}