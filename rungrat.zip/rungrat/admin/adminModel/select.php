<?php

class adminModel {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function getUserByUsername($db, $username) {
        $query = "SELECT password, admin_id, adminName, super FROM admin WHERE username = ?";
        $stmt = $db->prepare($query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        return $row = $result->fetch_assoc();
    }

    public function selectAdmins($db) {
        return mysqli_query($db, "SELECT admin_id, adminName, email, username, tel, address, super FROM admin ");
    }

    function getQuantityFromOrderItem($db, $orderID, $productID) {
        $query = "SELECT Quantity FROM order_item WHERE OrderID = ? AND IDProduct = ?";
        $stmt = $db->prepare($query);
        $stmt->bind_param("ss", $orderID, $productID);
        $stmt->execute();
        $stmt->bind_result($quantity);
        $stmt->fetch();
        $stmt->close();
        return $quantity;
    }

    public function selectAdminById($db, $id) {
        $query = "SELECT admin_id, username, adminName, address, email, tel FROM admin WHERE admin_id=?";
        $stmt = mysqli_prepare($db, $query);
        mysqli_stmt_bind_param($stmt, "s", $id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        return mysqli_fetch_array($result);
    }

    private function fetchUsername($username) {
        $query = "SELECT username FROM admin WHERE username = ?";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        return $stmt->get_result()->fetch_assoc();
    }

    public function checkUsernameAvailability($username) {
        $result = $this->fetchUsername($username);
        return $result ? 'taken' : 'available';
    }

    public function getLastAdminID($db) {
        $get_last_id_sql = "SELECT admin_id FROM admin ORDER BY admin_id DESC LIMIT 1";
        return mysqli_query($db, $get_last_id_sql);
    }

    public function getLastStock($db) {
        $get_last_id_sql = "SELECT IDProduct FROM stock ORDER BY IDProduct DESC LIMIT 1";
        return mysqli_query($db, $get_last_id_sql);
    }

    public function getLastStockType($db) {
        $get_last_id_sql = "SELECT typeID FROM stocktype ORDER BY typeID DESC LIMIT 1";
        return mysqli_query($db, $get_last_id_sql);
    }

    public function getNewAdminID($db) {
        $sql_max_id = "SELECT MAX(CAST(SUBSTRING(admin_id, 2) AS UNSIGNED)) AS max_id FROM admin";
        $result = $db->query($sql_max_id);
        $row = $result->fetch_assoc();
        $max_id = $row["max_id"];
        $new_id = ++$max_id;
        return "A" . sprintf("%03d", $new_id);
    }

    public function selectCustomer($db) {
        return mysqli_query($db, "SELECT IDCust, CustName, Address, Tel FROM customer ");
    }

    public function selectStock($db) {
        return mysqli_query($db, "SELECT * FROM stock");
    }

    public function selectCustomerByID($db, $id) {
        $cur = mysqli_query($db, "SELECT * FROM customer WHERE IDCust='$id'");
        $row = mysqli_fetch_array($cur);
        return $row;
    }

    public function getStockData($db, $id) {
        $cur = mysqli_query($db, "SELECT * FROM stock WHERE IDProduct='$id'");
        $row = mysqli_fetch_array($cur);
        return $row;
    }

    public function getImagePath($db, $a1) {
        $stmt = mysqli_prepare($db, "SELECT image_url FROM stock WHERE IDProduct = ?");
        mysqli_stmt_bind_param($stmt, "s", $a1);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $image_path);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);
        return $image_path;
    }
    
    public function getStockQty($db, $a1) {
        $sql = "SELECT StockQty FROM stock WHERE IDProduct = ?";
        $stmt = mysqli_prepare($db, $sql);
        mysqli_stmt_bind_param($stmt, "s", $a1);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_bind_result($stmt, $stock_qty);
        mysqli_stmt_fetch($stmt);
        mysqli_stmt_close($stmt);
        return $stock_qty;
    }
    
    function getOrdersByDateRange($db, $start_date, $end_date) {
        $sql = "SELECT OrderID, CustName, VAT, subTotal, totalPrice, DATE_FORMAT(orderDate, '%H:%i:%s') AS orderTime 
                FROM order_detail 
                WHERE DATE(orderDate) BETWEEN '$start_date' AND '$end_date' 
                AND paymentStatus = 'paid' 
                AND status = 'finish'";
        $result = mysqli_query($db, $sql);
        return $result;
    }

    function getOrderIDsByDateRange($db, $start_date, $end_date) {
        $order_id_sql = "SELECT OrderID FROM order_detail WHERE orderDate BETWEEN '$start_date' AND '$end_date' AND status = 'finish'";
        $order_id_result = mysqli_query($db, $order_id_sql);
        $order_ids = [];
        while ($row = mysqli_fetch_assoc($order_id_result)) {
            $order_ids[] = $row['OrderID'];
        }
        return $order_ids;
    }
    
    function getProductSalesByOrderID($db, $order_id) {
        $product_sales = [];
    
        $product_sql = "SELECT IDProduct, Quantity FROM order_item WHERE OrderID = '$order_id'";
        $product_result = mysqli_query($db, $product_sql);
        while ($row = mysqli_fetch_assoc($product_result)) {
            $product_id = $row['IDProduct'];
            $quantity = $row['Quantity'];
    
            // เพิ่มจำนวนสินค้าที่ขายไปในรายงาน
            if (isset($product_sales[$product_id])) {
                $product_sales[$product_id] += $quantity;
            } else {
                $product_sales[$product_id] = $quantity;
            }
        }
    
        return $product_sales;
    }
    
    function getProductInfoByID($db, $product_id) {
        $product_info_sql = "SELECT * FROM stock WHERE IDProduct = '$product_id'";
        $product_info_result = mysqli_query($db, $product_info_sql);
        return mysqli_fetch_assoc($product_info_result);
    }
    
    function displayProductInfoTable($product_info, $quantity_sold) {
        echo "<tr><td>{$product_info['IDProduct']}</td>";
        echo "<td>{$product_info['ProductName']}</td>";
        echo "<td>{$product_info['StockQty']}</td>";
        echo "<td>$quantity_sold</td></tr>";
    }
    
    function getOrdersByStatus($db, $status) {
        $orders = [];
        $orderQuery = mysqli_query($db, "SELECT * FROM order_detail WHERE status = '$status' ORDER BY OrderDate DESC");
        while ($orderRow = mysqli_fetch_assoc($orderQuery)) {
            $orders[] = $orderRow;
        }
        return $orders;
    }

    function getOrderItems($db, $orderID) {
        $orderItems = [];
        $orderItemsQuery = mysqli_query($db, "SELECT * FROM order_item WHERE OrderID='$orderID'");
        while ($row = mysqli_fetch_assoc($orderItemsQuery)) {
            $orderItems[] = $row;
        }
        return $orderItems;
    }

    function getProductByID($db, $productID) {
        $productQuery = mysqli_query($db, "SELECT * FROM stock WHERE IDProduct='$productID'");
        $productRow = mysqli_fetch_assoc($productQuery);
        return $productRow;
    }

    function getOrderDetail($db, $orderID) {
        $orderQuery = mysqli_query($db, "SELECT * FROM order_detail WHERE OrderID='$orderID'");
        return mysqli_fetch_assoc($orderQuery);
    }

    function getAllOrderDetail($db) {
        $orderQuery = mysqli_query($db, "SELECT * FROM order_detail");
        return $orderQuery;
    }

    public function getAllOrderDetailForInvoice($db, $adminType) {
        $adminTypeCondition = "";
        if ($adminType == 0) {
            $adminTypeCondition = "WHERE print = 0";
        } else if ($adminType == 1) {
            $adminTypeCondition = "WHERE print = 1";
        } else {
            $adminTypeCondition = "";
        }
        
        $orderQuery = mysqli_query($db, "SELECT * FROM order_detail $adminTypeCondition");
        return $orderQuery;
    }

    public function getAllOrderDetailForTaxInvoice($db, $adminType) {
        $adminTypeCondition = "";
        if ($adminType == 0) {
            $adminTypeCondition = "WHERE taxPrint = 0 AND status = 'deli'";
        } else if ($adminType == 1) {
            $adminTypeCondition = "WHERE taxPrint = 1";
        } else {
            $adminTypeCondition = "WHERE taxPrint = 1 OR taxPrint = 0";
        }
        
        $orderQuery = mysqli_query($db, "SELECT * FROM order_detail $adminTypeCondition ");
        return $orderQuery;
    }
    
    function getTotalOrderPrice($db, $orderID) {
        $get_total_price_query = "SELECT SUM(PricePerUnit * Quantity) AS total_price FROM order_item WHERE OrderID = '$orderID'";
        $total_price_result = mysqli_query($db, $get_total_price_query);
        $total_price_row = mysqli_fetch_assoc($total_price_result);
        return $total_price_row['total_price'];
    }

    public function selectForEmailRegis() {
        $query = "SELECT MAX(CAST(SUBSTRING(IDCust, 2) AS UNSIGNED)) AS max_id FROM customer";
        $stmt = $this->db->prepare($query);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return $row['max_id'];
    } 
    
}
?>
