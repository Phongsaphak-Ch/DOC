<?php

class adminUpdateModel {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function updateAdminData($db, $admin_id, $adminName, $email, $address, $tel) {
        $stmt = mysqli_prepare($db, "UPDATE admin SET adminName = ?, email = ?, address = ?, tel = ? WHERE admin_id = ?");
        mysqli_stmt_bind_param($stmt, "sssss", $adminName, $email, $address, $tel, $admin_id);
        return mysqli_stmt_execute($stmt);
    }

    public function updateCustomer($db, $id, $name, $address, $tel) {
        $stmt = mysqli_prepare($db, "UPDATE customer SET CustName = ?, Address = ?, Tel = ? WHERE IDCust = ?");
        mysqli_stmt_bind_param($stmt, "ssss", $name, $address, $tel, $id);
        $success = mysqli_stmt_execute($stmt);
        return $success;
    }

    function updateStockQuantityCust($db, $productID, $quantityDifference) {
        $query = "UPDATE stock SET StockQty = StockQty + ? WHERE IDProduct = ?";
        $stmt = $db->prepare($query);
        $stmt->bind_param("is", $quantityDifference, $productID);
        $stmt->execute();
        $stmt->close();
    }

    public function updateStock($db, $a1, $a2, $a3, $new_stock_qty, $a5, $image_path) {
        // เตรียมคำสั่ง SQL สำหรับการอัปเดตข้อมูล
        $sql = "UPDATE stock SET ProductName = ?, PricePerUnit = ?, StockQty = ?, details = ?, image_url = ? WHERE IDProduct = ?";
        // เตรียมคำสั่งพร้อมพารามิเตอร์
        $stmt = mysqli_prepare($db, $sql);
        mysqli_stmt_bind_param($stmt, "ssssss", $a2, $a3, $new_stock_qty, $a5, $image_path, $a1);
        // ทำการ execute คำสั่ง SQL
        $result = mysqli_stmt_execute($stmt);
        // ปิดคำสั่ง SQL
        mysqli_stmt_close($stmt);
        // คืนค่าผลลัพธ์ของการ execute คำสั่ง SQL
        return $result;
    }

    public function updateOrderStatus($db, $orderID, $status) {
        $cur = "UPDATE order_detail SET status = '$status' WHERE OrderID='$orderID'";
        $result = mysqli_query($db, $cur);
        return $result;
    }

    public function updateOrderStatusAll($db, $status) {
        $cur = "UPDATE order_detail SET status = '$status' WHERE status = 'wait'";
        $result = mysqli_query($db, $cur);
        return $result;
    }
    
    public function updateProductSold($db, $orderID) {
        $update_product_sold_sql = "UPDATE stock s
                                    INNER JOIN order_item oi ON s.IDProduct = oi.IDProduct
                                    INNER JOIN order_detail od ON oi.OrderID = od.OrderID
                                    SET s.ProductSold = s.ProductSold + oi.Quantity
                                    WHERE od.OrderID = '$orderID'";
        $update_product_sold_result = mysqli_query($db, $update_product_sold_sql);
        return $update_product_sold_result;
    }
    
    public function updateOrderItemQuantity($db, $orderID, $productID, $quantity) {
        $cur = "UPDATE order_item SET Quantity = '$quantity'
                WHERE OrderID = '$orderID' AND IDProduct = '$productID'";
        return mysqli_query($db, $cur);
    }

    public function updateOrderDetails($db, $name, $lastName, $email, $tel, $address, $totalOrderPrice, $vat, $orderID) {
        $update_order = "UPDATE order_detail 
                         SET CustName = '$name', lastName = '$lastName', email = '$email', 
                             tel = '$tel', address = '$address', totalPrice = '$totalOrderPrice', VAT = '$vat' 
                         WHERE OrderID = '$orderID'";
        return mysqli_query($db, $update_order);
    }

    public function updateStockQuantity($db, $productID, $newStockQty) {
        $updateStockQuery = "UPDATE stock SET StockQty='$newStockQty' WHERE IDProduct='$productID'";
        return mysqli_query($db, $updateStockQuery);
    }
    
    

}
?>
