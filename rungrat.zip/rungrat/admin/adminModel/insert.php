<?php
class adminInsertModel {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function insertAdmin() {
        return "INSERT INTO admin (admin_id, username, password, email, adminName, address, tel, super) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    }

    public function insertStock($conn, $product_code, $product_name, $product_price, 
    $product_qty, $product_detail, $image_path, $productSold, $typeid) {
    $stmt = $conn->prepare("INSERT INTO stock(IDProduct, ProductName, PricePerUnit, StockQty, details, image_url, ProductSold, typeID)
            VALUES(?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssdssis", $product_code, $product_name, $product_price, 
    $product_qty, $product_detail, $image_path, $productSold, $typeid);
    $success = $stmt->execute();
    return $success;
}


    function insertCustomer($db, $new_id_formatted, $username, $hashedPassword, $name, $address, $tel) {
        $stmt = mysqli_prepare($db, "INSERT INTO customer(IDCust, username, password,  CustName, Address, Tel)
                                        VALUES (?, ?, ?, ?, ?, ?)");
        if (!$stmt) {
            return false;
        }
        mysqli_stmt_bind_param($stmt, "ssssss", $new_id_formatted, $username, $hashedPassword, $name, $address, $tel);
        $result = mysqli_stmt_execute($stmt);
        mysqli_stmt_close($stmt);
        return $result;
    }

    public function insertStockType($db, $typeid, $new_type_name) {
        $typeSold = '0';
        $sql = "INSERT INTO stocktype (typeID, typeName, typeSold) VALUES (?, ?, ?)";
        $stmt = mysqli_prepare($db, $sql);

        if ($stmt === false) {
            return false;
        }
        mysqli_stmt_bind_param($stmt, "ssi", $typeid, $new_type_name, $typeSold);
        $result = mysqli_stmt_execute($stmt);
        if ($result === false) {
            return false;
        }
        mysqli_stmt_close($stmt);
        return true;
    }

}
?>
