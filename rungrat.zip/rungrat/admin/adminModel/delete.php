<?php
class adminDeleteModel {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function deleteAdminData($db, $admin_id) {
        $stmt = mysqli_prepare($db, "DELETE FROM admin WHERE admin_id = ?");
        mysqli_stmt_bind_param($stmt, "s", $admin_id);
        return mysqli_stmt_execute($stmt);
    }

    function deleteCustomer($db, $code) {
        $stmt = mysqli_prepare($db, "DELETE FROM customer WHERE IDCust = ?");
        mysqli_stmt_bind_param($stmt, "s", $code);
        $result = mysqli_stmt_execute($stmt);
        return $result;
    }

    function deleteProduct($db, $code) {
        $stmt = mysqli_prepare($db, "    DELETE FROM stock WHERE IDProduct = ?");
        mysqli_stmt_bind_param($stmt, "s", $code);
        $result = mysqli_stmt_execute($stmt);
        return $result;
    }
}
?>
